import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { stringify } from '../services/utils';
import { Calendar, RefreshCw, Clock, Newspaper, School, Brain, ShieldCheck, Box, Bookmark, BookmarkCheck, Plus, Database, Search, ArrowRight, Zap, Activity, Info, Globe, Sparkles, Flame, Timer } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { UniversityCategory, NewsItem } from '../types';
import { fetchLiveNews } from '../services/geminiService';
import { getCloudNews, archiveNewsItems, getGlobalSyncMetadata, updateGlobalSyncMetadata } from '../services/dbService';
import { summarizeNews } from '../services/aiService';
import { getLocalProfile, checkAndIncrementRequests, DAILY_LIMIT } from '../services/userService';
import QuotaModal from './QuotaModal';

const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
const INITIAL_VISIBLE_COUNT = 8;
const REVEAL_STEP = 8;

const UniversityAvatar: React.FC<{ title: string; category: string }> = ({ category }) => {
  const getGradient = () => {
    switch (category) {
      case 'Federal': return 'from-blue-600 to-indigo-900';
      case 'State': return 'from-emerald-500 to-teal-800';
      case 'Private': return 'from-purple-600 to-fuchsia-900';
      case 'JAMB': return 'from-red-600 to-orange-700';
      case 'Polytechnic': return 'from-orange-500 to-red-800';
      case 'COE': return 'from-cyan-500 to-blue-800';
      case 'National': return 'from-gray-800 to-black';
      case 'Jobs': return 'from-emerald-600 to-green-900';
      case 'Scholarships': return 'from-yellow-500 to-amber-800';
      case 'NYSC': return 'from-green-700 to-emerald-900';
      default: return 'from-gray-700 to-gray-900';
    }
  };
  return (
    <div className={`relative w-full h-full bg-gradient-to-br ${getGradient()} flex items-center justify-center overflow-hidden`}>
      <div className="absolute inset-0 bg-white/5 opacity-10"></div>
      <Newspaper className="text-white/40" size={48} />
    </div>
  );
};

const NewsCard: React.FC<{ 
  news: NewsItem; 
  onRead: () => void; 
  onDiscuss?: () => void;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  isRelevant?: boolean;
  onTagClick?: (tag: string) => void;
}> = ({ news, onRead, onDiscuss, isBookmarked, onToggleBookmark, isRelevant, onTagClick }) => {
  return (
    <motion.div layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02, y: -5 }}
      className="bg-white dark:bg-gray-800 rounded-[32px] overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-blue-500/10 transition-all group flex flex-col h-full border border-gray-100 dark:border-gray-700 relative"
    >
      {isRelevant && (
        <div className="absolute top-4 left-4 z-30 flex items-center gap-1.5 px-3 py-1 bg-emerald-500 text-white rounded-full text-[8px] font-black uppercase tracking-widest shadow-lg">
          <Sparkles size={10} fill="currentColor" /> For You
        </div>
      )}
      <button 
        onClick={(e) => { e.stopPropagation(); onToggleBookmark(news.id); }} 
        className={`absolute top-4 right-4 z-30 p-3 rounded-2xl backdrop-blur-md transition-all active:scale-75 shadow-lg ${
          isBookmarked 
            ? 'bg-blue-600 text-white ring-4 ring-blue-500/20' 
            : 'bg-black/20 text-white hover:bg-black/40'
        }`}
      >
        {isBookmarked ? <BookmarkCheck size={20} /> : <Bookmark size={20} />}
      </button>
      <div className="relative h-48 md:h-56 overflow-hidden">
        <UniversityAvatar title={news.title} category={news.category} />
        <div className="absolute bottom-4 left-4 z-20">
          <div className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-[9px] font-black text-white uppercase tracking-widest border border-white/10">{news.category}</div>
        </div>
      </div>
      <div className="p-6 md:p-8 flex flex-col flex-1">
        <div className="flex items-center text-blue-600/50 text-[9px] font-black uppercase tracking-widest mb-4"><Calendar size={12} className="mr-2" />{news.date}</div>
        <h3 className="text-lg md:text-xl font-black text-gray-900 dark:text-white mb-4 group-hover:text-blue-600 transition-colors leading-tight line-clamp-2">{news.title}</h3>
        <p className="text-gray-500 text-sm leading-relaxed font-medium line-clamp-3 mb-6">{news.excerpt}</p>
        
        {news.tags && news.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {news.tags.map(tag => (
              <button 
                key={tag}
                onClick={(e) => { e.stopPropagation(); onTagClick?.(tag); }}
                className="px-2.5 py-1 bg-gray-100 dark:bg-gray-700/50 hover:bg-blue-50 dark:hover:bg-blue-900/30 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg text-[9px] font-black uppercase tracking-widest transition-colors border border-transparent hover:border-blue-200 dark:hover:border-blue-800"
              >
                #{tag}
              </button>
            ))}
          </div>
        )}

        <div className="mt-auto pt-6 border-t border-gray-50 dark:border-gray-700 space-y-3">
          <div className="flex gap-2">
            <button onClick={onRead} className="flex-1 flex items-center justify-center gap-2 p-4 bg-gray-900 text-white dark:bg-white dark:text-black rounded-2xl font-black text-[10px] uppercase tracking-widest hover:scale-[1.02] transition-all group/btn">
              Read Report <ArrowRight size={14} />
            </button>
            {onDiscuss && (
              <button onClick={(e) => { e.stopPropagation(); onDiscuss(); }} className="p-4 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-cyan-400 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-100 transition-all flex items-center gap-2">
                <Brain size={16} /> Discuss
              </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

interface NewsGridProps {
  user: any;
  onDiscussAi?: (news: NewsItem) => void;
  onReadArticle: (news: NewsItem) => void;
  onLoginRequest: () => void;
  initialFilter?: UniversityCategory | 'Bookmarks';
}

const NewsGrid: React.FC<NewsGridProps> = ({ user, onDiscussAi, onReadArticle, onLoginRequest, initialFilter = 'All' }) => {
  const [filter, setFilter] = useState<UniversityCategory | 'Bookmarks' | 'Latest' | 'Hot'>(initialFilter);
  const [newsList, setNewsList] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [visibleCount, setVisibleCount] = useState(INITIAL_VISIBLE_COUNT);
  const [searchQuery, setSearchQuery] = useState('');
  const [isQuotaModalOpen, setIsQuotaModalOpen] = useState(false);
  const [usagePercent, setUsagePercent] = useState(0);
  
  // SYNC METADATA
  const [lastAutoSyncTime, setLastAutoSyncTime] = useState<string>('Syncing...');
  const [totalArchivedCount, setTotalArchivedCount] = useState(0);
  const [isStale, setIsStale] = useState(false);

  const loadLocalNews = useCallback(async () => {
    console.log("NewsGrid: loadLocalNews starting...");
    const cloudNews = await getCloudNews();
    console.log("NewsGrid: getCloudNews returned", cloudNews.length, "items");
    setNewsList(cloudNews);
    setTotalArchivedCount(cloudNews.length);
    
    const savedBookmarks = JSON.parse(localStorage.getItem('campusai_bookmarks') || '[]');
    setBookmarks(savedBookmarks);

    const lastAutoSync = localStorage.getItem('campusai_last_auto_sync_ts');
    console.log("NewsGrid: lastAutoSync from storage:", lastAutoSync);
    
    const profile = getLocalProfile();
    if (!profile.is_premium) {
      setUsagePercent(Math.min(100, ((profile.daily_requests || 0) / DAILY_LIMIT) * 100));
    }

    if (lastAutoSync) {
      const ts = parseInt(lastAutoSync);
      const diff = Date.now() - ts;
      setIsStale(diff > TWELVE_HOURS_MS);
      
      const mins = Math.round(diff / 60000);
      if (mins < 60) setLastAutoSyncTime(`${mins}m ago`);
      else setLastAutoSyncTime(`${Math.round(mins/60)}h ago`);
    } else {
      setLastAutoSyncTime('Initial Pull Needed');
    }
    console.log("NewsGrid: loadLocalNews finished.");
  }, []);

  const handleSyncLiveNews = async (isAuto = false) => {
    if (!user) { if(!isAuto) onLoginRequest(); return; }
    if (isLoading) return;

    // Prevent same-session spamming even if global check passes
    const sessionLock = sessionStorage.getItem('campusai_sync_lock');
    if (sessionLock && isAuto) return;

    // Quota Check for manual sync
    if (!isAuto) {
      const profile = getLocalProfile();
      if (!profile.is_premium) {
        const { allowed } = await checkAndIncrementRequests(user.uid);
        if (!allowed) {
          setIsQuotaModalOpen(true);
          return;
        }
      }
    }
    
    setIsLoading(true);
    try {
      // 1. Check Global Intelligence Signal (Prevent redundant AI consumption)
      const { lastSync } = await getGlobalSyncMetadata();
      const SIX_HOURS = 6 * 60 * 60 * 1000;
      const timeSinceLastSync = Date.now() - lastSync;

      if (isAuto && timeSinceLastSync < SIX_HOURS) {
        console.log("NewsGrid: Intelligence cycle recent, skipping automated pull.");
        setIsLoading(false);
        sessionStorage.setItem('campusai_sync_lock', 'active');
        return;
      }

      // 2. Pre-emptive Lock (Prevent race conditions from concurrent users)
      if (isAuto) {
        await updateGlobalSyncMetadata(Date.now());
      }

      const liveData = await fetchLiveNews();
      if (liveData && liveData.length > 0) {
        await archiveNewsItems(liveData);
        const now = Date.now();
        localStorage.setItem('campusai_last_auto_sync_ts', now.toString());
        if (!isAuto) await updateGlobalSyncMetadata(now);
        
        loadLocalNews();
        sessionStorage.setItem('campusai_sync_lock', 'active');
        if (!isAuto) alert("Intelligence Cycle Complete: New data points synchronized.");
      } else {
        if (!isAuto) alert("No new intelligence found in the current cycle. Check API keys in Admin Panel.");
      }
    } catch (e) {
      console.error(e);
      if (!isAuto) alert("Sync failed. Check console for details.");
    } finally { setIsLoading(false); }
  };

  useEffect(() => {
    loadLocalNews();
    
    // Strict 12-Hour Cycle Monitor
    const checkCycle = () => {
      const lastAuto = localStorage.getItem('campusai_last_auto_sync_ts');
      const ts = lastAuto ? parseInt(lastAuto) : 0;
      if (Date.now() - ts > TWELVE_HOURS_MS) {
        if (user) handleSyncLiveNews(true);
      }
    };

    checkCycle();
    const interval = setInterval(checkCycle, 60000);
    
    // Sync on refresh if enabled (default true)
    if (localStorage.getItem('campusai_sync_on_refresh') !== 'false') {
      if (user) {
        console.log("NewsGrid: syncOnRefresh triggered for authenticated user.");
        handleSyncLiveNews(true);
      }
    }

    window.addEventListener('campusai_news_updated', loadLocalNews);
    return () => {
      window.removeEventListener('campusai_news_updated', loadLocalNews);
      clearInterval(interval);
    };
  }, [user?.uid]);

  const filteredNews = useMemo(() => {
    if (!newsList.length) return [];

    // 1. Handle Latest filter — sort by date descending
    if (filter === 'Latest') {
      return [...newsList].sort((a, b) => {
        const dateA = new Date(a.date).getTime();
        const dateB = new Date(b.date).getTime();
        return isNaN(dateB) || isNaN(dateA) ? 0 : dateB - dateA;
      });
    }

    // 2. Handle Hot filter — prioritize JAMB, admissions, strike news (high-interest categories)
    if (filter === 'Hot') {
      const hotCategories = ['JAMB', 'National', 'Federal', 'NYSC'];
      const hotKeywords = ['cutoff', 'admission', 'result', 'strike', 'post-utme', 'jamb', 'list', 'release', 'urgent', 'breaking', 'deadline'];
      return [...newsList].sort((a, b) => {
        const scoreItem = (item: NewsItem) => {
          let score = 0;
          if (hotCategories.includes(item.category)) score += 3;
          const titleLower = item.title.toLowerCase();
          hotKeywords.forEach(kw => { if (titleLower.includes(kw)) score += 2; });
          return score;
        };
        return scoreItem(b) - scoreItem(a);
      });
    }

    // 3. Apply Search and Category Filter
    let baseFiltered = newsList.filter(item => {
      const catMatch = filter === 'All' ? true : filter === 'Bookmarks' ? bookmarks.includes(item.id) : item.category === filter;
      const searchMatch = searchQuery.trim() === '' || 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.tags && item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())));
      return catMatch && searchMatch;
    });

    // Sort by latest date when a specific category is selected
    if (filter !== 'All' && filter !== 'Bookmarks') {
      baseFiltered = [...baseFiltered].sort((a, b) => {
        const dateA = new Date(a.date).getTime();
        const dateB = new Date(b.date).getTime();
        return isNaN(dateB) || isNaN(dateA) ? 0 : dateB - dateA;
      });
    }

    // 4. Apply Role-Based Weighting (70% relevant, 30% others)
    if (user?.role && filter === 'All' && searchQuery.trim() === '') {
      const relevantCategories: UniversityCategory[] = [];
      if (user.role === 'Pre-Admission') relevantCategories.push('JAMB', 'Federal', 'State', 'National');
      if (user.role === 'In-Campus') relevantCategories.push('Federal', 'State', 'Private', 'Polytechnic', 'COE');
      if (user.role === 'Graduate/Alumni') relevantCategories.push('National', 'Private');
      if (user.role === 'School/Institution') relevantCategories.push('National', 'Federal', 'State');

      const relevant = baseFiltered.filter(n => relevantCategories.includes(n.category));
      const others = baseFiltered.filter(n => !relevantCategories.includes(n.category));
      return [...relevant, ...others];
    }

    return baseFiltered;
  }, [newsList, filter, bookmarks, searchQuery, user?.role]);

  return (
    <section id="news" className="py-12 relative z-10 news-grid">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between mb-12 gap-8">
        <div className="space-y-4 max-w-xl">
          <h2 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white tracking-tighter leading-tight">
            Campus Updates <br />
            <span className="text-cyan-400 font-black tracking-tight">(2026 Cycle)</span>
          </h2>
          
          <div className="flex flex-col gap-2.5">
             {/* ARCHIVED COUNT BADGE - Styled as per screenshot */}
             <div className="inline-flex items-center gap-2.5 px-5 py-2 bg-black/10 dark:bg-black/40 border border-gray-100 dark:border-white/10 rounded-full w-fit shadow-sm">
                <Box size={16} className="text-cyan-400" />
                <span className="text-sm font-black dark:text-white uppercase tracking-widest">
                  {totalArchivedCount} ARCHIVED
                </span>
             </div>

             {/* CLOUD ARCHIVE STATUS - Styled as per screenshot */}
             <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-500/5 dark:bg-emerald-500/5 border border-emerald-500/10 rounded-full w-fit">
                <div className={`w-1.5 h-1.5 rounded-full bg-emerald-500 ${isLoading ? 'animate-ping' : ''}`}></div>
                <span className="text-[9px] font-black uppercase text-emerald-600 dark:text-emerald-500/80 tracking-widest">
                  CLOUD ARCHIVE ACTIVE {lastAutoSyncTime && `• SYNCED ${lastAutoSyncTime.toUpperCase()}`}
                </span>
             </div>

             {usagePercent > 70 && (
                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-orange-500/5 border border-orange-500/10 rounded-full w-fit">
                   <Activity size={10} className="text-orange-500" />
                   <span className="text-[9px] font-black uppercase text-orange-600 tracking-widest">
                     Signal Capacity: {100 - Math.round(usagePercent)}% Remaining
                   </span>
                </div>
              )}
          </div>
          
          <p className="text-gray-500 dark:text-gray-400 font-bold text-lg mt-6">
            Investigative reports for the Nigerian scholar journey.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 w-full xl:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              type="text" 
              placeholder="Search news..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3.5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl text-xs font-bold outline-none focus:border-blue-500 transition-all shadow-sm"
            />
          </div>
          <div className="flex bg-white dark:bg-gray-800 p-1 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-x-auto no-scrollbar w-full sm:max-w-md">
            {/* Smart Filters */}
            <button key="Hot" onClick={() => setFilter('Hot' as any)} className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'Hot' ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'text-gray-500 hover:text-orange-500'}`}>
              <Flame size={11} /> Hot
            </button>
            <button key="Latest" onClick={() => setFilter('Latest' as any)} className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'Latest' ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/20' : 'text-gray-500 hover:text-cyan-500'}`}>
              <Timer size={11} /> Latest
            </button>
            {/* Divider */}
            <div className="w-px bg-gray-100 dark:bg-gray-700 mx-1 my-1.5 shrink-0" />
            {/* Category Filters */}
            {['All', 'Federal', 'State', 'Private', 'JAMB', 'Polytechnic', 'COE', 'National', 'Jobs', 'Scholarships', 'NYSC', 'Bookmarks'].map(cat => (
              <button key={cat} onClick={() => setFilter(cat as any)} className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === cat ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'text-gray-500 hover:text-blue-600'}`}>{cat}</button>
            ))}
          </div>
          <button 
            onClick={() => handleSyncLiveNews(false)} 
            disabled={isLoading} 
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-gray-900 dark:bg-white text-white dark:text-black rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 disabled:opacity-50 group border border-white/5 shrink-0"
          >
            {isLoading ? <RefreshCw className="animate-spin" size={14} /> : <Database size={14} className="group-hover:scale-110 transition-transform" />}
            {isLoading ? 'Syncing...' : 'Sync AI News'}
          </button>
        </div>
      </div>

      {(filter === 'Hot' || filter === 'Latest') && (
        <div className={`mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest ${filter === 'Hot' ? 'bg-orange-500/10 text-orange-500 border border-orange-500/20' : 'bg-cyan-500/10 text-cyan-500 border border-cyan-500/20'}`}>
          {filter === 'Hot' ? <Flame size={12} /> : <Timer size={12} />}
          {filter === 'Hot' ? 'Showing trending & high-interest reports' : 'Showing most recent reports first'}
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8">
        {filteredNews.slice(0, visibleCount).map(news => {
          const relevantCategories: UniversityCategory[] = [];
          if (user?.role === 'Pre-Admission') relevantCategories.push('JAMB', 'Federal', 'State', 'National', 'Scholarships');
          if (user?.role === 'In-Campus') relevantCategories.push('Federal', 'State', 'Private', 'Polytechnic', 'COE', 'Scholarships', 'Jobs');
          if (user?.role === 'Graduate/Alumni') relevantCategories.push('National', 'Private', 'Jobs', 'NYSC');
          if (user?.role === 'School/Institution') relevantCategories.push('National', 'Federal', 'State', 'Jobs');
          
          const isRelevant = relevantCategories.includes(news.category);

          return (
            <NewsCard 
              key={news.id} 
              news={news} 
              onRead={() => onReadArticle(news)} 
              onDiscuss={() => onDiscussAi?.(news)}
              isBookmarked={bookmarks.includes(news.id)} 
              isRelevant={isRelevant}
              onTagClick={(tag) => setSearchQuery(tag)}
              onToggleBookmark={() => {
                const current = JSON.parse(localStorage.getItem('campusai_bookmarks') || '[]');
                const updated = current.includes(news.id) ? current.filter((i: string) => i !== news.id) : [...current, news.id];
                localStorage.setItem('campusai_bookmarks', stringify(updated));
                setBookmarks(updated);
              }} 
            />
          );
        })}
      </div>
      
      <AnimatePresence>
        {filteredNews.length === 0 && !isLoading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-20 text-center space-y-4">
             <div className="w-20 h-20 bg-gray-50 dark:bg-gray-900 rounded-[32px] flex items-center justify-center mx-auto border border-gray-100 dark:border-gray-800">
                <Box size={32} className="text-gray-300" />
             </div>
             <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No Intelligence Matching Filter</p>
             <button onClick={() => setFilter('All')} className="text-blue-600 font-black text-[10px] uppercase underline">Reset Radar</button>
          </motion.div>
        )}
      </AnimatePresence>

      {filteredNews.length > visibleCount && (
        <div className="mt-12 text-center">
           <button onClick={() => setVisibleCount(v => v + REVEAL_STEP)} className="inline-flex items-center gap-2 px-10 py-4 bg-gray-50 dark:bg-gray-900 border-2 border-gray-100 dark:border-gray-800 rounded-3xl font-black text-[11px] uppercase tracking-widest hover:border-blue-600 transition-all">Reveal More Articles <Plus size={16}/></button>
        </div>
      )}

      <QuotaModal 
        isOpen={isQuotaModalOpen} 
        onClose={() => setIsQuotaModalOpen(false)} 
        onUpgrade={() => {
          setIsQuotaModalOpen(false);
          window.dispatchEvent(new CustomEvent('campusai_open_payment'));
        }} 
      />
    </section>
  );
};

export default NewsGrid;