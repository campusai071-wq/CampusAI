
import React, { useState, useEffect, useCallback } from 'react';
import { stringify } from '../services/utils';
import Navbar from './Navbar';
import Hero from './Hero';
import NewsGrid from './NewsGrid';
import FAQSection from './FAQSection';
import ChatPreview from './ChatPreview';
import SidePanel from './SidePanel';
import { AdmissionTimelineDisplay } from './AdmissionTimeline';
import AboutSection from './AboutSection';
import AdminPanel from './AdminPanel';
import UserSettingsModal from './UserSettingsModal';
import ChatInterface from './ChatInterface';
import NewsDetailView from './NewsDetailView';
import AuthModal from './AuthModal';
import ShareModal from './ShareModal';
import FeedbackModal from './FeedbackModal';
import ScholarPackModal from './ScholarPackModal';
import SupportModal from './SupportModal';
import LegalModal from './LegalModal';
import UniversityDirectory from './UniversityDirectory';
import TopRankings from './TopRankings';
import CutoffCalculator from './CutoffCalculator';
import StudentFeedback from './StudentFeedback';
import BillboardBanner from './BillboardBanner';
import ScholarJourney from './ScholarJourney';
import CGPACalculator from './CGPACalculator';
import TaskList from './TaskList';
import PremiumTools from './PremiumTools';
import ScholarshipAndJobs from './ScholarshipAndJobs';
import CBTCenterFinder from './CBTCenterFinder';
import MobileBottomNav from './MobileBottomNav';
import PremiumChannelBanner from './PremiumChannelBanner';
import InstallPrompt from './InstallPrompt';
import Footer from './Footer';
import Tour from './Tour';
import { BrowserRouter as Router, Routes, Route, useNavigate, useParams, useLocation } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import SEO from './SEO';
import { auth } from '../services/firebaseConfig';
import { slugify } from '../services/utils';
// @ts-ignore
import { signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { initializeUserProfile, subscribeToUserProfile, getLocalProfile, updateUserProfile } from '../services/userService';
import { AdminState, NewsItem, UserRole } from '../types';
import { WifiOff, Brain, Rocket, School, GraduationCap, Building2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getGlobalConfig } from '../services/dbService';

const AppContent: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { slug } = useParams();
  
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState<any>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showFab, setShowFab] = useState(false);
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | undefined>(undefined);
  const [activeArticle, setActiveArticle] = useState<NewsItem | null>(null);
  
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      return (localStorage.getItem('campusai_theme') as any) || 'light';
    } catch(e) { return 'light'; }
  });
  
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isScholarPackOpen, setIsScholarPackOpen] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState<{ type: 'pack' | 'refill' | 'tool'; amount: number; label: string; toolId?: string } | undefined>(undefined);
  const [legalModal, setLegalModal] = useState<{ isOpen: boolean; type: 'terms' | 'privacy' }>({ isOpen: false, type: 'terms' });
  const [initialAiPrompt, setInitialAiPrompt] = useState<string | undefined>(undefined);
  const [highlightedUni, setHighlightedUni] = useState<string | null>(null);

  // Admin Level 2 Auth State
  const [adminAuth, setAdminAuth] = useState({ isLoggedIn: false, email: null as string | null });
  const [socialLinks, setSocialLinks] = useState(() => {
    try {
      const saved = localStorage.getItem('campusai_social_links');
      return saved ? JSON.parse(saved) : { facebook: '', twitter: '', instagram: '', linkedin: '', youtube: '' };
    } catch {
      return { facebook: '', twitter: '', instagram: '', linkedin: '', youtube: '' };
    }
  });

  // STRICT ADMIN DETECTION: Only your verified email grants portal icon visibility
  const isAuthorizedAdmin = user?.email === '5ej852963@gmail.com';
  const adminState: AdminState = { 
    isLoggedIn: adminAuth.isLoggedIn, 
    email: adminAuth.email 
  };

  useEffect(() => {
    const handleScroll = () => setShowFab(window.scrollY > 200);
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    initializeUserProfile(); 

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => setUserCoords({ lat: position.coords.latitude, lng: position.coords.longitude }),
        (error) => console.warn("Geo restricted."),
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }

    const loadGlobalSettings = async () => {
      const config = await getGlobalConfig();
      if (config) {
        if (config.socials) {
          setSocialLinks(config.socials);
          localStorage.setItem('campusai_social_links', stringify(config.socials));
        }
        if (config.whatsapp) localStorage.setItem('campusai_whatsapp', config.whatsapp);
        if (config.supportEmail) localStorage.setItem('campusai_support_email', config.supportEmail);
        if (config.googleAdsEnabled !== undefined) localStorage.setItem('campusai_google_ads', config.googleAdsEnabled ? 'true' : 'false');
        if (config.flutterwaveKey) localStorage.setItem('campusai_flutterwave_key', config.flutterwaveKey);
        
        // Sync API Keys to localStorage for geminiService
        if (config.geminiKey) localStorage.setItem('campusai_gemini_key', config.geminiKey);
        if (config.featureKeys) localStorage.setItem('campusai_feature_keys', stringify(config.featureKeys));
        
        window.dispatchEvent(new Event('storage'));
      }
    };

    loadGlobalSettings();

    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener('online', goOnline);
    window.addEventListener('offline', goOffline);

    const handleQuotaUpdate = (e: any) => {
      const updatedProfile = e.detail;
      setUser((curr: any) => curr ? { ...curr, ...updatedProfile } : null);
    };
    window.addEventListener('campusai_quota_updated', handleQuotaUpdate);

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: any) => {
      if (firebaseUser) {
        const profile = await initializeUserProfile(firebaseUser);
        setUser({ ...firebaseUser, ...profile });
        subscribeToUserProfile(firebaseUser.uid, (updatedProfile) => {
           setUser((curr: any) => curr ? { ...curr, ...updatedProfile } : null);
        });
      }
    });

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('online', goOnline);
      window.removeEventListener('offline', goOffline);
      window.removeEventListener('campusai_quota_updated', handleQuotaUpdate);
      unsubscribe();
    };
  }, []);

  const navigateToAi = useCallback((prompt?: string) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    setInitialAiPrompt(prompt);
    setCurrentPage('ai');
    window.scrollTo(0, 0);
  }, [user]);

  useEffect(() => {
    const handleOpenPayment = (e: any) => {
      if (e.detail && typeof e.detail === 'object') {
        setPaymentConfig(e.detail);
      } else {
        setPaymentConfig(undefined); // Default to Scholar Pack
      }
      setIsScholarPackOpen(true);
    };

    const handleOpenAi = (e: any) => {
      navigateToAi(e.detail);
    };

    const handleOpenShare = () => {
      setIsShareOpen(true);
    };

    const handleOpenFeedback = () => {
      setIsFeedbackOpen(true);
    };

    window.addEventListener('campusai_open_payment', handleOpenPayment);
    window.addEventListener('campusai_open_ai', handleOpenAi);
    window.addEventListener('campusai_open_share', handleOpenShare);
    window.addEventListener('campusai_open_feedback', handleOpenFeedback);

    return () => {
      window.removeEventListener('campusai_open_payment', handleOpenPayment);
      window.removeEventListener('campusai_open_ai', handleOpenAi);
      window.removeEventListener('campusai_open_share', handleOpenShare);
      window.removeEventListener('campusai_open_feedback', handleOpenFeedback);
    };
  }, [navigateToAi]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try { localStorage.setItem('campusai_theme', theme); } catch(e) {}
  }, [theme]);

  const handleAuthSuccess = async (email: string, role?: UserRole) => {
    if (auth.currentUser) {
      const profile = await initializeUserProfile(auth.currentUser, role);
      setUser({ ...auth.currentUser, ...profile });
    }
    setIsAuthModalOpen(false);
  };

  const handleLogout = async () => {
    await signOut(auth);
    localStorage.removeItem('campusai_user_session');
    setUser(null);
    setAdminAuth({ isLoggedIn: false, email: null });
    setCurrentPage('home');
  };

  const openArticle = (article: NewsItem) => {
    const slug = article.slug || slugify(article.title);
    setActiveArticle(article);
    navigate(`/news/${slug}`, { state: { article } });
    window.scrollTo(0, 0);
  };

  const closeArticle = () => {
    setActiveArticle(null);
    navigate('/');
  };

  const handleSelectUni = (slug: string) => {
    setHighlightedUni(slug);
    setCurrentPage('home');
    setTimeout(() => {
      document.getElementById('directory')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 ${theme === 'dark' ? 'bg-gray-950 text-white' : 'bg-gray-50 text-gray-900'}`}>
      
      <AnimatePresence>
        {!isOnline && (
          <motion.div initial={{ y: -100 }} animate={{ y: 0 }} exit={{ y: -100 }} className="fixed top-0 left-0 right-0 z-[1000] bg-orange-600 text-white px-4 py-2.5 flex items-center justify-center gap-3 shadow-2xl">
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">Offline Shield Active — Simulation Mode</span>
          </motion.div>
        )}
      </AnimatePresence>

      <Navbar 
        onNavigate={(p) => {
          if (p === 'ai') navigateToAi();
          else if (p === 'settings') setIsSettingsOpen(true);
          else {
            setCurrentPage(p);
            navigate('/');
          }
        }} 
        currentPage={currentPage} 
        user={user}
        admin={adminState}
        theme={theme}
        onThemeToggle={() => setTheme(t => t === 'light' ? 'dark' : 'light')}
        onLoginRequest={() => setIsAuthModalOpen(true)}
        onShareRequest={() => setIsShareOpen(true)}
      />

      <AnimatePresence>
        {showFab && !location.pathname.includes('/news/') && currentPage !== 'ai' && currentPage !== 'admin' && (
          <motion.button
            initial={{ scale: 0, opacity: 0, x: 50 }} animate={{ scale: 1, opacity: 1, x: 0 }} exit={{ scale: 0, opacity: 0, x: 50 }}
            onClick={() => navigateToAi()}
            className="fixed bottom-[164px] md:bottom-24 right-4 md:right-8 z-[999] w-14 h-14 md:w-16 md:h-16 bg-blue-600 text-white rounded-full shadow-[0_25px_60px_rgba(37,99,235,0.7)] flex items-center justify-center group border-4 border-white dark:border-gray-900 transition-all font-black"
          >
            <Brain size={28} className="md:w-8 md:h-8" />
          </motion.button>
        )}
      </AnimatePresence>

      <main className="pb-40 md:pb-24">
        <Routes>
          <Route path="/" element={
            <>
              {currentPage === 'home' && (
                <>
                  <Hero onSearch={() => {}} onAskAI={() => navigateToAi()} />
                  
                  {/* Lifecycle Stages Navigator */}
                  <div className="container mx-auto px-4 md:px-8 relative z-30 py-12">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {[
                        { role: 'Pre-Admission', icon: <Rocket size={24} />, label: 'Admission Help', color: 'bg-blue-600' },
                        { role: 'In-Campus', icon: <School size={24} />, label: 'Campus Tools', color: 'bg-emerald-600' },
                        { role: 'Graduate/Alumni', icon: <GraduationCap size={24} />, label: 'Career Path', color: 'bg-purple-600' },
                        { role: 'School/Institution', icon: <Building2 size={24} />, label: 'Admin Suite', color: 'bg-orange-600' }
                      ].map((stage) => (
                        <motion.div 
                          key={stage.role}
                          whileHover={{ y: -5 }}
                          className="bg-white dark:bg-gray-900 p-6 rounded-[32px] border border-gray-100 dark:border-gray-800 shadow-xl flex flex-col items-center text-center group cursor-pointer"
                          onClick={() => {
                            if (!user) setIsAuthModalOpen(true);
                            else {
                              updateUserProfile({ role: stage.role as any });
                              window.scrollTo({ top: document.getElementById('news')?.offsetTop || 0, behavior: 'smooth' });
                            }
                          }}
                        >
                          <div className={`w-14 h-14 ${stage.color} text-white rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                            {stage.icon}
                          </div>
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{stage.role}</h4>
                          <p className="text-sm font-black dark:text-white">{stage.label}</p>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  <div className="container mx-auto px-4 md:px-8 py-20 relative z-20">
                    <div className="flex flex-col lg:flex-row gap-12 xl:gap-16">
                      <div className="w-full lg:w-[65%] space-y-24">
                        <NewsGrid user={user} onReadArticle={openArticle} onDiscussAi={(n) => navigateToAi(`Discuss update: ${n.title}`)} onLoginRequest={() => setIsAuthModalOpen(true)} />
                        <AdmissionTimelineDisplay isPremium={user?.is_premium} />
                      </div>
                      <aside className="w-full lg:w-[35%] lg:sticky lg:top-32 h-fit space-y-8 z-10">
                        <SidePanel />
                      </aside>
                    </div>
                  </div>

                  <div className="container mx-auto px-4 md:px-8 py-20 relative z-20">
                        <CutoffCalculator user={user} onLoginRequest={() => setIsAuthModalOpen(true)} onDiscussWithAI={navigateToAi} />
                  </div>

                  <div className="container mx-auto px-4 md:px-8 py-20 relative z-20">
                    <div className="flex flex-col lg:flex-row gap-12 xl:gap-16">
                      <div className="w-full space-y-24">
                        <CGPACalculator user={user} isPremium={user?.is_premium} onUpgrade={() => setIsScholarPackOpen(true)} />
                        
                        <section className="py-12 relative z-30">
                          <div className="container mx-auto">
                            <TaskList />
                          </div>
                        </section>
                        
                        <PremiumTools 
                          isPremium={user?.is_premium} 
                          onUpgrade={() => setIsScholarPackOpen(true)} 
                          onPayPerUse={(tool) => {
                            const event = new CustomEvent('campusai_open_payment', { detail: { type: 'tool', amount: tool.price, label: tool.name, toolId: tool.id } });
                            window.dispatchEvent(event);
                          }}
                        />
                        <UniversityDirectory 
                          externalHighlight={highlightedUni} 
                          onClearHighlight={() => setHighlightedUni(null)} 
                          isPremium={user?.is_premium}
                          onUpgrade={() => setIsScholarPackOpen(true)}
                        />
                        <CBTCenterFinder userCoords={userCoords} onLoginRequest={() => setIsAuthModalOpen(true)} />
                        <ScholarJourney role={user?.role} />
                      </div>
                    </div>
                  </div>
                  <TopRankings onSelectUni={handleSelectUni} />
                  <BillboardBanner />
                  <ChatPreview onFullAccess={() => navigateToAi()} />
                  <StudentFeedback />
                  <FAQSection />
                  <AboutSection />
                </>
              )}

              {currentPage === 'ai' && (
                <div className="container mx-auto px-0 md:px-8 pt-24 md:pt-32 pb-20 min-h-screen">
                  <ChatInterface 
                    user={user} admin={adminState} 
                    onBack={() => setCurrentPage('home')} 
                    initialPrompt={initialAiPrompt} onClearPrompt={() => setInitialAiPrompt(undefined)}
                    onLoginRequest={() => setIsAuthModalOpen(true)} userCoords={userCoords}
                  />
                </div>
              )}

              {currentPage === 'federal' && <div className="pt-32"><UniversityDirectory initialCategory="Federal" /></div>}
              {currentPage === 'state' && <div className="pt-32"><UniversityDirectory initialCategory="State" /></div>}
              {currentPage === 'polytechnic' && <div className="pt-32"><UniversityDirectory initialCategory="Polytechnic" /></div>}
              {currentPage === 'coe' && <div className="pt-32"><UniversityDirectory initialCategory="COE" /></div>}
              {currentPage === 'national' && <div className="pt-32"><UniversityDirectory initialCategory="National" /></div>}
              {currentPage === 'jamb' && <div className="pt-32 px-4 md:px-8"><NewsGrid user={user} onReadArticle={openArticle} onLoginRequest={() => setIsAuthModalOpen(true)} initialFilter="JAMB" /></div>}
              {currentPage === 'jobs' && <ScholarshipAndJobs type="job" />}
              {currentPage === 'scholarships' && <ScholarshipAndJobs type="scholarship" />}
              {currentPage === 'nysc' && <div className="pt-32 px-4 md:px-8"><NewsGrid user={user} onReadArticle={openArticle} onLoginRequest={() => setIsAuthModalOpen(true)} initialFilter="NYSC" /></div>}
              {currentPage === 'about' && <AboutSection />}
              
              {currentPage === 'admin' && isAuthorizedAdmin && (
                <div className="pt-24 min-h-screen bg-gray-900">
                  <AdminPanel 
                    isOpen={true} 
                    onClose={() => setCurrentPage('home')} 
                    admin={adminState} 
                    onAdminLogin={(email) => setAdminAuth({ isLoggedIn: true, email })} 
                    onAdminLogout={handleLogout}
                    onSocialUpdate={(links) => {
                      setSocialLinks(links);
                      localStorage.setItem('campusai_social_links', stringify(links));
                    }}
                    systemStatus={{ gemini: 'online', firebase: 'online' }}
                  />
                </div>
              )}
            </>
          } />
          
          <Route path="/universities/:slug" element={
            <>
              <Hero onSearch={() => {}} onAskAI={() => navigateToAi()} />
              <div className="container mx-auto px-4 md:px-8 py-20 relative z-20">
                <div className="flex flex-col lg:flex-row gap-12 xl:gap-16">
                  <div className="w-full lg:w-[65%] space-y-24">
                    <UniversityDirectory 
                      isPremium={user?.is_premium}
                      onUpgrade={() => setIsScholarPackOpen(true)}
                    />
                  </div>
                  <aside className="w-full lg:w-[35%] lg:sticky lg:top-32 h-fit space-y-8 z-10">
                    <SidePanel />
                  </aside>
                </div>
              </div>
            </>
          } />
          <Route path="/news/:slug" element={
            <div className="container mx-auto px-0 md:px-8 pt-24 md:pt-32 pb-20 min-h-screen">
              <NewsDetailView 
                user={user} 
                onClose={closeArticle} onLoginRequest={() => setIsAuthModalOpen(true)}
                relatedNews={[]} onSelectRelated={openArticle} 
              />
            </div>
          } />
        </Routes>
      </main>

      <Footer 
        onNavigate={setCurrentPage} 
        onOpenLegal={(type) => setLegalModal({ isOpen: true, type })} 
        onOpenSupport={() => setIsSupportOpen(true)} 
        isAdmin={isAuthorizedAdmin} 
        socialLinks={socialLinks} 
      />
      
      <MobileBottomNav activeTab={currentPage} onNavigate={(p) => {
        if (p === 'ai') navigateToAi();
        else if (p === 'settings') setIsSettingsOpen(true);
        else setCurrentPage(p);
      }} />
      
      <PremiumChannelBanner />
      <InstallPrompt />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onSuccess={handleAuthSuccess} />
      <UserSettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        theme={theme} onThemeChange={setTheme} onLogout={handleLogout}
        onLoginRequest={() => setIsAuthModalOpen(true)}
      />
      <ShareModal isOpen={isShareOpen} onClose={() => setIsShareOpen(false)} />
      <FeedbackModal isOpen={isFeedbackOpen} onClose={() => setIsFeedbackOpen(false)} />
      <ScholarPackModal isOpen={isScholarPackOpen} onClose={() => setIsScholarPackOpen(false)} user={user} paymentConfig={paymentConfig} />
      <SupportModal isOpen={isSupportOpen} onClose={() => setIsSupportOpen(false)} onNavigateAI={() => navigateToAi()} />
      <LegalModal isOpen={legalModal.isOpen} type={legalModal.type} onClose={() => setLegalModal({ ...legalModal, isOpen: false })} />
      <Tour />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HelmetProvider>
      <Router>
        <SEO />
        <AppContent />
      </Router>
    </HelmetProvider>
  );
};

export default App;
