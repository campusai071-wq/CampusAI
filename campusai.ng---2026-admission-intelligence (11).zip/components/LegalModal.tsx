
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShieldCheck, FileText, Lock, Globe, Scale, AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'terms' | 'privacy';
}

const LegalModal: React.FC<LegalModalProps> = ({ isOpen, onClose, type }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            onClick={onClose} 
            className="absolute inset-0 bg-black/90 backdrop-blur-xl" 
          />
          <motion.div 
            initial={{ scale: 0.9, y: 30, opacity: 0 }} 
            animate={{ scale: 1, y: 0, opacity: 1 }} 
            exit={{ scale: 0.9, y: 30, opacity: 0 }} 
            className="relative bg-white dark:bg-gray-950 w-full max-w-3xl rounded-[32px] md:rounded-[48px] overflow-y-auto max-h-[90vh] no-scrollbar shadow-[0_32px_80px_rgba(0,0,0,0.5)] flex flex-col border border-white/10"
          >
            {/* Header */}
            <div className="p-8 md:p-10 bg-gray-900 text-white flex justify-between items-center border-b border-white/5 shrink-0 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-40 h-40 bg-blue-600/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
               <div className="flex items-center gap-5 relative z-10">
                <div className="w-14 h-14 bg-blue-600 rounded-[22px] flex items-center justify-center shadow-2xl border border-blue-400/20">
                  {type === 'terms' ? <Scale size={28} /> : <Lock size={28} />}
                </div>
                <div>
                  <h3 className="text-2xl font-black tracking-tight uppercase">
                    {type === 'terms' ? 'Terms of Service' : 'Privacy Protocol'}
                  </h3>
                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.3em]">Revision: Feb 2026.1</p>
                </div>
              </div>
              <button onClick={onClose} className="p-2.5 bg-white/5 hover:bg-white/10 rounded-full transition-all active:scale-90"><X size={24} /></button>
            </div>

            {/* Content Body */}
            <div className="p-8 md:p-14 overflow-y-auto no-scrollbar space-y-10 text-gray-600 dark:text-gray-400">
              {type === 'terms' ? (
                <>
                  <div className="p-6 bg-blue-50 dark:bg-blue-900/10 rounded-3xl border border-blue-100 dark:border-blue-800/50 flex gap-4">
                    <AlertTriangle className="text-blue-600 shrink-0" size={24} />
                    <p className="text-xs font-bold text-blue-900 dark:text-blue-200 leading-relaxed">
                      PLEASE READ: CampusAI.ng is an independent AI research platform. We are NOT the official JAMB portal. Always cross-verify critical deadlines with the official government domain.
                    </p>
                  </div>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <FileText size={18} className="text-blue-500" /> 1. Service Scope
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      By utilizing this "Intelligence Engine," you acknowledge that outputs are generated via Google Gemini Neural Networks. We provide high-probability guidance for the 2026 Nigerian admission cycle, including aggregate calculations and cutoff mark predictions.
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <Globe size={18} className="text-cyan-500" /> 2. Data Accuracy & Hallucination
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      While our Strategist Node is grounded in real-time data, AI models may occasionally hallucinate. CampusAI accepts no liability for registration errors or missed deadlines. You are responsible for finalizing your registration on the <strong>official JAMB domain</strong> before Feb 28, 2026.
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <ShieldCheck size={18} className="text-emerald-500" /> 3. Service Access
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      CampusAI.ng provides unlimited AI Strategist access for the 2026 admission cycle. We reserve the right to modify access levels to maintain system stability and fair usage across our network.
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <ShieldAlert size={18} className="text-red-500" /> 4. Blacklisting
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      Unauthorized scraping, bot attacks, or attempts to bypass our security systems will result in a permanent hardware-level ban from our Federated Intelligence Network.
                    </p>
                  </section>
                </>
              ) : (
                <>
                  <div className="p-6 bg-emerald-50 dark:bg-emerald-900/10 rounded-3xl border border-emerald-100 dark:border-emerald-800/50 flex gap-4">
                    <CheckCircle2 className="text-emerald-600 shrink-0" size={24} />
                    <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200 leading-relaxed">
                      Your privacy is architected into the system. We use 256-bit encryption for all cloud profiles and journey logs.
                    </p>
                  </div>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <Lock size={18} className="text-blue-500" /> 1. Data Collection
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      We collect: Display Name, Email (for cloud sync), and academic grades. We do NOT store your passwords (handled by Firebase Secure Auth) or credit card details (handled by Flutterwave).
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <Globe size={18} className="text-emerald-500" /> 2. Intelligence Grounding
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      When using the "Map Finder," your GPS coordinates are sent over an encrypted bridge to Google Maps API to locate CBT centers. This data is never stored on our long-term database nodes.
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <FileText size={18} className="text-blue-400" /> 3. Broadcast Communication
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      By providing your email, you consent to receive critical "Admission Intel" broadcasts. These alerts are strictly restricted to 2026 registration updates and institutional news. You may opt-out via the "Profile" tab.
                    </p>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-gray-900 dark:text-white font-black uppercase text-sm tracking-widest flex items-center gap-3">
                      <Scale size={18} className="text-orange-500" /> 4. Data Deletion
                    </h4>
                    <p className="text-sm leading-relaxed font-medium">
                      Scholars may request full data erasure from our cloud nodes at any time by contacting our command desk at support@campusai.ng.
                    </p>
                  </section>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="p-8 md:p-10 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 shrink-0 text-center">
               <button 
                onClick={onClose} 
                className="w-full md:w-auto px-16 py-5 bg-gray-900 dark:bg-blue-600 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] hover:scale-105 active:scale-95 transition-all shadow-2xl"
               >
                 I Consent & Accept Logic
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default LegalModal;
