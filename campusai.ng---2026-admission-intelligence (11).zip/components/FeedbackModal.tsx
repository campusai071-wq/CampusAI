import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Sparkles, MessageSquare, Star, Award, GraduationCap } from 'lucide-react';
import { saveFeedback } from '../services/dbService';
import { auth } from '../services/firebaseConfig';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;

    setIsSubmitting(true);
    try {
      const user = auth.currentUser;
      await saveFeedback({
        feedback,
        rating,
        userId: user?.uid,
        email: user?.email || undefined
      });
      
      setIsSuccess(true);
      setTimeout(() => {
        onClose();
        setIsSuccess(false);
        setFeedback('');
      }, 3000);
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      alert('Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            onClick={onClose} 
            className="absolute inset-0 bg-black/80 backdrop-blur-md" 
          />
          <motion.div 
            initial={{ scale: 0.9, y: 20, opacity: 0 }} 
            animate={{ scale: 1, y: 0, opacity: 1 }} 
            exit={{ scale: 0.9, y: 20, opacity: 0 }} 
            className="relative bg-white dark:bg-gray-950 w-full max-w-md rounded-[32px] md:rounded-[48px] overflow-hidden shadow-2xl"
          >
            <div className="p-8 md:p-10">
              <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors text-gray-400">
                <X size={24} />
              </button>

              {isSuccess ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="w-20 h-20 bg-emerald-500 rounded-[28px] flex items-center justify-center text-white mx-auto mb-6 shadow-xl shadow-emerald-500/30">
                    <Award size={36} />
                  </div>
                  <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-2">Journey Shared!</h3>
                  <p className="text-gray-500 dark:text-gray-400 font-medium leading-relaxed">
                    Thank you for sharing your scholar journey. Your feedback helps us build the future of Nigerian admissions.
                  </p>
                </motion.div>
              ) : (
                <>
                  <div className="w-20 h-20 bg-indigo-600 rounded-[28px] flex items-center justify-center text-white mx-auto mb-6 shadow-xl shadow-indigo-500/30">
                    <GraduationCap size={36} />
                  </div>

                  <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-2 text-center">Share Your Journey</h3>
                  <p className="text-gray-500 dark:text-gray-400 font-medium mb-8 leading-relaxed text-sm text-center">
                    How has CampusAI helped you in your 2026 admission journey? We'd love to hear your success story.
                  </p>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-3 block">Your Experience</label>
                      <textarea
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        placeholder="Tell us about your progress, challenges, or how CampusAI made a difference..."
                        className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 text-sm font-medium text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all min-h-[120px] resize-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-3 block">Rate Your Progress</label>
                      <div className="flex justify-between gap-2">
                        {[1, 2, 3, 4, 5].map((num) => (
                          <button
                            key={num}
                            type="button"
                            onClick={() => setRating(num)}
                            className={`flex-1 py-3 rounded-xl border transition-all flex items-center justify-center gap-1 ${
                              rating >= num 
                                ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400' 
                                : 'bg-white dark:bg-gray-950 border-gray-100 dark:border-gray-800 text-gray-300'
                            }`}
                          >
                            <Star size={14} fill={rating >= num ? 'currentColor' : 'none'} />
                            <span className="text-xs font-bold">{num}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={isSubmitting || !feedback.trim()}
                      className={`w-full py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all ${
                        isSubmitting 
                          ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed' 
                          : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 active:scale-95'
                      }`}
                    >
                      {isSubmitting ? <><Sparkles size={18} className="animate-spin" /> Submitting...</> : <><Send size={18} /> Send Feedback</>}
                    </button>
                  </form>
                </>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default FeedbackModal;
