
import React, { useState, useEffect } from 'react';
import { Home, School, Building2, Brain, Newspaper, Info, Settings, Menu, X, ShieldCheck, LogIn, ChevronDown, Share2, Moon, Sun, User, ShieldAlert, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getAsuuStrikeStatus } from '../services/geminiService';
import { AdminState } from '../types';
import { auth } from '../services/firebaseConfig';
import { updateUserProfile } from '../services/userService';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
  user: any;
  admin?: AdminState;
  onLoginRequest: () => void;
  onShareRequest: () => void;
  theme?: 'light' | 'dark';
  onThemeToggle?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPage, user, admin, onLoginRequest, onShareRequest, theme, onThemeToggle }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [asuuStatus, setAsuuStatus] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    getAsuuStrikeStatus().then(status => setAsuuStatus(status?.status || 'Stable'));
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', icon: <Home size={18} />, id: 'home' },
    { name: 'Federal', icon: <School size={18} />, id: 'federal' },
    { name: 'State', icon: <Building2 size={18} />, id: 'state' },
    { name: 'AI Strategist', icon: <Brain size={18} />, id: 'ai', className: 'navbar-ai-button' },
    { name: 'JAMB', icon: <Newspaper size={18} />, id: 'jamb' },
    { name: 'About', icon: <Info size={18} />, id: 'about' },
  ];

  // STRICT SECURITY CHECK
  const isAuthorizedAdmin = user?.email === '5ej852963@gmail.com';

  const [isCategoriesOpen, setIsCategoriesOpen] = useState(false);

  const categories = [
    { name: 'Federal', id: 'federal' },
    { name: 'State', id: 'state' },
    { name: 'Private', id: 'private' },
    { name: 'Polytechnic', id: 'polytechnic' },
    { name: 'COE', id: 'coe' },
    { name: 'National', id: 'national' },
    { name: 'Jobs', id: 'jobs' },
    { name: 'Scholarships', id: 'scholarships' },
    { name: 'NYSC', id: 'nysc' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 w-full z-[100] transition-all duration-500 ease-in-out ${
      isScrolled 
        ? 'bg-white/70 dark:bg-gray-950/70 backdrop-blur-xl border-b border-gray-100 dark:border-gray-800 shadow-sm py-3' 
        : 'bg-gray-950 py-6 text-white'
    }`}>
      <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
        <div className="flex flex-col items-start cursor-pointer group" onClick={() => { onNavigate('home'); setIsMobileMenuOpen(false); }}>
          <span className={`text-xl md:text-2xl font-black tracking-tighter transition-colors ${isScrolled ? 'text-gray-900 dark:text-white' : 'text-white'}`}>
            Campus<span className="text-cyan-400">AI</span><span className="opacity-70 font-bold">.ng</span>
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <div className={`w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse`}></div>
            <span className={`text-[7px] font-black uppercase tracking-widest ${isScrolled ? 'text-gray-400' : 'text-white/50'}`}>
              {asuuStatus || 'Logic Engine v5.4'}
            </span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center space-x-6">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center space-x-2 font-black text-[10px] uppercase tracking-widest hover:text-cyan-400 transition-all ${item.className || ''} ${
                currentPage === item.id 
                  ? 'text-cyan-500' 
                  : (isScrolled ? 'text-gray-600 dark:text-gray-300' : 'text-white/90 hover:text-white')
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.name}</span>
            </button>
          ))}

          <div className="relative group" onMouseEnter={() => setIsCategoriesOpen(true)} onMouseLeave={() => setIsCategoriesOpen(false)}>
            <button className={`flex items-center space-x-2 font-black text-[10px] uppercase tracking-widest transition-all ${isScrolled ? 'text-gray-600 dark:text-gray-300' : 'text-white/90 hover:text-white'}`}>
              <Building2 size={18} />
              <span>Categories</span>
              <ChevronDown size={14} className={`transition-transform ${isCategoriesOpen ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
              {isCategoriesOpen && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }} className="absolute top-full left-0 mt-2 w-48 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden">
                  {categories.map(cat => (
                    <button key={cat.id} onClick={() => onNavigate(cat.id)} className="w-full text-left px-6 py-4 text-[10px] font-black uppercase tracking-widest text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-blue-600 transition-all">
                      {cat.name}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <div className="flex items-center gap-3 pl-4 border-l border-gray-200 dark:border-gray-800">
            {/* ADMIN ONLY ACCESS */}
            {isAuthorizedAdmin && (
               <button 
                 onClick={() => onNavigate('admin')} 
                 className={`p-2.5 rounded-xl transition-all bg-red-500/10 text-red-500 border border-red-500/20 animate-pulse`}
                 title="Open Architect Console"
               >
                 <ShieldAlert size={18} />
               </button>
            )}

            <button onClick={onThemeToggle} className={`p-2.5 rounded-xl transition-all ${isScrolled ? 'bg-gray-100 text-gray-600 dark:bg-gray-900' : 'bg-white/10 text-white'}`}>
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            
            {user ? (
               <div className="flex items-center gap-2">
                  {user.is_premium && (
                    <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-blue-600 text-white rounded-full text-[8px] font-black uppercase tracking-widest shadow-lg shadow-blue-600/20">
                      <Zap size={10} className="fill-white" /> Scholar Pack ⚡ Active
                    </div>
                  )}
                  <button onClick={() => onNavigate('settings')} className={`p-2.5 rounded-xl transition-all relative ${isScrolled ? 'bg-gray-100 dark:bg-gray-900' : 'bg-white/10 text-white'}`}>
                     <User size={18} />
                     <div className={`absolute -top-1 -right-1 w-3 h-3 border-2 border-white dark:border-gray-950 rounded-full ${user.is_premium ? 'bg-blue-500' : 'bg-emerald-500'}`}></div>
                  </button>
               </div>
            ) : (
               <button 
                onClick={onLoginRequest} 
                className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-600/20 active:scale-95 transition-all"
               >
                 <LogIn size={14} /> Sign In
               </button>
            )}
            
            <button onClick={() => onNavigate('settings')} className={`p-2.5 rounded-xl transition-all ${isScrolled ? 'bg-gray-100 dark:bg-gray-900' : 'bg-white/10 text-white'}`}>
              <Settings size={18} />
            </button>
          </div>
        </div>

        {/* Mobile Toggle */}
        <div className="lg:hidden flex items-center gap-2">
          {isAuthorizedAdmin && (
             <button onClick={() => onNavigate('admin')} className="p-2 bg-red-600 text-white rounded-lg">
               <ShieldAlert size={18} />
             </button>
          )}
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
            className={`p-2 rounded-lg ${isScrolled ? 'text-gray-900 dark:text-white' : 'text-white'}`}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: '100%' }} 
            className="lg:hidden fixed inset-0 z-[150] bg-white dark:bg-gray-950 flex flex-col p-6 overflow-y-auto"
          >
            <div className="mt-6 flex justify-between items-center px-2">
               <div className="flex flex-col">
                 <span className="text-xl font-black tracking-tighter dark:text-white">Campus<span className="text-cyan-400">AI</span></span>
                 {user?.is_premium && (
                   <span className="text-[8px] font-black uppercase tracking-widest text-blue-500">Scholar Pack ⚡ Active</span>
                 )}
               </div>
               <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 dark:text-white"><X size={24} /></button>
            </div>
            
            <div className="mt-12 flex flex-col gap-2">
               {isAuthorizedAdmin && (
                 <button 
                   onClick={() => { onNavigate('admin'); setIsMobileMenuOpen(false); }}
                   className="mb-4 w-full p-5 bg-red-600 text-white rounded-[24px] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl"
                 >
                   <ShieldAlert size={20} /> Access Architect Console
                 </button>
               )}
               {!user && (
                 <button 
                   onClick={() => { onLoginRequest(); setIsMobileMenuOpen(false); }}
                   className="mb-4 w-full p-5 bg-blue-600 text-white rounded-[24px] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl"
                 >
                   <LogIn size={20} /> Sign In to CampusAI
                 </button>
               )}
               
               {navItems.map(item => (
                  <button 
                    key={item.id} 
                    onClick={() => { onNavigate(item.id); setIsMobileMenuOpen(false); }} 
                    className={`p-5 text-left font-black text-sm border-b border-gray-50 dark:border-gray-900 flex items-center gap-4 ${
                      currentPage === item.id ? 'text-blue-600' : 'dark:text-white text-gray-700'
                    }`}
                  >
                    {item.icon} {item.name}
                  </button>
               ))}

               <div className="p-5 bg-gray-50 dark:bg-gray-900/50 rounded-3xl mt-4">
                 <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-4 px-2">Institutional Categories</p>
                 <div className="grid grid-cols-2 gap-2">
                   {categories.map(cat => (
                     <button 
                       key={cat.id} 
                       onClick={() => { onNavigate(cat.id); setIsMobileMenuOpen(false); }}
                       className="p-4 bg-white dark:bg-gray-800 rounded-2xl text-[10px] font-black uppercase tracking-widest text-gray-600 dark:text-gray-300 border border-gray-100 dark:border-gray-700"
                     >
                       {cat.name}
                     </button>
                   ))}
                 </div>
               </div>
               
               <button 
                 onClick={() => { onNavigate('settings'); setIsMobileMenuOpen(false); }} 
                 className="p-5 text-left font-black text-sm border-b border-gray-50 dark:border-gray-900 flex items-center gap-4 dark:text-white text-gray-700"
               >
                 <Settings size={20} /> Profile & Settings
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
