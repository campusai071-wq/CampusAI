import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, Search, Briefcase, GraduationCap, ExternalLink } from 'lucide-react';
import { getScholarships, getJobOpenings } from '../services/geminiService';
import { Scholarship, JobOpening } from '../types';

interface ScholarshipAndJobsProps {
  type: 'scholarship' | 'job';
}

const ScholarshipAndJobs: React.FC<ScholarshipAndJobsProps> = ({ type }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<(Scholarship | JobOpening)[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query) return;
    setLoading(true);
    try {
      if (type === 'scholarship') {
        const data = await getScholarships(query);
        setResults(data);
      } else {
        const data = await getJobOpenings(query);
        setResults(data);
      }
    } catch (error) {
      console.error('Search failed', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 md:px-8 py-24">
      <div className="max-w-4xl mx-auto mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-black mb-6 tracking-tight dark:text-white uppercase">
          {type === 'scholarship' ? 'Scholarship' : 'Job'} <span className="text-blue-600">Scout</span>
        </h1>
        <div className="flex gap-4 max-w-lg mx-auto">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Enter ${type === 'scholarship' ? 'field/category' : 'industry/field'}...`}
            className="flex-1 p-4 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 font-bold outline-none focus:border-blue-500"
          />
          <button
            onClick={handleSearch}
            disabled={loading}
            className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-blue-500 transition-all disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" /> : <Search size={20} />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {results.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-gray-900 p-8 rounded-[32px] border border-gray-100 dark:border-gray-800 shadow-sm"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center text-blue-600">
                {type === 'scholarship' ? <GraduationCap size={24} /> : <Briefcase size={24} />}
              </div>
              <div>
                <h3 className="font-black text-lg dark:text-white">{item.title}</h3>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                  {'provider' in item ? item.provider : item.company}
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6 line-clamp-3">{item.description}</p>
            <div className="flex justify-between items-center text-xs font-bold text-gray-400 uppercase tracking-widest">
              <span>Deadline: {item.deadline}</span>
              <a href={item.applyUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-blue-600 hover:underline">
                Apply <ExternalLink size={12} />
              </a>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ScholarshipAndJobs;
