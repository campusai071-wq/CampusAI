
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Lightbulb, Search, Sparkles, Lock, ArrowRight } from 'lucide-react';
import PremiumToolModal from './PremiumToolModal';

interface PremiumToolsProps {
  isPremium?: boolean;
  onUpgrade: () => void;
  onPayPerUse: (tool: { id: string; name: string; price: number }) => void;
}

const PremiumTools: React.FC<PremiumToolsProps> = ({ isPremium, onUpgrade, onPayPerUse }) => {
  const [selectedTool, setSelectedTool] = useState<any>(null);

  const tools = [
    {
      id: 'essay_polisher',
      name: 'Essay Polisher',
      description: 'AI-powered grammar and tone refinement for academic essays.',
      price: 100,
      icon: <FileText size={24} />,
      color: 'blue'
    },
    {
      id: 'topic_generator',
      name: 'Project Topic Generator',
      description: 'Generate unique, researchable project topics for any department.',
      price: 300,
      icon: <Lightbulb size={24} />,
      color: 'purple'
    },
    {
      id: 'research_assistant',
      name: 'Research Assistant',
      description: 'Find relevant references and structure your research paper.',
      price: 200,
      icon: <Search size={24} />,
      color: 'emerald'
    }
  ];

  return (
    <section id="premium-tools" className="py-20 bg-gray-50 dark:bg-gray-900/30 transition-colors premium-tools">
      {selectedTool && <PremiumToolModal tool={selectedTool} onClose={() => setSelectedTool(null)} />}
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100 dark:border-blue-800">
                <Sparkles size={12} />
                Specialized Intelligence
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white tracking-tighter leading-tight uppercase">
                Academic <span className="text-blue-600">Micro-Tools</span>
              </h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium max-w-md">
                Precision AI tools for specific academic tasks. Free for Scholar Pack members or pay-per-use.
              </p>
            </div>
            {!isPremium && (
              <button 
                onClick={onUpgrade}
                className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-600/20 hover:scale-105 transition-all"
              >
                Unlock All with Scholar Pack
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tools.map((tool) => (
              <motion.div 
                key={tool.id}
                whileHover={{ y: -5 }}
                className="bg-white dark:bg-gray-900 p-8 rounded-[32px] border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all relative overflow-hidden group"
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 shadow-lg transition-all group-hover:scale-110 ${
                  tool.color === 'blue' ? 'bg-blue-50 text-blue-600' :
                  tool.color === 'purple' ? 'bg-purple-50 text-purple-600' :
                  'bg-emerald-50 text-emerald-600'
                }`}>
                  {tool.icon}
                </div>
                
                <h3 className="text-xl font-black dark:text-white mb-3 uppercase tracking-tight">{tool.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 font-medium mb-8 leading-relaxed">
                  {tool.description}
                </p>

                <div className="flex items-center justify-between pt-6 border-t border-gray-50 dark:border-gray-800">
                  <div className="flex flex-col">
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Price</span>
                    <span className="text-lg font-black dark:text-white">₦{tool.price}</span>
                  </div>
                  
                  <button 
                    onClick={() => isPremium ? setSelectedTool(tool) : onPayPerUse(tool)}
                    className={`flex items-center gap-2 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                      isPremium 
                        ? 'bg-emerald-500 text-white hover:bg-emerald-600' 
                        : 'bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-800 dark:hover:bg-gray-700'
                    }`}
                  >
                    {isPremium ? 'Launch' : 'Unlock Now'}
                    <ArrowRight size={14} />
                  </button>
                </div>

                {isPremium && (
                  <div className="absolute top-6 right-6">
                    <div className="bg-emerald-500/10 text-emerald-500 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border border-emerald-500/20">
                      Included
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default PremiumTools;
