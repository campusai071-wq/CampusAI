import React, { useState, useEffect } from 'react';
import { stringify } from '../services/utils';
import { X, Save, Database, CheckCircle2, Lock, LogOut, ShieldCheck, Megaphone, DollarSign, Loader2, Activity, AlertCircle, Zap, ShieldAlert, Newspaper, Send, ShoppingBag, Tag, Key, Users, Trash2, Search, UserCheck, RefreshCw, Star, Mail, Copy, ExternalLink, Code, Smartphone, Monitor, Globe, Eye, EyeOff, Server, CreditCard, Clock, Check, Facebook, Twitter, Instagram, Linkedin, Youtube, MessageSquare, AlertTriangle, Brain, WifiOff, Rocket, Sun, ClipboardCopy, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AdminState, BillboardAd, NewsItem, UniversityCategory, UserProfile, BroadcastEmail, UserRole } from '../types';
import universityData from '../universities';
import { getPublishedNews, publishNewsUpdate, deleteNewsUpdate, getCloudAds, publishCloudAd, deleteCloudAd, getSubscribers, getPendingAds, approveAd, dispatchBroadcast, archiveNewsItems, getTickerHeadlines, saveTickerHeadlines, getCloudNews, getGlobalConfig, saveGlobalConfig, saveGlobalScoringSystem, getGlobalScoringSystem, db, getASUUStatusFromDB, saveASUUStatusToDB, updateGlobalSyncMetadata } from '../services/dbService';
import { fetchRecentUsers, getTotalUserCount } from '../services/userService';
import { generateNewsVideoScript, fetchLiveNews, getUniversityScoringSystem, generateMorningBriefing } from '../services/geminiService';
import { auth, MASTER_CONFIG } from '../services/firebaseConfig';

declare var process: any;

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  admin: AdminState;
  onAdminLogin: (email: string) => void;
  onAdminLogout: () => void;
  systemStatus?: { gemini: string; firebase: string };
  onSocialUpdate?: (links: { facebook: string; twitter: string; instagram: string; linkedin: string; youtube: string }) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose, admin, onAdminLogin, onAdminLogout, systemStatus, onSocialUpdate }) => {
  // STRICT SECURITY: Double-check authorized email
  if (admin.email !== '5ej852963@gmail.com' && admin.isLoggedIn) {
     return (
       <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/90 backdrop-blur-xl p-6">
         <div className="text-center space-y-4">
           <ShieldAlert size={64} className="text-red-500 mx-auto" />
           <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Access Denied</h2>
           <p className="text-gray-400 max-w-xs mx-auto text-sm">Your credentials are not authorized for the Architect Console.</p>
           <button onClick={onClose} className="px-8 py-3 bg-white text-black rounded-xl font-black uppercase text-xs">Return to Safety</button>
         </div>
       </div>
     );
  }

  const [firebaseConfig, setFirebaseConfig] = useState('');
  const [geminiKey, setGeminiKey] = useState('');
  const [featureKeys, setFeatureKeys] = useState<Record<string, string>>({
    chat: '', news: '', video: '', bio: '', courses: '', 
    cutoff: '', scoring: '', tracker: '', strike: '', maps: '',
    scholarship: '', jobs: '', nysc: '', maptiler: ''
  });
  const [flutterwaveKey, setFlutterwaveKey] = useState('');
  const [showGemini, setShowGemini] = useState(false);
  
  const [validationStatus, setValidationStatus] = useState<'idle' | 'validating' | 'valid' | 'invalid'>('idle');
  const [loginEmail, setLoginEmail] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [supportEmail, setSupportEmail] = useState('');
  const [premiumWhatsapp, setPremiumWhatsapp] = useState('');
  const [premiumTelegram, setPremiumTelegram] = useState('');
  const [googleAdsEnabled, setGoogleAdsEnabled] = useState(false);
  const [syncOnRefresh, setSyncOnRefresh] = useState(localStorage.getItem('campusai_sync_on_refresh') !== 'false');
  const [activeTab, setActiveTab] = useState<'infrastructure' | 'revenue' | 'content' | 'users' | 'communications' | 'analytics' | 'seo' | 'faq' | 'status' | 'briefing'>('infrastructure');
  const [briefing, setBriefing] = useState<any>(null);
  const [isBriefingLoading, setIsBriefingLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleGenerateBriefing = async () => {
    setIsBriefingLoading(true);
    try {
      const result = await generateMorningBriefing();
      setBriefing(result);
    } catch (e) {
      console.error('Briefing error:', e);
    } finally {
      setIsBriefingLoading(false);
    }
  };
  const [dbStatus, setDbStatus] = useState<'online' | 'blocked' | 'offline'>('online');
  
  // ASUU Status State
  const [asuuStatus, setAsuuStatus] = useState({ isActive: false, status: 'No Strike', summary: '', lastUpdated: '' });
  const [isUpdatingAsuu, setIsUpdatingAsuu] = useState(false);
  
  // SEO State
  const [seoConfig, setSeoConfig] = useState({
    title: 'CampusAI.ng - 2026 Nigerian Admission Intelligence',
    description: 'The ultimate companion for Nigerian scholars in the 2026 admission cycle.',
    keywords: 'JAMB 2026, Post-UTME, University Admissions, Nigeria Education',
    ogImage: 'https://campusai.ng/og-image.jpg'
  });

  // FAQ State
  const [faqs, setFaqs] = useState<{ question: string; answer: string; category: string }[]>([]);
  const [newFaq, setNewFaq] = useState({ question: '', answer: '', category: 'General' });

  // Scoring Sync State
  const [syncProgress, setSyncProgress] = useState({ current: 0, total: 0, status: 'idle', currentUni: '' });
  const [isSyncing, setIsSyncing] = useState(false);

  const generateSitemap = () => {
    const urls = [
      'https://campusai.ng/',
      'https://campusai.ng/news',
      'https://campusai.ng/about',
      'https://campusai.ng/contact'
    ];
    
    // Add university pages
    universityData.forEach(uni => {
      const slug = uni.slug || uni.name.toLowerCase().replace(/\s+/g, '-');
      urls.push(`https://campusai.ng/university/${slug}`);
    });

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${urls.map(url => `
  <url>
    <loc>${url}</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <priority>${url === 'https://campusai.ng/' ? '1.0' : '0.8'}</priority>
  </url>`).join('')}
</urlset>`;

    const blob = new Blob([sitemap], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sitemap.xml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    alert("Sitemap generated and downloaded. Upload this to your root directory for better SEO.");
  };
  const [saved, setSaved] = useState(false);
  const [tickerHeadlines, setTickerHeadlines] = useState<string[]>([]);
  const [newTickerHeadline, setNewTickerHeadline] = useState('');

  const [socials, setSocials] = useState({ facebook: '', twitter: '', instagram: '', linkedin: '', youtube: '' });
  const isGeminiInEnv = !!process.env.API_KEY;
  const isFlutterwaveInEnv = !!process.env.VITE_FLUTTERWAVE_PUBLIC_KEY;
  const isFwLive = flutterwaveKey.startsWith('FLWPUBK-') || flutterwaveKey.startsWith('FLWPUBK_');

  // Broadcast Suite State
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [broadcastForm, setBroadcastForm] = useState<Partial<BroadcastEmail>>({
    subject: '[URGENT] Official JAMB 2026 Registration Notice',
    headline: 'No Extension for 2026 UTME Registration Period',
    ctaText: 'Check Official Deadline',
    ctaLink: 'https://campusai.ng',
    urgency: 'high',
    body: `JAMB has officially confirmed that approximately one million candidates have already registered for the ongoing 2026 UTME. The Board has made it clear that the registration timeline remains unchanged to align with the calendars of other examination bodies. 

Candidates are therefore advised to register early, avoid last-minute rushes, and disregard any claims suggesting an extension as the Board will not be held responsible for candidates who fail to register within the stipulated period.`
  });

  useEffect(() => {
    if (isOpen) {
      const storedFirebase = localStorage.getItem('campusai_firebase');
      if (storedFirebase) setFirebaseConfig(storedFirebase);
      
    const loadSettings = async () => {
      const config = await getGlobalConfig();
      if (config) {
        if (config.whatsapp) setWhatsappNumber(config.whatsapp);
        if (config.supportEmail) setSupportEmail(config.supportEmail);
        if (config.premiumWhatsapp) setPremiumWhatsapp(config.premiumWhatsapp);
        if (config.premiumTelegram) setPremiumTelegram(config.premiumTelegram);
        if (config.socials) setSocials(config.socials);
        if (config.googleAdsEnabled !== undefined) setGoogleAdsEnabled(config.googleAdsEnabled);
        if (config.flutterwaveKey) setFlutterwaveKey(config.flutterwaveKey);
        if (config.geminiKey) setGeminiKey(config.geminiKey);
        if (config.featureKeys) setFeatureKeys(config.featureKeys);
        if (config.seo) setSeoConfig(config.seo);
        if (config.faqs) setFaqs(config.faqs);
      } else {
        const storedGemini = localStorage.getItem('campusai_gemini_key');
        if (storedGemini) setGeminiKey(storedGemini);

        const storedFeatureKeys = localStorage.getItem('campusai_feature_keys');
        if (storedFeatureKeys) {
          try {
            setFeatureKeys(JSON.parse(storedFeatureKeys));
          } catch (e) {}
        }

        const storedFw = localStorage.getItem('campusai_flutterwave_key') || MASTER_CONFIG.FLUTTERWAVE_PUBLIC_KEY;
        if (storedFw) setFlutterwaveKey(storedFw);

        const storedWhatsapp = localStorage.getItem('campusai_whatsapp');
        if (storedWhatsapp) setWhatsappNumber(storedWhatsapp);

        const storedSupportEmail = localStorage.getItem('campusai_support_email') || 'support@campusai.ng';
        setSupportEmail(storedSupportEmail);

        const savedSocials = localStorage.getItem('campusai_social_links');
        if (savedSocials) setSocials(JSON.parse(savedSocials));
        
        setGoogleAdsEnabled(localStorage.getItem('campusai_google_ads') === 'true');
        setSyncOnRefresh(localStorage.getItem('campusai_sync_on_refresh') === 'true');
      }
      
      loadCloudAds();
      loadPendingAds();
      getTickerHeadlines().then(setTickerHeadlines);
    };

    loadSettings();

    if (admin.isLoggedIn) {
      loadUsers();
      loadSubscribers();
    }

    const handleDbError = (e: any) => {
      if (e.detail?.type === 'permission_denied') setDbStatus('blocked');
    };
    window.addEventListener('campusai_db_error', handleDbError);
    return () => window.removeEventListener('campusai_db_error', handleDbError);
  }
}, [isOpen, activeTab, admin.isLoggedIn]);

  const [showPostForm, setShowPostForm] = useState(false);
  const [generatedScript, setGeneratedScript] = useState<any>(null);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'synced' | 'pending' | 'error'>('synced');
  const [launchChecklist, setLaunchChecklist] = useState({
    firebase: false,
    gemini: false,
    news: false,
    socials: false,
    payment: false
  });

  useEffect(() => {
    const checkReadiness = async () => {
      const config = await getGlobalConfig();
      const news = await getCloudNews();
      
      setLaunchChecklist({
        firebase: !!db,
        gemini: !!geminiKey || !!(config?.geminiKey),
        news: news.length > 0,
        socials: !!socials.facebook || !!socials.twitter || !!(config?.socials?.facebook),
        payment: !!flutterwaveKey || !!(config?.flutterwaveKey)
      });
    };
    if (isOpen) checkReadiness();
  }, [isOpen, geminiKey, socials, flutterwaveKey]);
  const [publishedNews, setPublishedNews] = useState<NewsItem[]>([]);
  const [isPublishing, setIsPublishing] = useState(false);
  
  const loadNews = async () => {
    const news = await getCloudNews();
    setPublishedNews(news);
  };

  useEffect(() => {
    if (isOpen && activeTab === 'content') {
      loadNews();
    }
  }, [isOpen, activeTab]);
  const [newPost, setNewPost] = useState<Partial<NewsItem>>({
    category: 'Federal',
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
    relatedNews: []
  });
  const [newRelatedLink, setNewRelatedLink] = useState({ title: '', url: '' });

  const [billboardAds, setBillboardAds] = useState<BillboardAd[]>([]);
  const [pendingAds, setPendingAds] = useState<BillboardAd[]>([]);
  const [showAdForm, setShowAdForm] = useState(false);
  const [isPublishingAd, setIsPublishingAd] = useState(false);
  const [newAd, setNewAd] = useState<Partial<BillboardAd>>({ 
    category: 'Services', 
    isVerified: true, 
    isSponsored: true,
    price: '₦',
    link: 'https://',
    status: 'active'
  });

  const [manualUid, setManualUid] = useState('');
  const [recentUsers, setRecentUsers] = useState<UserProfile[]>([]);
  const [subscribers, setSubscribers] = useState<any[]>([]);
  const [totalUserCount, setTotalUserCount] = useState(0);
  const [userRoleFilter, setUserRoleFilter] = useState<UserRole | 'All'>('All');
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [generatingVideoScriptId, setGeneratingVideoScriptId] = useState<string | null>(null);

  const isLiveCloud = auth && !auth.isMock;

  const filteredUsers = recentUsers.filter(u => userRoleFilter === 'All' || u.role === userRoleFilter);

  const loadCloudAds = async () => {
    const ads = await getCloudAds();
    setBillboardAds(ads);
  };

  const loadPendingAds = async () => {
    const pAds = await getPendingAds();
    setPendingAds(pAds);
  };

  const loadUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const [users, count] = await Promise.all([
        fetchRecentUsers(),
        getTotalUserCount()
      ]);
      setRecentUsers(users);
      setTotalUserCount(count);
    } catch (e) {
      console.error("User Load Error");
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const loadSubscribers = async () => {
    const subs = await getSubscribers();
    setSubscribers(subs);
  };

  const validateFirebase = () => {
    setValidationStatus('validating');
    setTimeout(() => {
      try {
        const parsed = JSON.parse(firebaseConfig);
        if (parsed.apiKey && parsed.projectId) {
          setValidationStatus('valid');
        } else {
          setValidationStatus('invalid');
        }
      } catch (e) { setValidationStatus('invalid'); }
    }, 1200);
  };

  const handleSaveSeo = async () => {
    await saveGlobalConfig({ seo: seoConfig });
    alert("SEO Settings Saved!");
  };

  const handleAddFaq = () => {
    if (!newFaq.question || !newFaq.answer) return;
    const updated = [...faqs, newFaq];
    setFaqs(updated);
    setNewFaq({ question: '', answer: '', category: 'General' });
  };

  const handleSaveFaqs = async () => {
    await saveGlobalConfig({ faqs });
    alert("FAQs Saved!");
  };

  const handleSyncScoring = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    setSyncProgress({ current: 0, total: universityData.length, status: 'syncing', currentUni: '' });

    for (let i = 0; i < universityData.length; i++) {
      const uni = universityData[i];
      if (!uni.slug) continue;

      setSyncProgress(prev => ({ ...prev, current: i + 1, currentUni: uni.name }));

      try {
        // Check if already exists
        const existing = await getGlobalScoringSystem(uni.slug);
        if (!existing) {
          const scoring = await getUniversityScoringSystem(uni.name);
          if (scoring) {
            await saveGlobalScoringSystem(uni.slug, scoring);
          }
        }
      } catch (e) {
        console.error(`Error syncing ${uni.name}:`, e);
      }

      // Small delay to avoid rate limits
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setIsSyncing(false);
    setSyncProgress(prev => ({ ...prev, status: 'complete' }));
    alert("Scoring Systems Sync Complete!");
  };

  const handleSave = async () => {
    // 1. Save to LocalStorage (Immediate feedback)
    localStorage.setItem('campusai_firebase', firebaseConfig);
    localStorage.setItem('campusai_gemini_key', geminiKey);
    localStorage.setItem('campusai_feature_keys', stringify(featureKeys));
    localStorage.setItem('campusai_flutterwave_key', flutterwaveKey);
    const sanitizedWhatsapp = whatsappNumber.replace(/\D/g, '');
    localStorage.setItem('campusai_whatsapp', sanitizedWhatsapp);
    localStorage.setItem('campusai_support_email', supportEmail);
    localStorage.setItem('campusai_google_ads', googleAdsEnabled ? 'true' : 'false');
    localStorage.setItem('campusai_sync_on_refresh', syncOnRefresh ? 'true' : 'false');
    localStorage.setItem('campusai_social_links', stringify(socials));

    // 2. Save to Cloud (Visibility for all users/shared links)
    await saveGlobalConfig({
      whatsapp: sanitizedWhatsapp,
      supportEmail,
      premiumWhatsapp,
      premiumTelegram,
      socials,
      googleAdsEnabled,
      flutterwaveKey,
      geminiKey, // Cloud Sync for keys
      featureKeys
    });
    
    await saveTickerHeadlines(tickerHeadlines);
    
    if (onSocialUpdate) onSocialUpdate(socials);
    
    setSaved(true);
    window.dispatchEvent(new Event('storage'));
    setTimeout(() => { 
      setSaved(false); 
      onClose(); 
      window.location.reload();
    }, 1500);
  };

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen && admin.isLoggedIn) {
      const loadStatus = async () => {
        const status = await getASUUStatusFromDB();
        if (status) setAsuuStatus(status);
      };
      loadStatus();
    }
  }, [isOpen, admin.isLoggedIn]);

  const handleUpdateAsuuStatus = async () => {
    setIsUpdatingAsuu(true);
    try {
      const dataToSave = {
        isActive: asuuStatus.isActive,
        status: asuuStatus.status,
        summary: asuuStatus.summary
      };
      await saveASUUStatusToDB(dataToSave);
      setAsuuStatus(prev => ({ ...prev, lastUpdated: new Date().toLocaleDateString() }));
      alert("ASUU Strike Status updated successfully!");
    } catch (e) {
      alert("Failed to update ASUU status.");
    } finally {
      setIsUpdatingAsuu(false);
    }
  };

  const handleSyncLiveNews = async (isAuto = false) => {
    if (isLoading) return;
    setIsLoading(true);
    try {
      const liveData = await fetchLiveNews();
      if (liveData && liveData.length > 0) {
        await archiveNewsItems(liveData);
        
        // Auto-update ticker with latest 5 news titles
        const newHeadlines = liveData.slice(0, 5).map(n => n.title);
        if (newHeadlines.length > 0) {
          await saveTickerHeadlines([...newHeadlines, ...tickerHeadlines].slice(0, 10));
          setTickerHeadlines(prev => [...newHeadlines, ...prev].slice(0, 10));
        }

        const now = Date.now();
        await updateGlobalSyncMetadata(now);
        localStorage.setItem('campusai_last_auto_sync_ts', now.toString());
        sessionStorage.setItem('campusai_sync_lock', 'active');
        await loadNews(); // Refresh from cloud
        alert(`Intelligence Cycle Complete: ${liveData.length} new data points synchronized.`);
      } else {
        alert("No new intelligence found. Check API keys and network signal.");
      }
    } catch (e) {
      alert("Sync failed. Check console for details.");
    } finally { setIsLoading(false); }
  };

  const handlePublishPost = async () => {
    if (!newPost.title || !newPost.excerpt) return;
    setIsPublishing(true);
    try {
      await publishNewsUpdate({
        title: newPost.title,
        category: newPost.category as UniversityCategory,
        excerpt: newPost.excerpt,
        fullContent: newPost.fullContent, 
        date: newPost.date || '',
        sourceUrl: newPost.sourceUrl,
        image: ''
      });
      
      // Auto-update ticker with the new post
      const updatedTicker = [newPost.title!, ...tickerHeadlines].slice(0, 10);
      await saveTickerHeadlines(updatedTicker);
      setTickerHeadlines(updatedTicker);

      await loadNews(); // Refresh from cloud
      setNewPost({ 
        category: 'Federal', 
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }),
        fullContent: '' 
      });
      setShowPostForm(false);
    } finally { setIsPublishing(false); }
  };

  const handleDeletePost = async (id: string) => {
    if (window.confirm('Permanently delete this news update?')) {
      await deleteNewsUpdate(id);
      await loadNews(); // Refresh from cloud
    }
  };

  const handlePublishAd = async () => {
    if (!newAd.title || !newAd.description) return;
    setIsPublishingAd(true);
    const sanitizedWhatsapp = newAd.whatsapp ? newAd.whatsapp.replace(/\D/g, '') : undefined;
    const adToSave: Omit<BillboardAd, 'id'> = {
      title: newAd.title!,
      description: newAd.description!,
      category: (newAd.category as any) || 'Services',
      price: newAd.price || 'Contact for price',
      link: newAd.link || '#',
      whatsapp: sanitizedWhatsapp,
      isVerified: !!newAd.isVerified,
      isSponsored: true,
      status: 'active'
    };
    const adId = await publishCloudAd(adToSave);
    if (adId) {
      await loadCloudAds();
      setNewAd({ category: 'Services', isVerified: true, isSponsored: true, price: '₦', link: 'https://', status: 'active' });
      setShowAdForm(false);
      window.dispatchEvent(new Event('campusai_ads_updated'));
    }
    setIsPublishingAd(false);
  };

  const handleDeleteAd = async (id: string) => {
    if (window.confirm('Remove this advertisement?')) {
      const success = await deleteCloudAd(id);
      if (success) {
        await loadCloudAds();
        await loadPendingAds();
        window.dispatchEvent(new Event('campusai_ads_updated'));
      }
    }
  };

  const handleApprovePending = async (id: string) => {
    const success = await approveAd(id);
    if (success) {
      alert("Ad approved and live!");
      await loadCloudAds();
      await loadPendingAds();
      window.dispatchEvent(new Event('campusai_ads_updated'));
    }
  };

  const handleDispatchBroadcast = async () => {
    if (!broadcastForm.subject || !broadcastForm.body) return;
    if (!confirm(`Dispatch mass email to ${subscribers.length} scholars? This action consumes significant backend throughput.`)) return;
    
    setIsBroadcasting(true);
    const success = await dispatchBroadcast({
      subject: broadcastForm.subject!,
      headline: broadcastForm.headline!,
      body: broadcastForm.body!,
      ctaText: broadcastForm.ctaText!,
      ctaLink: broadcastForm.ctaLink!,
      urgency: broadcastForm.urgency as any
    });

    if (success) {
      alert("Intelligence Dispatch Successful! Emails are being routed via satellite nodes.");
      setBroadcastForm({
        ...broadcastForm,
        body: ''
      });
    } else {
      alert("Dispatch Failure: Routing nodes congested or no recipients found.");
    }
    setIsBroadcasting(false);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginEmail.trim().length >= 4) {
      onAdminLogin(loginEmail);
      setLoginEmail('');
    }
  };

  const copyConfigString = () => {
    navigator.clipboard.writeText(firebaseConfig);
    alert("Copied! Paste this on other devices to sync.");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-xl" onClick={onClose} />
      <div className="relative bg-white dark:bg-gray-950 w-full max-w-5xl rounded-[48px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] border border-white/5">
        
        <div className="p-6 md:p-8 bg-gray-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/20">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h2 className="text-lg md:text-2xl font-black tracking-tight uppercase tracking-widest">Admin Command Center</h2>
              <div className="flex items-center gap-2 text-[8px] md:text-[10px] font-bold text-red-400 uppercase tracking-widest">
                <div className={`w-1.5 h-1.5 rounded-full animate-ping ${dbStatus === 'blocked' ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
                {isLiveCloud ? 'Live Cloud Active' : 'Simulation Mode'}
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24} /></button>
        </div>

        <div className="flex border-b border-gray-100 dark:border-gray-900 shrink-0 bg-gray-50/50 dark:bg-gray-950 overflow-x-auto no-scrollbar">
          {(['infrastructure', 'revenue', 'content', 'status', 'users', 'communications', 'analytics', 'seo', 'faq', 'briefing'] as const).map(tab => (
            <button 
              key={tab} 
              onClick={() => setActiveTab(tab)} 
              className={`flex-1 min-w-[120px] py-4 md:py-5 text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] transition-all relative ${activeTab === tab ? 'text-red-500' : 'text-gray-400'}`}
            >
              {tab}
              {activeTab === tab && <motion.div layoutId="tab-admin-active" className="absolute bottom-0 left-0 right-0 h-1 bg-red-600" />}
            </button>
          ))}
        </div>

        <div className="p-6 md:p-8 space-y-10 overflow-y-auto flex-grow no-scrollbar bg-white dark:bg-gray-950">
          {!admin.isLoggedIn ? (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="max-w-md mx-auto text-center space-y-8 py-12">
              <div className="w-20 h-20 bg-gray-100 dark:bg-gray-900 rounded-[32px] flex items-center justify-center text-gray-400 mx-auto border border-gray-100 dark:border-gray-800">
                <Lock size={40} />
              </div>
              <div>
                <h3 className="text-2xl font-black dark:text-white mb-2">Restricted Area</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Enter secure security token to manage CampusAI.</p>
              </div>
              <form onSubmit={handleLogin} className="space-y-4">
                <input 
                  type="password" 
                  value={loginEmail} 
                  onChange={(e) => setLoginEmail(e.target.value)} 
                  placeholder="Security Token" 
                  className="w-full bg-gray-50 dark:bg-gray-900 border-2 border-transparent focus:border-red-500 rounded-2xl p-4 text-center dark:text-white font-mono"
                />
                <button type="submit" className="w-full py-5 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl transition-all">Authenticate Access</button>
              </form>
            </motion.div>
          ) : (
            <>
              {activeTab === 'infrastructure' && (
                <div className="space-y-10">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800">
                      <div>
                        <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Cloud Sync Status</p>
                        <p className="text-sm font-bold dark:text-white flex items-center gap-2">
                          {db ? (
                            <span className="text-emerald-500 flex items-center gap-1"><Check size={14} /> Connected to Federated Network</span>
                          ) : (
                            <span className="text-amber-500 flex items-center gap-1"><WifiOff size={14} /> Local Mode (Sync Required)</span>
                          )}
                        </p>
                      </div>
                      <button onClick={handleSave} className="px-4 py-2 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">Force Sync</button>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800">
                      <div>
                        <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Sync News on Refresh</p>
                        <p className="text-[10px] font-bold text-gray-500">Enable automatic news sync when the page is refreshed.</p>
                      </div>
                      <button 
                        onClick={() => setSyncOnRefresh(!syncOnRefresh)}
                        className={`w-12 h-6 rounded-full transition-colors ${syncOnRefresh ? 'bg-emerald-500' : 'bg-gray-300'}`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${syncOnRefresh ? 'translate-x-7' : 'translate-x-1'}`} />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800">
                       <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">Premium WhatsApp Invite</label>
                         <input 
                           type="text" 
                           value={premiumWhatsapp} 
                           onChange={(e) => setPremiumWhatsapp(e.target.value)} 
                           placeholder="https://chat.whatsapp.com/..." 
                           className="w-full bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 p-4 rounded-2xl dark:text-white outline-none font-bold"
                         />
                       </div>
                       <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">Premium Telegram Invite</label>
                         <input 
                           type="text" 
                           value={premiumTelegram} 
                           onChange={(e) => setPremiumTelegram(e.target.value)} 
                           placeholder="https://t.me/..." 
                           className="w-full bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 p-4 rounded-2xl dark:text-white outline-none font-bold"
                         />
                       </div>
                    </div>

                    <div className="p-6 bg-blue-50 dark:bg-blue-900/10 rounded-3xl border border-blue-100 dark:border-blue-800">
                      <h4 className="text-xs font-black uppercase text-blue-600 dark:text-cyan-400 mb-4 flex items-center gap-2"><Rocket size={16} /> April Launch Readiness</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(launchChecklist).map(([key, value]) => (
                          <div key={key} className="flex items-center gap-3">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${value ? 'bg-emerald-500 text-white' : 'bg-gray-200 dark:bg-gray-800 text-gray-400'}`}>
                              {value ? <Check size={12} /> : <div className="w-1.5 h-1.5 rounded-full bg-current" />}
                            </div>
                            <span className={`text-[10px] font-black uppercase tracking-widest ${value ? 'text-gray-700 dark:text-gray-300' : 'text-gray-400'}`}>
                              {key === 'firebase' ? 'Neural Link (Firebase)' : 
                               key === 'gemini' ? 'AI Core (Gemini)' : 
                               key === 'news' ? 'Intelligence Feed' : 
                               key === 'socials' ? 'Social Nodes' : 
                               key === 'payment' ? 'Payout Bridge' : 'Unknown Node'}
                            </span>
                          </div>
                        ))}
                      </div>
                      {!Object.values(launchChecklist).every(v => v) && (
                        <p className="text-[9px] font-bold text-amber-600 mt-4 flex items-center gap-1 italic">
                          <ShieldCheck size={12} /> Some nodes are offline. Visibility might be limited for visitors.
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-6 md:p-8 bg-gray-50 dark:bg-gray-900 rounded-[32px] border border-gray-100 dark:border-gray-800">
                      <h3 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-6 flex items-center gap-2">
                        <Activity size={14} className="text-emerald-500" /> System Health
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center px-4 py-2 bg-white dark:bg-gray-950 rounded-xl border border-gray-100 dark:border-gray-800">
                          <span className="text-[10px] font-bold dark:text-gray-400">Gemini Cloud</span>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${systemStatus?.gemini === 'online' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-orange-500/10 text-orange-500'}`}>
                            {systemStatus?.gemini === 'online' ? 'OPERATIONAL' : 'OFFLINE'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center px-4 py-2 bg-white dark:bg-gray-950 rounded-xl border border-gray-100 dark:border-gray-800">
                          <span className="text-[10px] font-bold dark:text-gray-400">Firebase Core</span>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase ${isLiveCloud ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-50 text-red-500'}`}>
                            {isLiveCloud ? 'INITIALIZED' : 'OFFLINE'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="md:col-span-2 p-6 md:p-8 bg-blue-600 text-white rounded-[32px] shadow-xl shadow-blue-500/20 relative overflow-hidden group">
                       <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2"></div>
                       <div className="relative z-10 flex justify-between h-full flex-col">
                          <div className="flex items-center gap-3 mb-6">
                            <Smartphone size={24} />
                            <h3 className="text-xs font-black uppercase tracking-widest opacity-80">Cloud Signature</h3>
                          </div>
                          <div className="bg-white/10 border border-white/20 p-4 rounded-2xl backdrop-blur-md">
                             <p className="text-[9px] opacity-70 leading-relaxed mb-4">Copy this core configuration signature to sync this specific setup across multiple developer devices manually.</p>
                             <button onClick={copyConfigString} className="flex items-center gap-2 px-6 py-2 bg-white text-blue-600 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl active:scale-95 transition-all"><Copy size={12} /> Copy Core Configuration</button>
                          </div>
                       </div>
                    </div>
                  </div>

                  <div className="p-6 md:p-10 bg-gray-50 dark:bg-gray-900 rounded-[40px] border border-gray-100 dark:border-gray-800 space-y-8">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center shadow-lg">
                        <Globe size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black dark:text-white">Social Connect</h3>
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Global Brand Links</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2 flex items-center gap-2">
                           <Facebook size={12} /> Facebook URL
                         </label>
                         <input 
                           type="text" 
                           value={socials.facebook} 
                           onChange={(e) => setSocials({...socials, facebook: e.target.value})}
                           placeholder="https://facebook.com/..."
                           className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                         />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2 flex items-center gap-2">
                           <Twitter size={12} /> Twitter URL
                         </label>
                         <input 
                           type="text" 
                           value={socials.twitter} 
                           onChange={(e) => setSocials({...socials, twitter: e.target.value})}
                           placeholder="https://twitter.com/..."
                           className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                         />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2 flex items-center gap-2">
                           <Instagram size={12} /> Instagram URL
                         </label>
                         <input 
                           type="text" 
                           value={socials.instagram} 
                           onChange={(e) => setSocials({...socials, instagram: e.target.value})}
                           placeholder="https://instagram.com/..."
                           className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                         />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2 flex items-center gap-2">
                           <Linkedin size={12} /> LinkedIn URL
                         </label>
                         <input 
                           type="text" 
                           value={socials.linkedin} 
                           onChange={(e) => setSocials({...socials, linkedin: e.target.value})}
                           placeholder="https://linkedin.com/in/..."
                           className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                         />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2 flex items-center gap-2">
                           <Youtube size={12} /> YouTube URL
                         </label>
                         <input 
                           type="text" 
                           value={socials.youtube} 
                           onChange={(e) => setSocials({...socials, youtube: e.target.value})}
                           placeholder="https://youtube.com/@..."
                           className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                         />
                      </div>
                    </div>
                  </div>

                  <div className="p-6 md:p-10 bg-gray-50 dark:bg-gray-900 rounded-[40px] border border-gray-100 dark:border-gray-800 space-y-8">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg">
                        <Key size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black dark:text-white">API Core Access</h3>
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Logic & Finance Nodes</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-12">
                        <div className="space-y-8">
                           <div className="space-y-4">
                             <div className="flex justify-between items-center ml-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Primary Gemini API Key (Fallback)</label>
                                {geminiKey && <span className="text-[8px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full">Active Signal</span>}
                             </div>
                             <div className="relative">
                               <input 
                                 type="text" 
                                 value={geminiKey} 
                                 onChange={(e) => setGeminiKey(e.target.value)} 
                                 placeholder="Primary API Key" 
                                 className="w-full p-4 bg-white dark:bg-gray-950 border border-transparent focus:border-blue-500 rounded-2xl font-bold dark:text-white outline-none shadow-sm"
                               />
                               <Brain className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none" size={18} />
                             </div>
                           </div>

                           <div className="space-y-6">
                              <div className="flex items-center gap-2 ml-2">
                                 <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                                 <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Feature-Specific Logic Nodes (1 Key Per Feature)</label>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                 {Object.keys(featureKeys).map((feature) => (
                                   <div key={feature} className="space-y-2">
                                     <label className="text-[9px] font-black uppercase text-gray-500 ml-2">{feature} Intelligence Key</label>
                                     <input 
                                       type="text"
                                       value={featureKeys[feature]}
                                       onChange={(e) => setFeatureKeys({...featureKeys, [feature]: e.target.value})}
                                       placeholder={`${feature} key...`}
                                       className="w-full p-3 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-xl font-bold text-xs dark:text-white outline-none focus:border-blue-500 transition-all"
                                     />
                                   </div>
                                 ))}
                              </div>
                           </div>
                        </div>

                        <div className="space-y-4 pt-8 border-t border-gray-100 dark:border-gray-800">
                          <div className="flex justify-between items-center ml-2">
                             <div className="flex items-center gap-2">
                                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Flutterwave Public Key</label>
                                {flutterwaveKey && (
                                  <span className={`text-[8px] font-black px-2 py-0.5 rounded-full ${isFwLive ? 'bg-emerald-500 text-white shadow-sm' : 'bg-orange-100 text-orange-600'}`}>
                                    {isFwLive ? 'LIVE' : 'TEST MODE'}
                                  </span>
                                )}
                             </div>
                             {isFlutterwaveInEnv && <span className="flex items-center gap-1 text-[8px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full"><Server size={8}/> Detected in Env</span>}
                          </div>
                          <div className="relative">
                             <input 
                               type="text" 
                               value={flutterwaveKey} 
                               onChange={(e) => setFlutterwaveKey(e.target.value)} 
                               placeholder={isFlutterwaveInEnv ? "Active via Environment Variable" : "FLWPUBK_..."} 
                               className={`w-full p-4 rounded-2xl font-bold outline-none border transition-all ${isFlutterwaveInEnv ? 'bg-emerald-500/5 dark:bg-emerald-500/5 border-emerald-500/20 dark:text-emerald-400' : 'bg-white dark:bg-gray-950 dark:text-white border-transparent focus:border-blue-500'}`}
                             />
                             <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300 pointer-events-none" size={18} />
                          </div>
                        </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-200 dark:border-gray-800">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center shadow-lg">
                        <Code size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black dark:text-white">Master Firebase Logic</h3>
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Global Linkage Config</p>
                      </div>
                    </div>
                    
                    <textarea 
                      value={firebaseConfig}
                      onChange={(e) => { setFirebaseConfig(e.target.value); setValidationStatus('idle'); }}
                      placeholder='{ "apiKey": "...", ... }'
                      className="w-full h-40 bg-white dark:bg-gray-950 p-6 rounded-[24px] border-2 border-transparent focus:border-red-500 outline-none font-mono text-sm dark:text-gray-300 resize-none shadow-inner"
                    />
                    <div className="mt-4 flex flex-col md:flex-row justify-between items-center gap-4">
                      <div className="flex items-center gap-3">
                         {validationStatus === 'valid' && <span className="text-[10px] font-black text-emerald-500 uppercase flex items-center gap-1"><CheckCircle2 size={12}/> Valid Signature</span>}
                      </div>
                      <button onClick={validateFirebase} className="w-full md:w-auto px-6 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded-full text-[10px] font-black uppercase tracking-widest">Verify Signal</button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'users' && (
                <div className="space-y-12">
                   <div className="p-6 md:p-8 bg-gray-50 dark:bg-gray-900 rounded-[40px] border border-gray-100 dark:border-gray-800 shadow-sm">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg">
                          <Users size={24} />
                        </div>
                        <div>
                          <h3 className="text-xl font-black dark:text-white">Cloud Explorer</h3>
                          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">{totalUserCount} Verified Scholars</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {(['All', 'Pre-Admission', 'In-Campus', 'Graduate/Alumni', 'School/Institution'] as const).map(r => (
                          <button 
                            key={r} 
                            onClick={() => setUserRoleFilter(r)}
                            className={`px-3 py-1.5 rounded-xl text-[8px] font-black uppercase tracking-widest transition-all ${userRoleFilter === r ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                      <button onClick={loadUsers} className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 text-blue-600 dark:text-blue-400 rounded-xl font-black text-[10px] uppercase tracking-widest border border-gray-100 dark:border-gray-700 shadow-sm">
                        <RefreshCw size={14} className={isLoadingUsers ? "animate-spin" : ""} /> Force Cloud Sync
                      </button>
                    </div>
                    
                    <div className="space-y-3">
                      {isLoadingUsers ? (
                        <div className="py-12 flex flex-col items-center justify-center space-y-4">
                          <Loader2 className="animate-spin text-blue-500" size={32} />
                        </div>
                      ) : filteredUsers.map(u => (
                        <div key={u.uid} className="flex flex-col md:flex-row items-center justify-between p-4 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-3xl gap-4 group">
                          <div className="flex items-center gap-4 w-full md:w-auto">
                            <div className="w-12 h-12 bg-gray-100 dark:bg-gray-900 rounded-2xl overflow-hidden flex items-center justify-center shrink-0 border border-gray-100 dark:border-gray-800">
                              {u.photoURL ? <img src={u.photoURL} className="w-full h-full object-cover" /> : <Users size={20} className="text-gray-400" />}
                            </div>
                            <div className="overflow-hidden">
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-sm dark:text-white truncate">{u.displayName || 'Anonymous Scholar'}</p>
                                {u.is_premium && <Star size={12} className="text-yellow-500 fill-current" />}
                              </div>
                              <p className="text-[10px] font-mono text-gray-400 truncate">{u.uid}</p>
                              <p className="text-[9px] font-black text-blue-500 uppercase tracking-widest">{u.role || 'Pre-Admission'}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                            <div className="text-right">
                              <p className="text-[8px] font-bold text-gray-400">Last Active</p>
                              <p className="text-[10px] font-black dark:text-white">
                                {typeof u.last_active === 'string' ? u.last_active : 
                                 u.last_active && typeof u.last_active === 'object' && 'seconds' in u.last_active ? 
                                 new Date((u.last_active as any).seconds * 1000).toLocaleDateString() : 
                                 'Unknown'}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              
              {activeTab === 'revenue' && (
                <div className="space-y-12">
                   <div className="p-6 md:p-8 bg-emerald-500/5 dark:bg-emerald-500/5 rounded-[40px] border border-emerald-500/10">
                    <div className="flex items-center gap-4 mb-8">
                      <div className="w-12 h-12 bg-emerald-50 text-white rounded-2xl flex items-center justify-center shadow-lg">
                        <DollarSign size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black dark:text-white">Revenue Control</h3>
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Ad Monetization & Support Hub</p>
                      </div>
                    </div>

                    <div className="mb-10">
                       <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest dark:text-white mb-6">
                          <Clock size={16} className="text-orange-500" /> Pending Paid Approvals ({pendingAds.length})
                       </h4>
                       {pendingAds.length > 0 ? (
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           {pendingAds.map(ad => (
                             <div key={ad.id} className="p-6 bg-white dark:bg-gray-900 border-2 border-orange-100 dark:border-orange-900/30 rounded-[32px] space-y-4">
                               <div className="flex justify-between items-start">
                                 <div>
                                   <p className="font-black dark:text-white">{ad.title}</p>
                                   <p className="text-[10px] font-black text-orange-500 uppercase">Paid: {ad.paidAmount}</p>
                                 </div>
                                 <div className="px-3 py-1 bg-gray-100 dark:bg-gray-800 rounded-full text-[8px] font-black uppercase text-gray-400">{ad.category}</div>
                               </div>
                               <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 italic">"{ad.description}"</p>
                               <div className="pt-4 flex gap-2">
                                  <button onClick={() => handleApprovePending(ad.id)} className="flex-1 py-3 bg-emerald-500 text-white rounded-xl font-black text-[10px] uppercase flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"><Check size={14}/> Approve Ad</button>
                                  <button onClick={() => handleDeleteAd(ad.id)} className="p-3 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all"><Trash2 size={16}/></button>
                               </div>
                             </div>
                           ))}
                         </div>
                       ) : (
                         <div className="p-8 text-center bg-gray-50 dark:bg-gray-900/50 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800">
                           <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">No pending submissions</p>
                         </div>
                       )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">WhatsApp Support Line</label>
                        <input 
                          type="text" 
                          value={whatsappNumber} 
                          onChange={(e) => setWhatsappNumber(e.target.value)} 
                          placeholder="23481..." 
                          className="w-full bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 p-4 rounded-2xl dark:text-white outline-none font-bold"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">Official Support Email</label>
                        <input 
                          type="email" 
                          value={supportEmail} 
                          onChange={(e) => setSupportEmail(e.target.value)} 
                          placeholder="support@campusai.ng" 
                          className="w-full bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 p-4 rounded-2xl dark:text-white outline-none font-bold"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest dark:text-white">
                          <ShoppingBag size={16} className="text-emerald-500" /> Active Cloud Billboard {billboardAds.length > 0 && `(${billboardAds.length})`}
                        </h4>
                        <button 
                          onClick={() => setShowAdForm(!showAdForm)}
                          className={`w-full md:w-auto px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${showAdForm ? 'bg-red-50 text-red-500' : 'bg-emerald-600 text-white'}`}
                        >
                          {showAdForm ? 'Cancel' : 'New Ad Slot'}
                        </button>
                      </div>

                      <AnimatePresence>
                        {showAdForm && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                            <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-[32px] space-y-4 border border-emerald-500/20 shadow-inner">
                              <input placeholder="Ad Title" className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl font-bold outline-none dark:text-white" value={newAd.title || ''} onChange={e => setNewAd({...newAd, title: e.target.value})} />
                              <div className="grid grid-cols-2 gap-4">
                                <input placeholder="Price" className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl outline-none dark:text-white" value={newAd.price || ''} onChange={e => setNewAd({...newAd, price: e.target.value})} />
                                <input placeholder="Vendor WhatsApp" className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl outline-none dark:text-white" value={newAd.whatsapp || ''} onChange={e => setNewAd({...newAd, whatsapp: e.target.value})} />
                              </div>
                              <textarea placeholder="Ad Description" className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl h-24 outline-none dark:text-white" value={newAd.description || ''} onChange={e => setNewAd({...newAd, description: e.target.value})} />
                              <button onClick={handlePublishAd} disabled={isPublishingAd} className="w-full py-4 bg-emerald-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest">
                                {isPublishingAd ? <Loader2 className="animate-spin" size={14} /> : 'Commit Ad to Cloud'}
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      <div className="space-y-2">
                        {billboardAds.map(ad => (
                          <div key={ad.id} className="p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl flex items-center justify-between group">
                            <div className="overflow-hidden">
                              <p className="font-bold text-xs dark:text-white truncate">{ad.title}</p>
                              <p className="text-[10px] font-bold text-gray-400 uppercase">{ad.price}</p>
                            </div>
                            <button onClick={() => handleDeleteAd(ad.id)} className="p-2 text-gray-300 hover:text-red-500"><Trash2 size={16} /></button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-6">
                       <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest dark:text-white">
                          <Mail size={16} className="text-blue-500" /> Recent Subscribers
                       </h4>
                       <div className="bg-gray-50 dark:bg-gray-900/50 rounded-[32px] p-6 border border-gray-100 dark:border-gray-800 max-h-[400px] overflow-y-auto no-scrollbar">
                          {subscribers.length > 0 ? (
                            <div className="space-y-3">
                              {subscribers.map(sub => (
                                <div key={sub.id} className="p-4 bg-white dark:bg-gray-950 rounded-2xl border border-gray-100 dark:border-gray-800 flex justify-between items-center group">
                                   <div className="overflow-hidden">
                                      <p className="text-xs font-bold dark:text-gray-200 truncate">{sub.email}</p>
                                      <p className="text-[8px] font-black uppercase text-gray-400 mt-1">Joined: {sub.subscribedAt?.toDate?.().toLocaleDateString()}</p>
                                   </div>
                                   <a href={`mailto:${sub.email}`} className="p-2 bg-blue-50 text-blue-600 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"><Send size={12} /></a>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="py-12 text-center text-gray-400">
                               <p className="text-[10px] font-black uppercase tracking-widest">No subscribers yet</p>
                            </div>
                          )}
                       </div>
                    </div>
                  </div>
                </div>
              )}
              
              {activeTab === 'content' && (
                <div className="space-y-12">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest dark:text-white">
                        <Newspaper size={16} className="text-blue-500" /> News Management
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        <button 
                          onClick={() => handleSyncLiveNews(false)}
                          disabled={isLoading}
                          className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
                        >
                          <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} /> Cycle Latest News
                        </button>
                        <button 
                          onClick={() => setShowPostForm(!showPostForm)}
                          className={`w-full md:w-auto px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${showPostForm ? 'bg-red-50 text-red-500' : 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'}`}
                        >
                          {showPostForm ? 'Cancel' : 'Publish Update'}
                        </button>
                      </div>
                   </div>
                   <AnimatePresence>
                     {showPostForm && (
                       <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                         <div className="p-6 md:p-8 bg-gray-50 dark:bg-gray-900 rounded-[32px] space-y-4 border border-blue-500/20 shadow-inner">
                            <input placeholder="Headline" className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl font-bold dark:text-white outline-none" value={newPost.title || ''} onChange={e => setNewPost({...newPost, title: e.target.value})} />
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <select className="bg-white dark:bg-gray-950 p-4 rounded-xl outline-none dark:text-white font-bold" value={newPost.category} onChange={e => setNewPost({...newPost, category: e.target.value as any})}>
                                <option>Federal</option><option>State</option><option>Private</option><option>JAMB</option><option>Polytechnic</option><option>COE</option><option>National</option>
                              </select>
                              <input placeholder="Date (Jan 31)" className="bg-white dark:bg-gray-950 p-4 rounded-xl outline-none dark:text-white font-bold" value={newPost.date || ''} onChange={e => setNewPost({...newPost, date: e.target.value})} />
                            </div>
                            <textarea placeholder="Article Excerpt (Short)..." className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl h-24 outline-none dark:text-white font-bold" value={newPost.excerpt || ''} onChange={e => setNewPost({...newPost, excerpt: e.target.value})} />
                            <textarea placeholder="Full Investigative Content (Long Form)..." className="w-full bg-white dark:bg-gray-950 p-4 rounded-xl h-64 outline-none dark:text-white" value={newPost.fullContent || ''} onChange={e => setNewPost({...newPost, fullContent: e.target.value})} />
                            <button onClick={handlePublishPost} disabled={isPublishing} className="w-full py-4 bg-blue-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest">
                              {isPublishing ? <Loader2 className="animate-spin" size={14} /> : 'Commit News to Feed'}
                            </button>
                         </div>
                       </motion.div>
                     )}
                   </AnimatePresence>
                   
                   <div className="space-y-3">
                      {publishedNews.slice(0, 10).map(news => (
                        <div key={news.id} className="p-4 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-2xl flex items-center justify-between group">
                          <div className="flex items-center gap-4 overflow-hidden">
                             <div className="w-10 h-10 bg-gray-100 dark:bg-gray-900 rounded-xl flex items-center justify-center text-gray-400 shrink-0">
                               {news.hasVideo ? <Zap size={20} className="text-emerald-500" /> : <Newspaper size={20} />}
                             </div>
                             <div className="overflow-hidden">
                                <p className="font-bold text-xs dark:text-white truncate">{news.title}</p>
                                <p className="text-[8px] font-bold text-gray-400 uppercase">{news.category} • {news.date}</p>
                             </div>
                          </div>
                          <div className="flex items-center gap-2">
                             {!news.hasVideo && (
                               <button 
                                 onClick={async () => {
                                   try {
                                     setGeneratingVideoScriptId(news.id);
                                     const script = await generateNewsVideoScript(news);
                                     setGeneratingVideoScriptId(null);
                                     if (script && script.voiceoverText && script.script) {
                                       setGeneratedScript(script);
                                     } else {
                                       alert("Error: AI failed to generate a valid video script. Please try again.");
                                     }
                                   } catch (err) {
                                     setGeneratingVideoScriptId(null);
                                     console.error("Video script generation failed:", err);
                                     alert("Video script generation failed. Please check your internet or API usage.");
                                   }
                                 }}
                                 disabled={generatingVideoScriptId === news.id}
                                 className="p-2 text-emerald-500 hover:bg-emerald-500/10 rounded-lg transition-all disabled:opacity-50"
                                 title="Generate & Post AI Video"
                               >
                                 {generatingVideoScriptId === news.id ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                               </button>
                             )}
                             <button onClick={() => handleDeletePost(news.id)} className="p-2 text-gray-300 hover:text-red-500"><Trash2 size={16} /></button>
                          </div>
                        </div>
                      ))}
                   </div>

                   <div className="pt-12 border-t border-gray-100 dark:border-gray-800">
                      <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest dark:text-white mb-6">
                        <Megaphone size={16} className="text-orange-500" /> Live Ticker Management
                      </h4>
                      <div className="space-y-4">
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={newTickerHeadline} 
                            onChange={(e) => setNewTickerHeadline(e.target.value)} 
                            placeholder="Add new scrolling headline..." 
                            className="flex-1 p-4 bg-gray-50 dark:bg-gray-900 border border-transparent focus:border-orange-500 rounded-2xl font-bold dark:text-white outline-none"
                          />
                          <button 
                            onClick={() => {
                              if (newTickerHeadline.trim()) {
                                setTickerHeadlines([...tickerHeadlines, newTickerHeadline.trim()]);
                                setNewTickerHeadline('');
                              }
                            }}
                            className="px-6 bg-orange-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest"
                          >
                            Add
                          </button>
                        </div>
                        <div className="space-y-2">
                          {tickerHeadlines.map((h, idx) => (
                            <div key={idx} className="p-4 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-2xl flex items-center justify-between group">
                              <p className="text-xs font-bold dark:text-white">{h}</p>
                              <button onClick={() => setTickerHeadlines(tickerHeadlines.filter((_, i) => i !== idx))} className="p-2 text-gray-300 hover:text-red-500"><Trash2 size={16} /></button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-900 rounded-[32px] p-8 space-y-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
                          <Database size={24} />
                        </div>
                        <div>
                          <h3 className="text-xl font-black dark:text-white">Scoring Systems Sync</h3>
                          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Populate University Cutoff Logic</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <p className="text-sm text-gray-500 dark:text-gray-400 font-medium leading-relaxed">
                          This tool iterates through all {universityData.length} universities and uses AI to identify their 2026 aggregate scoring formulas. Data is saved to the cloud cache for instant calculator performance.
                        </p>

                        {isSyncing && (
                          <div className="space-y-3">
                            <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                              <span className="text-blue-500">Syncing: {syncProgress.currentUni}</span>
                              <span className="text-gray-400">{syncProgress.current} / {syncProgress.total}</span>
                            </div>
                            <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                              <motion.div 
                                className="h-full bg-blue-600"
                                initial={{ width: 0 }}
                                animate={{ width: `${(syncProgress.current / syncProgress.total) * 100}%` }}
                              />
                            </div>
                          </div>
                        )}

                        <button 
                          onClick={handleSyncScoring}
                          disabled={isSyncing}
                          className={`w-full py-5 rounded-[24px] font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-3 ${
                            isSyncing 
                              ? 'bg-gray-200 dark:bg-gray-800 text-gray-400 cursor-not-allowed' 
                              : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-500/20'
                          }`}
                        >
                          {isSyncing ? <><Loader2 className="animate-spin" size={18} /> Syncing Data...</> : <><RefreshCw size={18} /> Sync All Scoring Systems</>}
                        </button>
                      </div>
                    </div>
                </div>
              )}

              {activeTab === 'communications' && (
                <div className="space-y-12">
                   <div className="p-6 md:p-10 bg-blue-500/5 dark:bg-blue-500/5 rounded-[40px] border border-blue-500/10">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg">
                          <MessageSquare size={24} />
                        </div>
                        <div>
                          <h3 className="text-xl font-black dark:text-white">Broadcast Hub</h3>
                          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Mass Email Intelligence Dispatch</p>
                        </div>
                      </div>
                      <div className="bg-white dark:bg-gray-800 px-6 py-3 rounded-2xl border border-blue-100 dark:border-blue-900/40 shadow-sm flex items-center gap-3">
                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                         <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Signal Base: <span className="text-blue-600 dark:text-blue-400">{subscribers.length} VERIFIED SCHOLARS</span></p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                      <div className="space-y-6">
                         <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase text-gray-400 ml-2">Email Subject Line</label>
                           <input 
                             value={broadcastForm.subject}
                             onChange={e => setBroadcastForm({...broadcastForm, subject: e.target.value})}
                             className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none focus:border-blue-500 transition-all"
                           />
                         </div>
                         <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase text-gray-400 ml-2">Internal Headline</label>
                           <input 
                             value={broadcastForm.headline}
                             onChange={e => setBroadcastForm({...broadcastForm, headline: e.target.value})}
                             className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none focus:border-blue-500 transition-all"
                           />
                         </div>
                         <div className="space-y-2">
                           <label className="text-[10px] font-black uppercase text-gray-400 ml-2">Body Content (Admission Intel)</label>
                           <textarea 
                             value={broadcastForm.body}
                             onChange={e => setBroadcastForm({...broadcastForm, body: e.target.value})}
                             className="w-full h-56 p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none resize-none focus:border-blue-500 transition-all"
                           />
                         </div>
                         <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase text-gray-400 ml-2">Button Call-to-Action</label>
                              <input value={broadcastForm.ctaText} onChange={e => setBroadcastForm({...broadcastForm, ctaText: e.target.value})} className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none" />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase text-gray-400 ml-2">Landing URL</label>
                              <input value={broadcastForm.ctaLink} onChange={e => setBroadcastForm({...broadcastForm, ctaLink: e.target.value})} className="w-full p-4 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none" />
                            </div>
                         </div>
                         <button 
                           onClick={handleDispatchBroadcast}
                           disabled={isBroadcasting || !broadcastForm.subject || !broadcastForm.body}
                           className="w-full py-5 bg-blue-600 hover:bg-blue-700 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-xl flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
                         >
                           {isBroadcasting ? <Loader2 className="animate-spin" size={18} /> : <><Send size={18} /> Dispatch Broadcast Signal</>}
                         </button>
                      </div>

                      <div className="space-y-4">
                        <label className="text-[10px] font-black uppercase text-gray-400 ml-2 flex items-center gap-2"><Eye size={14} /> Official Intelligence Template</label>
                        <div className="border border-gray-100 dark:border-gray-800 rounded-[40px] overflow-hidden bg-white shadow-2xl scale-95 origin-top">
                           <div className="bg-blue-900 p-8 text-center relative overflow-hidden">
                              <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl"></div>
                              <h1 className="text-white font-black text-2xl tracking-tighter relative z-10">CampusAI.ng</h1>
                              <p className="text-blue-400 text-[9px] font-black uppercase tracking-[0.3em] mt-1 relative z-10">Verified Admission Intelligence</p>
                           </div>
                           <div className="p-10 text-gray-900">
                              <div className="flex items-center gap-2 mb-4">
                                <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></div>
                                <span className="text-[8px] font-black text-red-500 uppercase tracking-widest">High Priority Alert</span>
                              </div>
                              <h2 className="text-2xl font-black mb-6 leading-tight text-gray-950">{broadcastForm.headline}</h2>
                              <div className="text-sm leading-relaxed text-gray-700 whitespace-pre-wrap mb-10 font-medium">
                                 {broadcastForm.body}
                              </div>
                              <div className="text-center">
                                 <div className="inline-block px-10 py-5 bg-blue-600 text-white font-black text-[11px] rounded-xl uppercase tracking-widest shadow-xl shadow-blue-500/20">{broadcastForm.ctaText}</div>
                              </div>
                           </div>
                           <div className="bg-gray-50 p-8 border-t border-gray-100 text-center">
                              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">&copy; 2026 CampusAI — Federated Intelligence Network</p>
                              <div className="flex items-center justify-center gap-2 mt-3">
                                 <ShieldCheck size={12} className="text-gray-300" />
                                 <p className="text-[8px] text-gray-300 uppercase tracking-tighter">Sent via encrypted cloud nodes. No action required.</p>
                              </div>
                           </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {activeTab === 'status' && (
                <div className="space-y-12">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-red-500/20">
                      <AlertTriangle size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black dark:text-white">Global Status Center</h3>
                      <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Manage Critical Academic Alerts</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-900 rounded-[40px] p-8 border border-gray-100 dark:border-gray-800 space-y-8">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-white dark:bg-gray-800 rounded-xl flex items-center justify-center text-red-500 shadow-sm">
                          <Brain size={20} />
                        </div>
                        <div>
                          <h4 className="font-black dark:text-white uppercase tracking-widest text-xs">ASUU Strike Status</h4>
                          <p className="text-[10px] text-gray-400 font-bold">Last Updated: {asuuStatus.lastUpdated ? new Date(asuuStatus.lastUpdated).toLocaleString() : 'Never'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-[10px] font-black uppercase tracking-widest ${asuuStatus.isActive ? 'text-red-500' : 'text-emerald-500'}`}>
                          {asuuStatus.isActive ? 'Active Strike' : 'Academic Peace'}
                        </span>
                        <button 
                          onClick={() => setAsuuStatus({...asuuStatus, isActive: !asuuStatus.isActive})}
                          className={`w-12 h-6 rounded-full relative transition-colors ${asuuStatus.isActive ? 'bg-red-500' : 'bg-gray-300 dark:bg-gray-700'}`}
                        >
                          <motion.div 
                            animate={{ x: asuuStatus.isActive ? 24 : 2 }}
                            className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
                          />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">Header / Status (2 words)</label>
                      <input 
                        type="text"
                        value={asuuStatus.status}
                        onChange={(e) => setAsuuStatus({...asuuStatus, status: e.target.value})}
                        placeholder="e.g. No Strike"
                        className="w-full p-4 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none focus:border-red-500 transition-all mb-4"
                      />
                      
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-2">Strike Details / Intelligence</label>
                      <textarea 
                        value={asuuStatus.summary}
                        onChange={(e) => setAsuuStatus({...asuuStatus, summary: e.target.value})}
                        placeholder="Provide latest intelligence on strike status..."
                        className="w-full h-32 p-4 bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-2xl font-bold dark:text-white outline-none focus:border-red-500 transition-all"
                      />
                    </div>

                    <button 
                      onClick={handleUpdateAsuuStatus}
                      disabled={isUpdatingAsuu}
                      className="w-full py-5 bg-red-600 text-white rounded-3xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-500/20 flex items-center justify-center gap-3"
                    >
                      {isUpdatingAsuu ? <Loader2 className="animate-spin" size={18} /> : <><Save size={18} /> Update Strike Intelligence</>}
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'analytics' && (
                <div className="space-y-12">
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                      <div className="p-6 bg-blue-50 dark:bg-blue-900/20 rounded-[32px] border border-blue-100 dark:border-blue-800">
                         <p className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-2">Total Scholars</p>
                         <h3 className="text-3xl font-black dark:text-white">{totalUserCount}</h3>
                         <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-emerald-500">
                            <Zap size={12} /> +12% this week
                         </div>
                      </div>
                      <div className="p-6 bg-emerald-50 dark:bg-emerald-900/20 rounded-[32px] border border-emerald-100 dark:border-emerald-800">
                         <p className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest mb-2">AI Interactions</p>
                         <h3 className="text-3xl font-black dark:text-white">12,482</h3>
                         <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-emerald-500">
                            <Activity size={12} /> 98.4% Success
                         </div>
                      </div>
                      <div className="p-6 bg-orange-50 dark:bg-orange-900/20 rounded-[32px] border border-orange-100 dark:border-orange-800">
                         <p className="text-[10px] font-black text-orange-600 dark:text-orange-400 uppercase tracking-widest mb-2">Revenue (Est.)</p>
                         <h3 className="text-3xl font-black dark:text-white">₦42.5k</h3>
                         <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-orange-500">
                            <DollarSign size={12} /> +5% vs prev
                         </div>
                      </div>
                      <div className="p-6 bg-purple-50 dark:bg-purple-900/20 rounded-[32px] border border-purple-100 dark:border-purple-800">
                         <p className="text-[10px] font-black text-purple-600 dark:text-purple-400 uppercase tracking-widest mb-2">Video Reach</p>
                         <h3 className="text-3xl font-black dark:text-white">8.2k</h3>
                         <div className="mt-4 flex items-center gap-2 text-[10px] font-bold text-purple-500">
                            <Monitor size={12} /> TikTok/YouTube
                         </div>
                      </div>
                   </div>

                   <div className="p-8 bg-gray-50 dark:bg-gray-900 rounded-[40px] border border-gray-100 dark:border-gray-800">
                      <div className="flex items-center justify-between mb-8">
                         <h3 className="text-xl font-black dark:text-white">System Performance</h3>
                         <button className="px-4 py-2 bg-white dark:bg-gray-800 rounded-xl text-[10px] font-black uppercase tracking-widest border border-gray-100 dark:border-gray-700">Export Report</button>
                      </div>
                      <div className="space-y-6">
                         <div className="space-y-2">
                            <div className="flex justify-between text-[10px] font-black uppercase text-gray-400">
                               <span>Gemini Logic Latency</span>
                               <span>240ms avg</span>
                            </div>
                            <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                               <div className="h-full bg-blue-500 w-[15%]"></div>
                            </div>
                         </div>
                         <div className="space-y-2">
                            <div className="flex justify-between text-[10px] font-black uppercase text-gray-400">
                               <span>Firebase Write Throughput</span>
                               <span>1.2k req/min</span>
                            </div>
                            <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                               <div className="h-full bg-emerald-500 w-[45%]"></div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
              )}

              {activeTab === 'seo' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
                      <Globe size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black dark:text-white">SEO Management</h3>
                      <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Optimize Search Visibility</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Site Title</label>
                      <input 
                        type="text" 
                        value={seoConfig.title}
                        onChange={(e) => setSeoConfig({ ...seoConfig, title: e.target.value })}
                        className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 text-sm font-medium"
                      />
                    </div>
                    <div className="space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Keywords (Comma Separated)</label>
                      <input 
                        type="text" 
                        value={seoConfig.keywords}
                        onChange={(e) => setSeoConfig({ ...seoConfig, keywords: e.target.value })}
                        className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 text-sm font-medium"
                      />
                    </div>
                    <div className="md:col-span-2 space-y-4">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Meta Description</label>
                      <textarea 
                        value={seoConfig.description}
                        onChange={(e) => setSeoConfig({ ...seoConfig, description: e.target.value })}
                        className="w-full bg-gray-50 dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-2xl p-4 text-sm font-medium h-32"
                      />
                    </div>
                  </div>

                  <button 
                    onClick={handleSaveSeo}
                    className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20"
                  >
                    Save SEO Settings
                  </button>
                </motion.div>
              )}

              {activeTab === 'faq' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
                      <MessageSquare size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black dark:text-white">FAQ Management</h3>
                      <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Manage User Help Content</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-900 rounded-3xl p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Question</label>
                        <input 
                          type="text" 
                          value={newFaq.question}
                          onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
                          className="w-full bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-xl p-3 text-sm font-medium"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Category</label>
                        <select 
                          value={newFaq.category}
                          onChange={(e) => setNewFaq({ ...newFaq, category: e.target.value })}
                          className="w-full bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-xl p-3 text-sm font-medium"
                        >
                          <option>General</option>
                          <option>Admission</option>
                          <option>Payment</option>
                          <option>Technical</option>
                        </select>
                      </div>
                      <div className="md:col-span-2 space-y-2">
                        <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Answer</label>
                        <textarea 
                          value={newFaq.answer}
                          onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
                          className="w-full bg-white dark:bg-gray-950 border border-gray-100 dark:border-gray-800 rounded-xl p-3 text-sm font-medium h-24"
                        />
                      </div>
                    </div>
                    <button 
                      onClick={handleAddFaq}
                      className="w-full py-4 bg-gray-900 dark:bg-white dark:text-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-[1.02] transition-all"
                    >
                      Add FAQ Item
                    </button>
                  </div>

                  <div className="space-y-4">
                    {faqs.map((faq, idx) => (
                      <div key={idx} className="p-6 border border-gray-100 dark:border-gray-800 rounded-3xl flex justify-between items-start gap-4">
                        <div>
                          <span className="text-[8px] font-black uppercase tracking-widest px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded-md mb-2 inline-block">{faq.category}</span>
                          <h4 className="font-bold text-gray-900 dark:text-white mb-1">{faq.question}</h4>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{faq.answer}</p>
                        </div>
                        <button 
                          onClick={() => setFaqs(faqs.filter((_, i) => i !== idx))}
                          className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={handleSaveFaqs}
                    className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-500/20"
                  >
                    Save All FAQs
                  </button>
                </motion.div>
              )}

              {/* MORNING BRIEFING TAB */}
              {activeTab === 'briefing' && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
                        <Sun size={20} className="text-orange-400" /> Morning Briefing
                      </h3>
                      <p className="text-xs text-gray-500 mt-1">AI searches for today's latest updates and generates ready-to-post WhatsApp & Telegram messages.</p>
                    </div>
                    <button
                      onClick={handleGenerateBriefing}
                      disabled={isBriefingLoading}
                      className="flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-600 disabled:opacity-50 transition-all shadow-lg shadow-orange-500/20"
                    >
                      {isBriefingLoading ? <><Loader2 size={14} className="animate-spin" /> Searching...</> : <><Sun size={14} /> Generate Today's Briefing</>}
                    </button>
                  </div>

                  {!briefing && !isBriefingLoading && (
                    <div className="py-20 text-center space-y-3 border-2 border-dashed border-gray-100 dark:border-gray-800 rounded-3xl">
                      <Sun size={40} className="text-orange-300 mx-auto" />
                      <p className="text-sm font-bold text-gray-400">Click "Generate Today's Briefing" to fetch the latest Nigerian university updates</p>
                      <p className="text-xs text-gray-300">Takes about 15–20 seconds. Uses Google Search to find real updates.</p>
                    </div>
                  )}

                  {isBriefingLoading && (
                    <div className="py-20 text-center space-y-3">
                      <Loader2 size={40} className="text-orange-400 mx-auto animate-spin" />
                      <p className="text-sm font-bold text-gray-400">Searching the web for today's updates...</p>
                      <p className="text-xs text-gray-300">Checking JAMB, Post-UTME, Admission Lists, ASUU, NYSC & more</p>
                    </div>
                  )}

                  {briefing && !isBriefingLoading && (
                    <div className="space-y-6">
                      {/* Date & Summary */}
                      <div className="p-5 bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800/30 rounded-2xl">
                        <p className="text-[10px] font-black uppercase tracking-widest text-orange-500 mb-1">{briefing.date}</p>
                        <p className="text-sm font-bold text-gray-700 dark:text-gray-300">{briefing.summary}</p>
                      </div>

                      {/* Individual Updates */}
                      <div className="space-y-3">
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-400">Today's Updates ({briefing.updates?.length || 0})</h4>
                        {briefing.updates?.map((update: any, i: number) => (
                          <div key={i} className="p-5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] font-black uppercase tracking-widest px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-cyan-400 rounded-full">{update.category}</span>
                              <button
                                onClick={() => handleCopy(update.readyToPost, `update-${i}`)}
                                className="flex items-center gap-1.5 text-[9px] font-black uppercase text-gray-400 hover:text-blue-600 transition-colors"
                              >
                                {copiedKey === `update-${i}` ? <><Check size={12} className="text-emerald-500" /> Copied</> : <><ClipboardCopy size={12} /> Copy Post</>}
                              </button>
                            </div>
                            <p className="font-black text-gray-900 dark:text-white text-sm">{update.headline}</p>
                            <p className="text-xs text-gray-500 leading-relaxed">{update.detail}</p>
                            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs text-gray-600 dark:text-gray-400 whitespace-pre-wrap">{update.readyToPost}</div>
                          </div>
                        ))}
                      </div>

                      {/* Free WhatsApp Post */}
                      <div className="p-5 bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-800/30 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-green-600">📱 Free WhatsApp Post</h4>
                          <button
                            onClick={() => handleCopy(briefing.whatsappFreePost, 'whatsapp-free')}
                            className="flex items-center gap-1.5 text-[9px] font-black uppercase text-gray-400 hover:text-green-600 transition-colors"
                          >
                            {copiedKey === 'whatsapp-free' ? <><Check size={12} className="text-emerald-500" /> Copied!</> : <><ClipboardCopy size={12} /> Copy</>}
                          </button>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">{briefing.whatsappFreePost}</p>
                      </div>

                      {/* Premium WhatsApp Post */}
                      <div className="p-5 bg-green-100 dark:bg-green-800/20 border border-green-200 dark:border-green-700/30 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-green-700 dark:text-green-400">💎 Premium WhatsApp Post</h4>
                          <button
                            onClick={() => handleCopy(briefing.whatsappPremiumPost, 'whatsapp-premium')}
                            className="flex items-center gap-1.5 text-[9px] font-black uppercase text-gray-400 hover:text-green-700 transition-colors"
                          >
                            {copiedKey === 'whatsapp-premium' ? <><Check size={12} className="text-emerald-500" /> Copied!</> : <><ClipboardCopy size={12} /> Copy</>}
                          </button>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">{briefing.whatsappPremiumPost}</p>
                      </div>

                      {/* Free Telegram Post */}
                      <div className="p-5 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-blue-600">✈️ Free Telegram Post</h4>
                          <button
                            onClick={() => handleCopy(briefing.telegramFreePost, 'telegram-free')}
                            className="flex items-center gap-1.5 text-[9px] font-black uppercase text-gray-400 hover:text-blue-600 transition-colors"
                          >
                            {copiedKey === 'telegram-free' ? <><Check size={12} className="text-emerald-500" /> Copied!</> : <><ClipboardCopy size={12} /> Copy</>}
                          </button>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">{briefing.telegramFreePost}</p>
                      </div>

                      {/* Premium Telegram Post */}
                      <div className="p-5 bg-cyan-50 dark:bg-cyan-900/20 border border-cyan-100 dark:border-cyan-800/30 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-cyan-600">💎 Premium Telegram Post</h4>
                          <button
                            onClick={() => handleCopy(briefing.telegramPremiumPost, 'telegram-premium')}
                            className="flex items-center gap-1.5 text-[9px] font-black uppercase text-gray-400 hover:text-cyan-600 transition-colors"
                          >
                            {copiedKey === 'telegram-premium' ? <><Check size={12} className="text-emerald-500" /> Copied!</> : <><ClipboardCopy size={12} /> Copy</>}
                          </button>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">{briefing.telegramPremiumPost}</p>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </>
          )}
        </div>

        <div className="p-6 md:p-8 border-t border-gray-100 dark:border-gray-900 shrink-0 bg-gray-50/50 dark:bg-gray-950 flex flex-col md:flex-row justify-between items-center gap-4">
          <button onClick={onAdminLogout} className="flex items-center justify-center gap-2 text-[10px] font-black uppercase text-red-500 hover:scale-105 transition-all"><LogOut size={18} /> Terminate Sessions</button>
          <button onClick={handleSave} disabled={saved || !admin.isLoggedIn} className={`w-full md:w-auto px-12 py-5 rounded-3xl font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl ${saved ? 'bg-emerald-500 text-white' : 'bg-red-600 text-white hover:bg-red-700 disabled:opacity-50'}`}>
            {saved ? <><CheckCircle2 size={18} /> System Synchronized</> : <><Save size={18} /> Save Global Parameters</>}
          </button>
        </div>
      </div>
      
      {/* Generated Script Modal */}
      {generatedScript && (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setGeneratedScript(null)} />
          <div className="relative bg-white dark:bg-gray-900 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 bg-emerald-500 text-white flex justify-between items-center shrink-0">
              <h2 className="text-xl font-black uppercase tracking-tighter flex items-center gap-2">
                <Sparkles size={24} /> AI Video Script Generated
              </h2>
              <button onClick={() => setGeneratedScript(null)} className="p-2 hover:bg-white/20 rounded-full transition-all">
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 md:p-8 overflow-y-auto space-y-6">
              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Suggested Title</h3>
                <p className="text-lg font-black dark:text-white">{generatedScript.suggestedTitle}</p>
              </div>

              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 flex justify-between items-center">
                  Voiceover Transcript
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(generatedScript.voiceoverText);
                      alert("Voiceover copied!");
                    }}
                    className="text-[10px] text-emerald-500 hover:text-emerald-600 flex items-center gap-1"
                  >
                    <ClipboardCopy size={12} /> COPY
                  </button>
                </h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <p className="text-sm leading-relaxed dark:text-gray-300 whitespace-pre-wrap">{generatedScript.voiceoverText}</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 flex justify-between items-center">
                  Full Script (Spoken Words)
                  <button 
                    onClick={() => {
                      navigator.clipboard.writeText(generatedScript.script);
                      alert("Script copied!");
                    }}
                    className="text-[10px] text-emerald-500 hover:text-emerald-600 flex items-center gap-1"
                  >
                    <ClipboardCopy size={12} /> COPY
                  </button>
                </h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <p className="text-sm leading-relaxed dark:text-gray-300 whitespace-pre-wrap">{generatedScript.script}</p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Visual Cues</h3>
                <ul className="list-disc pl-5 space-y-1">
                  {generatedScript.visualCues?.map((cue: string, idx: number) => (
                    <li key={idx} className="text-sm text-gray-600 dark:text-gray-400">{cue}</li>
                  ))}
                </ul>
              </div>

              {generatedScript.hashtags && generatedScript.hashtags.length > 0 && (
                <div>
                  <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Hashtags</h3>
                  <div className="flex flex-wrap gap-2">
                    {generatedScript.hashtags.map((tag: string, idx: number) => (
                      <span key={idx} className="px-3 py-1 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 font-bold text-[10px] uppercase tracking-wider rounded-lg">
                        {tag.startsWith('#') ? tag : `#${tag}`}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <div className="p-6 border-t border-gray-100 dark:border-gray-800 shrink-0 flex gap-4">
               <button 
                 onClick={() => {
                   setGeneratedScript(null);
                   alert("Video scheduled for automated production. Metrics will appear in Analytics shortly.");
                 }}
                 className="flex-1 py-4 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-600 transition-all flex items-center justify-center gap-2"
               >
                 <CheckCircle2 size={16} /> Schedule Auto-Post
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;