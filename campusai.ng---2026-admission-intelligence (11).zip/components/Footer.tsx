
import React from 'react';
import { Home, School, ShieldCheck, Mail, Twitter, Facebook, Instagram, Linkedin, Youtube, ArrowUp, Github, ExternalLink, Globe, MessageCircle, Lock, Cpu } from 'lucide-react';
import { motion } from 'framer-motion';

interface FooterProps {
  onNavigate: (page: string) => void;
  onOpenLegal: (type: 'privacy' | 'terms') => void;
  onOpenSupport: () => void;
  isAdmin?: boolean;
  socialLinks?: {
    facebook: string;
    twitter: string;
    instagram: string;
    linkedin: string;
    youtube: string;
  };
}

const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenLegal, onOpenSupport, isAdmin, socialLinks }) => {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-950 text-white pt-24 pb-12 border-t border-white/5 relative overflow-hidden">
      {/* Decorative Glow */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-cyan-400 to-emerald-500"></div>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          {/* Brand Column */}
          <div className="space-y-8">
            <div className="flex flex-col items-start">
              <span className="text-3xl font-black tracking-tighter">
                Campus<span className="text-cyan-400">AI</span><span className="opacity-70 font-bold">.ng</span>
              </span>
              <div className="flex items-center gap-2 mt-2 px-3 py-1 bg-white/5 rounded-lg border border-white/10">
                 <Cpu size={12} className="text-blue-500" />
                 <span className="text-[8px] font-black uppercase tracking-widest text-gray-400">Node Cluster: Lagos_West</span>
              </div>
              <p className="text-gray-400 text-sm mt-6 leading-relaxed font-medium">
                The premiere high-intelligence companion for the Nigerian student journey. Empowering the 2026 academic cycle with real-time data and neural logic.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              {socialLinks?.twitter && (
                <a href={socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="w-11 h-11 bg-white/5 rounded-xl flex items-center justify-center hover:bg-blue-400 transition-all active:scale-90 border border-white/10 group">
                  <Twitter size={20} className="group-hover:scale-110 transition-transform" />
                </a>
              )}
              {socialLinks?.facebook && (
                <a href={socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="w-11 h-11 bg-white/5 rounded-xl flex items-center justify-center hover:bg-blue-700 transition-all active:scale-90 border border-white/10 group">
                  <Facebook size={20} className="group-hover:scale-110 transition-transform" />
                </a>
              )}
              {socialLinks?.instagram && (
                <a href={socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="w-11 h-11 bg-white/5 rounded-xl flex items-center justify-center hover:bg-pink-600 transition-all active:scale-90 border border-white/10 group">
                  <Instagram size={20} className="group-hover:scale-110 transition-transform" />
                </a>
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 mb-8">Navigation Hub</h4>
            <ul className="space-y-5">
              {[
                { label: 'Home Orbit', id: 'home' },
                { label: 'Federal Directory', id: 'federal' },
                { label: 'State Gateways', id: 'state' },
                { label: 'AI Strategist', id: 'ai' },
                { label: 'Official JAMB News', id: 'jamb' }
              ].map((item) => (
                <li key={item.id}>
                  <button 
                    onClick={() => onNavigate(item.id)}
                    className="text-gray-400 hover:text-white transition-all text-sm font-bold flex items-center gap-3 group"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-gray-800 group-hover:bg-cyan-400 group-hover:scale-150 transition-all"></div>
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Governance & Compliance */}
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-500 mb-8">Governance</h4>
            <ul className="space-y-5">
              <li>
                <button onClick={() => onOpenLegal('terms')} className="text-gray-400 hover:text-white transition-colors text-sm font-bold flex items-center gap-2">Terms of Service <ExternalLink size={12} className="opacity-20" /></button>
              </li>
              <li>
                <button onClick={() => onOpenLegal('privacy')} className="text-gray-400 hover:text-white transition-colors text-sm font-bold flex items-center gap-2">Privacy Protocol <ExternalLink size={12} className="opacity-20" /></button>
              </li>
              {isAdmin && (
                <li className="pt-6">
                  <button 
                    onClick={() => onNavigate('admin')}
                    className="w-full py-3 bg-red-600/10 border border-red-600/20 text-red-500 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-2 hover:bg-red-600 hover:text-white transition-all animate-pulse"
                  >
                    <Lock size={12} /> Architect Portal
                  </button>
                </li>
              )}
            </ul>
          </div>

          {/* Support Node */}
          <div className="bg-white/5 p-8 rounded-[40px] border border-white/10 shadow-2xl relative">
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-blue-600/10 rounded-full blur-2xl"></div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-cyan-400 mb-6 flex items-center gap-2">
              <MessageCircle size={14} /> Command Desk
            </h4>
            <p className="text-xs text-gray-400 mb-8 font-medium leading-relaxed">
              Facing synchronization issues or billing errors? Connect with our human architects for rapid resolution.
            </p>
            <button 
              onClick={onOpenSupport} 
              className="flex items-center justify-center gap-3 w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-[20px] text-[10px] font-black uppercase tracking-widest transition-all shadow-xl shadow-blue-900/40 active:scale-95"
            >
              <Mail size={16} /> Open Ticket
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start">
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-600">
              © {currentYear} CAMPUSAI.NG — FEDERATED INTELLIGENCE NETWORK
            </p>
            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-emerald-500" />
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Verified Academic Entity</span>
              </div>
              <div className="w-1 h-1 bg-gray-800 rounded-full"></div>
              <span className="text-[9px] font-black text-gray-700 uppercase tracking-widest">Lagos, NG</span>
            </div>
          </div>

          <button 
            onClick={scrollToTop}
            className="group flex items-center gap-4 px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all active:scale-95"
          >
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 group-hover:text-white transition-colors">Back to Orbit</span>
            <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center group-hover:-translate-y-1 transition-transform shadow-lg shadow-blue-600/20">
              <ArrowUp size={18} />
            </div>
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
