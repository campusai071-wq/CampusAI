import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Loader2, Map as MapIcon, ShieldCheck, AlertCircle, Zap, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { findCBTCenters } from '../services/geminiService';
import { getLocalProfile, checkAndIncrementRequests } from '../services/userService';
import QuotaModal from './QuotaModal';

interface CBTCenterFinderProps {
  userCoords?: { lat: number; lng: number };
  onLoginRequest: () => void;
}

const CBTCenterFinder: React.FC<CBTCenterFinderProps> = ({ userCoords, onLoginRequest }) => {
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [isQuotaModalOpen, setIsQuotaModalOpen] = useState(false);

  useEffect(() => {
    getLocalProfile();
  }, []);

  const findCenters = async () => {
    const profile = getLocalProfile();
    if (!profile.uid) { onLoginRequest(); return; }
    if (!userCoords) return;

    // Quota Check
    const { allowed } = await checkAndIncrementRequests(profile.uid);
    if (!allowed) {
      setIsQuotaModalOpen(true);
      return;
    }

    setIsSearching(true);
    setResults([]);
    try {
      const centers = await findCBTCenters(userCoords.lat, userCoords.lng);
      setResults(centers.slice(0, 3));
    } finally { setIsSearching(false); }
  };

  return (
    <section id="cbt-finder" className="py-24 bg-gray-50 dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800">
      <div className="container mx-auto px-4 md:px-8">
        <div className="bg-white dark:bg-gray-950 rounded-[48px] p-8 md:p-16 shadow-2xl relative overflow-hidden">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <div className="lg:w-1/2">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-cyan-400 rounded-full text-[10px] font-black uppercase mb-6 border border-blue-100 dark:border-blue-800"><MapPin size={12} />Geo-Intelligence</div>
              <h2 className="text-4xl md:text-5xl font-black mb-6 tracking-tight dark:text-white">Accredited <span className="text-blue-600 dark:text-cyan-400">Centers</span></h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium text-lg mb-10 leading-relaxed">Map verified JAMB-accredited exam locations instantly using your coordinates. Our GPS node cross-references the 2026 official database.</p>
              
              <button 
                onClick={findCenters} 
                disabled={isSearching || !userCoords} 
                className="w-full sm:w-auto px-12 py-6 bg-blue-600 hover:bg-blue-500 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-blue-600/20 flex items-center justify-center gap-3 active:scale-95 transition-all disabled:opacity-50"
              >
                {isSearching ? <Loader2 className="animate-spin" size={20} /> : <><Navigation size={20} /> Locate Centers</>}
              </button>

              {!userCoords && !isSearching && (
                 <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-4 ml-2">Location access required for Geo-Search.</p>
              )}
            </div>
            <div className="lg:w-1/2 w-full min-h-[300px] border-2 border-dashed border-gray-100 dark:border-gray-800 rounded-[40px] flex items-center justify-center bg-gray-50/50 dark:bg-gray-900/50">
               {results.length > 0 ? (
                 <div className="w-full p-6 space-y-4">
                   {results.map((r, i) => (
                     <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} key={i} className="p-5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl flex items-center justify-between shadow-sm group hover:border-blue-400 transition-all">
                        <div className="flex items-center gap-4 overflow-hidden">
                           <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/40 rounded-xl flex items-center justify-center text-blue-600 dark:text-cyan-400 shrink-0"><MapIcon size={18} /></div>
                           <p className="font-bold text-sm truncate dark:text-white">{r.title}</p>
                        </div>
                        <a href={r.uri} target="_blank" className="text-blue-600 dark:text-cyan-400 font-black text-[10px] uppercase tracking-widest whitespace-nowrap ml-4 hover:underline">Get Directions</a>
                     </motion.div>
                   ))}
                 </div>
               ) : (
                 <div className="text-center opacity-40">
                   <MapIcon size={64} className="text-gray-300 dark:text-gray-700 mx-auto mb-4" />
                   <p className="text-sm font-black uppercase tracking-widest text-gray-400">Awaiting Signal</p>
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>
      <QuotaModal 
        isOpen={isQuotaModalOpen} 
        onClose={() => setIsQuotaModalOpen(false)} 
        onUpgrade={() => {
          setIsQuotaModalOpen(false);
          window.dispatchEvent(new CustomEvent('campusai_open_payment'));
        }} 
      />
    </section>
  );
};

export default CBTCenterFinder;
