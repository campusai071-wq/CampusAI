import React, { useState, useEffect } from 'react';
import { Smartphone, Download, X, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const InstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      // Check if user has already dismissed it
      const isDismissed = localStorage.getItem('campusai_install_dismissed');
      if (!isDismissed) setIsVisible(true);
    };

    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
    
    if (isIOS && !isStandalone) {
      const isDismissed = localStorage.getItem('campusai_install_dismissed');
      if (!isDismissed) {
        setIsVisible(true);
      }
    }

    // Auto-show fallback after 10 seconds if not dismissed and not already installed
    const timer = setTimeout(() => {
      const isDismissed = localStorage.getItem('campusai_install_dismissed');
      if (!isDismissed && !isStandalone) {
        setIsVisible(true);
      }
    }, 10000);

    // Listen for manual trigger from settings
    const handleManualTrigger = () => setIsVisible(true);
    window.addEventListener('campusai_trigger_install', handleManualTrigger);

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('campusai_trigger_install', handleManualTrigger);
      clearTimeout(timer);
    };
  }, []);

  const handleInstall = async () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    
    if (isIOS) {
      alert("To install CampusAI on iOS: Tap the 'Share' button in Safari and select 'Add to Home Screen'.");
      return;
    }

    if (!deferredPrompt) {
      alert("To install CampusAI: Tap your browser's menu (\u22EE) and select 'Install app' or 'Add to Home screen'.");
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsVisible(false);
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setIsVisible(false);
    localStorage.setItem('campusai_install_dismissed', 'true');
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div 
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-[164px] left-4 right-24 z-[160] md:bottom-24 md:right-auto md:left-8 md:w-80"
        >
          <div className="bg-gray-900 text-white p-4 rounded-[28px] shadow-2xl border border-white/10 flex items-center gap-4">
             <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shrink-0 shadow-lg">
               <Smartphone size={24} />
             </div>
             <div className="flex-grow">
                <p className="text-[10px] font-black uppercase text-blue-400 tracking-widest flex items-center gap-1">
                   <Sparkles size={10} /> App Version Available
                </p>
                <p className="text-xs font-bold leading-tight">Install CampusAI on your home screen for offline use.</p>
             </div>
             <div className="flex flex-col gap-2">
                <button onClick={handleInstall} className="p-2 bg-white text-gray-900 rounded-xl hover:bg-blue-400 transition-colors">
                  <Download size={18} />
                </button>
                <button onClick={handleDismiss} className="p-2 bg-white/10 text-gray-400 rounded-xl hover:text-white">
                  <X size={18} />
                </button>
             </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default InstallPrompt;