import React from 'react';
import { Helmet } from 'react-helmet-async';
import { stringify } from '../services/utils';

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  article?: boolean;
  keywords?: string;
}

const SEO: React.FC<SEOProps> = ({ title, description, image, article, keywords }) => {
  const siteName = "CampusAI.ng";
  const fullTitle = title ? `${title} | ${siteName}` : "CampusAI.ng — Nigeria's #1 AI Admission Intelligence for 2026";
  const defaultDescription = "Free AI-powered JAMB cutoff calculator, aggregate calculator, Post-UTME tracker and admission predictions for Nigerian students 2026. Check your admission chances instantly.";
  const metaDescription = description || defaultDescription;
  const defaultKeywords = "JAMB 2026, cutoff marks Nigeria, aggregate calculator, Post-UTME 2026, admission chances Nigeria, UNILAG admission, UI OAU ABU UNN cutoff";
  const metaKeywords = keywords || defaultKeywords;
  const metaImage = image || "https://picsum.photos/seed/campus/1200/630";
  const url = window.location.href;

  const structuredData = article ? {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": title || siteName,
    "description": metaDescription,
    "image": [metaImage],
    "datePublished": new Date().toISOString(),
    "author": {
      "@type": "Organization",
      "name": siteName,
      "url": "https://campusai.ng"
    }
  } : {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": siteName,
    "url": "https://campusai.ng",
    "description": defaultDescription,
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://campusai.ng/?search={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };

  return (
    <Helmet>
      {/* Standard metadata tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="keywords" content={metaKeywords} />
      
      {/* Open Graph / Facebook / WhatsApp */}
      <meta property="og:type" content={article ? 'article' : 'website'} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:image" content={metaImage} />
      <meta property="og:url" content={url} />
      <meta property="og:site_name" content={siteName} />

      {/* SEO Moat: Authority Meta Tags */}
      <meta name="google-site-verification" content="n07lx2H6ou5qr0uS9BwlEYwX-27Jt2E27QYnJpD0jHQ" />
      <meta name="msvalidate.01" content="YOUR_BING_VERIFICATION_CODE_HERE" />
      <meta name="yandex-verification" content="YOUR_YANDEX_VERIFICATION_CODE_HERE" />
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={metaImage} />

      {/* Canonical URL */}
      <link rel="canonical" href={url} />

      {/* Structured Data */}
      <script type="application/ld+json">
        {stringify(structuredData)}
      </script>
    </Helmet>
  );
};

export default SEO;
