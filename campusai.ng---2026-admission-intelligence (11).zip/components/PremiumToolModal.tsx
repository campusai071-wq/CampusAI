import React, { useState } from 'react';
import { stringify } from '../services/utils';
import { polishEssay, generateProjectTopic, researchAssistant } from '../services/premiumToolsService';

interface PremiumToolModalProps {
  tool: { id: string; name: string; description: string };
  onClose: () => void;
}

const PremiumToolModal: React.FC<PremiumToolModalProps> = ({ tool, onClose }) => {
  const [input, setInput] = useState('');
  const [pages, setPages] = useState(1);
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleRun = async () => {
    setLoading(true);
    try {
      if (tool.id === 'essay_polisher') {
        setResult(await polishEssay(input));
      } else if (tool.id === 'topic_generator') {
        setResult(await generateProjectTopic(input));
      } else if (tool.id === 'research_assistant') {
        setResult(await researchAssistant(input, pages));
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[1000]">
      <div className="bg-white p-8 rounded-2xl w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-4">{tool.name}</h2>
        <p className="mb-4">{tool.description}</p>
        <textarea 
          className="w-full p-2 border rounded mb-4" 
          value={input} 
          onChange={(e) => setInput(e.target.value)}
          placeholder={tool.id === 'essay_polisher' ? 'Paste your essay here...' : 'Enter department or topic...'}
        />
        {tool.id === 'research_assistant' && (
          <input 
            type="number" 
            value={pages} 
            onChange={(e) => setPages(parseInt(e.target.value))} 
            className="w-full p-2 border rounded mb-4"
            placeholder="Number of pages"
          />
        )}
        <button onClick={handleRun} className="bg-blue-600 text-white px-4 py-2 rounded" disabled={loading}>
          {loading ? 'Processing...' : 'Run Tool'}
        </button>
        <button onClick={onClose} className="ml-2 text-gray-500">Close</button>
        {result && (
          <div className="mt-4 p-4 bg-gray-100 rounded max-h-60 overflow-y-auto">
            <pre className="whitespace-pre-wrap text-xs">{stringify(result)}</pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default PremiumToolModal;
