
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calculator, Plus, Trash2, RefreshCw, Award, Info, ChevronDown, ChevronUp, Lock, Brain } from 'lucide-react';
import { analyzeCGPA } from '../services/premiumToolsService';

interface Course {
  id: string;
  name: string;
  units: number;
  grade: string;
}

const GRADE_VALUES_5: Record<string, number> = {
  'A': 5, 'B': 4, 'C': 3, 'D': 2, 'E': 1, 'F': 0
};

const GRADE_VALUES_4: Record<string, number> = {
  'A': 4, 'B': 3, 'C': 2, 'D': 1, 'F': 0
};

interface CGPACalculatorProps {
  user?: any;
  isPremium?: boolean;
  onUpgrade?: () => void;
}

const CGPACalculator: React.FC<CGPACalculatorProps> = ({ user, isPremium, onUpgrade }) => {
  const [scale, setScale] = useState<4 | 5>(5);
  const [courses, setCourses] = useState<Course[]>([
    { id: '1', name: '', units: 3, grade: 'A' }
  ]);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  const runAnalysis = async () => {
    setAnalyzing(true);
    const analysis = await analyzeCGPA(Number(results.gpa), 'Current', user?.role, user?.university, user?.targetCourse);
    setAnalysis(analysis || null);
    setAnalyzing(false);
  };

  const addCourse = () => {
    if (!isPremium) {
      onUpgrade?.();
      return;
    }
    setCourses([...courses, { id: Math.random().toString(36).substr(2, 9), name: '', units: 3, grade: 'A' }]);
  };

  const removeCourse = (id: string) => {
    if (courses.length > 1) {
      setCourses(courses.filter(c => c.id !== id));
    }
  };

  const updateCourse = (id: string, field: keyof Course, value: any) => {
    setCourses(courses.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const reset = () => {
    setCourses([{ id: '1', name: '', units: 3, grade: 'A' }]);
  };

  const results = useMemo(() => {
    const gradeValues = scale === 5 ? GRADE_VALUES_5 : GRADE_VALUES_4;
    let totalUnits = 0;
    let totalPoints = 0;

    courses.forEach(c => {
      const units = Number(c.units) || 0;
      const point = gradeValues[c.grade] || 0;
      totalUnits += units;
      totalPoints += (units * point);
    });

    const gpa = totalUnits > 0 ? (totalPoints / totalUnits).toFixed(2) : '0.00';
    
    let classOfDegree = 'N/A';
    const gpaNum = Number(gpa);
    if (scale === 5) {
      if (gpaNum >= 4.5) classOfDegree = 'First Class';
      else if (gpaNum >= 3.5) classOfDegree = 'Second Class Upper';
      else if (gpaNum >= 2.4) classOfDegree = 'Second Class Lower';
      else if (gpaNum >= 1.5) classOfDegree = 'Third Class';
      else if (gpaNum >= 1.0) classOfDegree = 'Pass';
      else classOfDegree = 'Fail';
    } else {
      if (gpaNum >= 3.5) classOfDegree = 'First Class';
      else if (gpaNum >= 3.0) classOfDegree = 'Second Class Upper';
      else if (gpaNum >= 2.0) classOfDegree = 'Second Class Lower';
      else if (gpaNum >= 1.0) classOfDegree = 'Pass';
      else classOfDegree = 'Fail';
    }

    return { gpa, totalUnits, totalPoints, classOfDegree };
  }, [courses, scale]);

  return (
    <section id="cgpa" className="py-20 bg-white dark:bg-gray-950 transition-colors relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
      
      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-purple-100 dark:border-purple-800">
                <Calculator size={12} />
                Academic Logic
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 dark:text-white tracking-tighter leading-tight">
                CGPA <span className="text-purple-600">Calculator</span>
              </h2>
              <p className="text-gray-500 dark:text-gray-400 font-medium max-w-md">
                Calculate your semester GPA or cumulative CGPA with precision. Supports both 4.0 and 5.0 grading scales.
              </p>
            </div>

            <div className="flex bg-gray-100 dark:bg-gray-900 p-1 rounded-2xl border border-gray-200 dark:border-gray-800">
              <button 
                onClick={() => setScale(5)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${scale === 5 ? 'bg-white dark:bg-gray-800 text-purple-600 shadow-lg' : 'text-gray-400'}`}
              >
                5.0 Scale
              </button>
              <button 
                onClick={() => setScale(4)}
                className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${scale === 4 ? 'bg-white dark:bg-gray-800 text-purple-600 shadow-lg' : 'text-gray-400'}`}
              >
                4.0 Scale
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
            {!isPremium && (
              <div className="absolute inset-0 z-50 backdrop-blur-[2px] bg-white/10 dark:bg-gray-950/10 flex items-center justify-center rounded-[48px]">
                <div className="bg-white dark:bg-gray-900 p-8 rounded-[32px] shadow-2xl border border-gray-100 dark:border-gray-800 text-center max-w-sm mx-4">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-600/20">
                    <Lock size={28} />
                  </div>
                  <h4 className="text-xl font-black dark:text-white mb-3 uppercase tracking-tight">Premium Logic Only</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400 font-medium mb-8">
                    The CGPA Calculator is a premium tool reserved for Scholar Pack members.
                  </p>
                  <button 
                    onClick={onUpgrade}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-blue-600/20"
                  >
                    Activate Scholar Pack
                  </button>
                </div>
              </div>
            )}
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white dark:bg-gray-900 rounded-[32px] border border-gray-100 dark:border-gray-800 shadow-xl overflow-hidden">
                <div className="p-6 md:p-8 border-b border-gray-50 dark:border-gray-800 flex items-center justify-between">
                  <h3 className="text-sm font-black uppercase tracking-widest text-gray-400">Course Inventory</h3>
                  <button onClick={reset} className="text-gray-400 hover:text-red-500 transition-colors">
                    <RefreshCw size={16} />
                  </button>
                </div>
                
                <div className="p-6 md:p-8 space-y-4 max-h-[500px] overflow-y-auto custom-scrollbar">
                  <AnimatePresence initial={false}>
                    {courses.map((course, index) => (
                      <motion.div 
                        key={course.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="grid grid-cols-12 gap-4 items-center"
                      >
                        <div className="col-span-6 md:col-span-7">
                          <label htmlFor={`course-name-${course.id}`} className="sr-only">Course Name</label>
                          <input 
                            id={`course-name-${course.id}`}
                            name={`course-name-${course.id}`}
                            type="text" 
                            placeholder="Course Name (Optional)" 
                            value={course.name}
                            onChange={(e) => updateCourse(course.id, 'name', e.target.value)}
                            className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-3.5 text-sm font-bold outline-none focus:border-purple-500 transition-all"
                          />
                        </div>
                        <div className="col-span-3 md:col-span-2">
                          <label htmlFor={`course-units-${course.id}`} className="sr-only">Units</label>
                          <select 
                            id={`course-units-${course.id}`}
                            name={`course-units-${course.id}`}
                            value={course.units}
                            onChange={(e) => updateCourse(course.id, 'units', Number(e.target.value))}
                            className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-3.5 text-sm font-bold outline-none focus:border-purple-500 transition-all"
                          >
                            {[1, 2, 3, 4, 5, 6].map(u => <option key={u} value={u}>{u} Units</option>)}
                          </select>
                        </div>
                        <div className="col-span-2 md:col-span-2">
                          <label htmlFor={`course-grade-${course.id}`} className="sr-only">Grade</label>
                          <select 
                            id={`course-grade-${course.id}`}
                            name={`course-grade-${course.id}`}
                            value={course.grade}
                            onChange={(e) => updateCourse(course.id, 'grade', e.target.value)}
                            className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-3.5 text-sm font-bold outline-none focus:border-purple-500 transition-all"
                          >
                            {Object.keys(scale === 5 ? GRADE_VALUES_5 : GRADE_VALUES_4).map(g => <option key={g} value={g}>{g}</option>)}
                          </select>
                        </div>
                        <div className="col-span-1 flex justify-end">
                          <button 
                            onClick={() => removeCourse(course.id)}
                            className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>

                <div className="p-6 md:p-8 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-100 dark:border-gray-800">
                  <button 
                    onClick={addCourse}
                    className="w-full py-4 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-2xl flex items-center justify-center gap-2 text-gray-400 hover:border-purple-500 hover:text-purple-600 transition-all font-bold text-sm"
                  >
                    <Plus size={18} /> Add Another Course
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-purple-600 rounded-[32px] p-8 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
                
                <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 opacity-60">Neural Computation</h3>
                
                <div className="space-y-8">
                  <div>
                    <span className="text-sm font-bold opacity-60 block mb-1">Current GPA</span>
                    <div className="text-6xl font-black tracking-tighter">{results.gpa}</div>
                    <button 
                      onClick={runAnalysis}
                      className="mt-4 w-full bg-white/20 hover:bg-white/30 text-white rounded-xl py-2 text-xs font-bold flex items-center justify-center gap-2 transition-all"
                      disabled={analyzing}
                    >
                      <Brain size={14} /> {analyzing ? 'Analyzing...' : 'Get AI Analysis'}
                    </button>
                    {analysis && (
                      <div className="mt-4 p-4 bg-white/10 rounded-xl text-xs text-white/90 max-h-40 overflow-y-auto">
                        {analysis}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/10 rounded-2xl p-4">
                      <span className="text-[9px] font-black uppercase tracking-widest opacity-60 block mb-1">Total Units</span>
                      <span className="text-xl font-black">{results.totalUnits}</span>
                    </div>
                    <div className="bg-white/10 rounded-2xl p-4">
                      <span className="text-[9px] font-black uppercase tracking-widest opacity-60 block mb-1">Total Points</span>
                      <span className="text-xl font-black">{results.totalPoints}</span>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-white/10">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                        <Award size={20} />
                      </div>
                      <div>
                        <span className="text-[9px] font-black uppercase tracking-widest opacity-60 block">Classification</span>
                        <span className="text-sm font-black">{results.classOfDegree}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-900 rounded-[32px] p-8 border border-gray-100 dark:border-gray-800 shadow-xl">
                <h4 className="text-sm font-black uppercase tracking-widest text-gray-400 mb-6 flex items-center gap-2">
                  <Info size={14} /> Grading Logic
                </h4>
                <div className="space-y-3">
                  {Object.entries(scale === 5 ? GRADE_VALUES_5 : GRADE_VALUES_4).map(([grade, point]) => (
                    <div key={grade} className="flex items-center justify-between text-sm">
                      <span className="font-bold text-gray-500">{grade} Grade</span>
                      <span className="font-black text-gray-900 dark:text-white">{point.toFixed(1)} Points</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CGPACalculator;
