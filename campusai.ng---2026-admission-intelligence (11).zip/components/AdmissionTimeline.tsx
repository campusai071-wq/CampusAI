import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { getAdmissionTimeline } from '../services/admissionTrackerService';
import { AdmissionTimeline } from '../types';

export const AdmissionTimelineDisplay: React.FC<{ isPremium?: boolean }> = ({ isPremium = false }) => {
  const [university, setUniversity] = useState('');
  const [timeline, setTimeline] = useState<AdmissionTimeline | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTimeline = async (uni: string) => {
    if (!uni) return;
    setLoading(true);
    setError(null);
    try {
      const data = await getAdmissionTimeline(uni, isPremium);
      setTimeline(data);
    } catch (err) {
      setError('Could not load timeline.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-900 rounded-[32px] shadow-xl border border-gray-100 dark:border-gray-800">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <h2 className="text-2xl font-black mb-4 dark:text-white">Admission Tracker</h2>
        <div className="relative">
          <input
            type="text"
            value={university}
            onChange={(e) => setUniversity(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchTimeline(university)}
            placeholder="Search university (e.g., FUTA, UNILAG)..."
            className="w-full pl-12 pr-4 py-4 bg-gray-100 dark:bg-gray-800 rounded-2xl border-none focus:ring-2 focus:ring-blue-500 dark:text-white"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => fetchTimeline(university)}
            className="absolute right-2 top-2 bottom-2 px-6 bg-blue-600 text-white rounded-xl font-bold"
          >
            Track
          </motion.button>
        </div>
      </motion.div>

      {loading && <div className="text-center py-8 dark:text-white">Loading timeline...</div>}
      {error && <div className="text-center py-8 text-red-500">{error}</div>}
      
      {timeline && !loading && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-4"
        >
          <h3 className="text-lg font-black dark:text-white">{timeline.university} Admission Timeline</h3>
          <table className="w-full text-left">
            <thead>
              <tr className="text-gray-400 text-xs uppercase tracking-widest">
                <th className="pb-2">Stage</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Date</th>
                <th className="pb-2"></th>
              </tr>
            </thead>
            <tbody>
              {timeline.stages.map((s, i) => (
                <tr key={i} className="border-t border-gray-100 dark:border-gray-800">
                  <td className="py-3 font-medium dark:text-gray-300">{s.stage}</td>
                  <td className="py-3 font-bold">
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                      s.status === 'Completed' ? 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' :
                      s.status === 'In Progress' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' :
                      'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                    }`}>{s.status}</span>
                  </td>
                  <td className="py-3 dark:text-white font-bold text-sm">{s.likelyDate || 'TBD'}</td>
                  <td className="py-3">
                    {s.confidence && (
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                        s.confidence === 'Confirmed' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' :
                        'bg-orange-100 text-orange-500 dark:bg-orange-900/30 dark:text-orange-400'
                      }`}>{s.confidence}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {(timeline as any).predictionNote && (
            <p className="text-xs text-orange-500 dark:text-orange-400 mt-3 bg-orange-50 dark:bg-orange-900/20 px-3 py-2 rounded-xl">
              💡 {(timeline as any).predictionNote}
            </p>
          )}
          <p className="text-xs text-gray-400 mt-2">Last Updated: {timeline.lastUpdated}</p>
        </motion.div>
      )}
    </div>
  );
};