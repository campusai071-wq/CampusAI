import React, { useState, useEffect } from 'react';
import { Megaphone, Home, Laptop, Zap, CheckCircle, ExternalLink, PlusCircle, Sparkles, X, DollarSign, ShieldCheck, ArrowRight, ShoppingBag, Layout, Image, Send, Loader2, PartyPopper } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
// @ts-ignore
import { useFlutterwave, closePaymentModal } from 'flutterwave-react-v3';
import { BillboardAd, AdPackage } from '../types';
import { getCloudAds, submitPendingAd, savePremiumSubscription } from '../services/dbService';
import { MASTER_CONFIG, auth } from '../services/firebaseConfig';
import PremiumSuccessModal from './PremiumSuccessModal';
import PremiumExplanationModal from './PremiumExplanationModal';

const AD_PACKAGES: AdPackage[] = [
  {
    id: 'basic',
    name: "Student Basic",
    price: "₦2,500",
    amountKobo: 2500, // Flutterwave uses real amount, not kobo
    duration: "7 Days",
    features: ["Standard Grid Slot", "WhatsApp Integration", "Category Tag"],
    color: "bg-blue-500"
  },
  {
    id: 'premium',
    name: "Premium Billboard",
    price: "₦15,000",
    amountKobo: 15000,
    duration: "30 Days",
    features: ["Priority Top Placement", "Verified Badge", "Highlighted Border", "30 Days Constant Display", "Best for Serious Brands"],
    color: "bg-gradient-to-r from-emerald-500 to-teal-600"
  },
  {
    id: 'partner',
    name: "Campus Partner",
    price: "₦50,000",
    amountKobo: 50000,
    duration: "Full Semester",
    features: ["Hero Section Banner", "Social Media Spotlight", "Email Newsletter Inclusion"],
    color: "bg-purple-600"
  }
];

const DEFAULT_ADS: BillboardAd[] = [
  {
    id: 'campusai-premium',
    title: '🎓 CampusAI Premium Channel',
    description: 'Get daily admission alerts, Post-UTME dates, cutoff predictions & morning briefings before anyone else. Join 50+ students already inside.',
    category: 'Services',
    price: '₦500/month',
    link: '#',
    whatsapp: '2349169760634',
    isVerified: true,
    isSponsored: false,
    status: 'active'
  },
  {
    id: 'def1',
    title: 'Your Business Here',
    description: 'Reach 50,000+ Nigerian students globally. Your ad will show on every device after approval.',
    category: 'Services',
    price: '₦2,500/wk',
    link: '#',
    isVerified: true,
    isSponsored: true,
    status: 'active'
  }
];

const BillboardBanner: React.FC = () => {
  const [showCreator, setShowCreator] = useState(false);
  const [creatorStep, setCreatorStep] = useState<'package' | 'details' | 'success'>('package');
  const [ads, setAds] = useState<BillboardAd[]>([]);
  const [selectedPackage, setSelectedPackage] = useState<AdPackage | null>(null);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showExplanationModal, setShowExplanationModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [form, setForm] = useState<Partial<BillboardAd>>({
    title: '',
    description: '',
    category: 'Services',
    price: '₦',
    whatsapp: '',
    link: 'https://'
  });

  const adminWhatsapp = localStorage.getItem('campusai_whatsapp') || '2349169760634';

  const loadAds = async () => {
    const cloudAds = await getCloudAds();
    setAds(cloudAds.length > 0 ? cloudAds : DEFAULT_ADS);
  };

  useEffect(() => {
    loadAds();
    window.addEventListener('campusai_ads_updated', loadAds);
    return () => window.removeEventListener('campusai_ads_updated', loadAds);
  }, []);

  const getFlutterwaveKey = () => {
    return MASTER_CONFIG.FLUTTERWAVE_PUBLIC_KEY || localStorage.getItem('campusai_flutterwave_key') || "FLWPUBK_TEST_PLACEHOLDER";
  };

  const fwConfig = {
    public_key: getFlutterwaveKey(),
    tx_ref: Date.now().toString(),
    amount: selectedPackage?.amountKobo || 0,
    currency: 'NGN',
    payment_options: 'card,mobilemoney,ussd',
    customer: {
      email: 'advertiser@campusai.ng',
      phone_number: form.whatsapp || '08000000000',
      name: 'CampusAI Advertiser',
    },
    customizations: {
      title: 'CampusAI Marketplace',
      description: `Payment for ${selectedPackage?.name} ad package`,
      logo: 'https://campusai.ng/favicon.svg',
    },
  };

  const handleFlutterPayment = useFlutterwave(fwConfig);

  const premiumFwConfig = {
    public_key: getFlutterwaveKey(),
    tx_ref: 'premium_' + Date.now().toString(),
    amount: 500,
    currency: 'NGN',
    payment_options: 'card,mobilemoney,ussd',
    customer: {
      email: auth.currentUser?.email || 'student@campusai.ng',
      phone_number: '08000000000',
      name: 'CampusAI Student',
    },
    customizations: {
      title: 'CampusAI Premium',
      description: 'Daily admission alerts & briefings',
      logo: 'https://campusai.ng/favicon.svg',
    },
  };
  
  const handlePremiumPayment = useFlutterwave(premiumFwConfig);

  const handleCreateAd = () => {
    if (!form.title || !form.description) return;
    
    handleFlutterPayment({
      callback: async (response) => {
        if (response.status === "successful") {
          setIsSubmitting(true);
          const adData: Omit<BillboardAd, 'id'> = {
            title: form.title!,
            description: form.description!,
            category: form.category as any,
            price: form.price,
            whatsapp: form.whatsapp,
            link: form.link || '#',
            isVerified: false,
            isSponsored: true,
            status: 'pending',
            paidAmount: selectedPackage?.price
          };

          const adId = await submitPendingAd(adData);
          if (adId) {
            setCreatorStep('success');
            const msg = `Hello Admin, I just paid ${selectedPackage?.price} via Flutterwave for a Billboard Ad. Ad ID: ${adId}. Content: ${form.title}`;
            setTimeout(() => {
              window.open(`https://wa.me/${adminWhatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`, '_blank');
            }, 2000);
          }
          setIsSubmitting(false);
          closePaymentModal();
        }
      },
      onClose: () => {},
    });
  };

  const getIcon = (cat: string) => {
    switch (cat) {
      case 'Hostels': return <Home size={18} />;
      case 'Gadgets': return <Laptop size={18} />;
      case 'Tutorials': return <Zap size={18} />;
      default: return <Megaphone size={18} />;
    }
  };

  return (
    <section className="py-20 bg-white dark:bg-gray-950">
      <div className="container mx-auto px-4 md:px-8">
        <div className="bg-gray-900 dark:bg-blue-950 rounded-[56px] p-8 md:p-16 relative overflow-hidden border border-white/5 shadow-2xl">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-500/10 blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="flex flex-col lg:flex-row items-center justify-between gap-16 relative z-10">
            <div className="lg:w-1/3 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-cyan-500/20 text-cyan-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-6 border border-cyan-500/20">
                <Sparkles size={12} />
                Global Marketplace
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-6 leading-[1.1]">
                Promote to <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400">Scholars</span>
              </h2>
              <p className="text-gray-400 font-medium mb-10 text-lg leading-relaxed">
                Reach over 50,000 active admission seekers. Your verified campaign will display across all student devices globally.
              </p>
              
              <button 
                onClick={() => { setShowCreator(true); setCreatorStep('package'); }}
                className="flex items-center justify-center gap-2 px-10 py-5 bg-white text-gray-900 rounded-3xl font-black text-xs uppercase tracking-widest hover:bg-cyan-400 transition-all active:scale-95 shadow-2xl shadow-cyan-500/20 w-full sm:w-auto"
              >
                <PlusCircle size={20} />
                Get Advert Space
              </button>
            </div>

            <div className="lg:w-2/3 w-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Pinned CampusAI self-promo — always first */}
                {[...ads].sort((a) => a.id === 'campusai-premium' ? -1 : 1).map((ad, idx) => (
                  <motion.div
                    key={ad.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className={`backdrop-blur-xl border p-8 rounded-[40px] group hover:border-cyan-500/50 transition-all cursor-pointer flex flex-col justify-between h-full min-h-[260px] ${
                      ad.id === 'campusai-premium'
                        ? 'bg-gradient-to-br from-cyan-500/20 to-emerald-500/10 border-cyan-500/40 ring-1 ring-cyan-500/30'
                        : 'bg-white/5 border-white/10'
                    }`}
                    onClick={() => {
                      if (ad.id === 'campusai-premium') {
                        setShowExplanationModal(true);
                      } else if (ad.whatsapp) {
                        window.open(`https://wa.me/${ad.whatsapp.replace(/\D/g, '')}`, '_blank');
                      } else if (ad.link !== '#') {
                        window.open(ad.link, '_blank');
                      }
                    }}
                  >
                    <div>
                      <div className="flex justify-between items-start mb-6">
                        <div className={`p-4 rounded-2xl transition-all duration-500 ${ad.id === 'campusai-premium' ? 'bg-cyan-500 text-white' : 'bg-white/10 text-cyan-400 group-hover:bg-cyan-500 group-hover:text-white'}`}>
                          {ad.id === 'campusai-premium' ? <Send size={18} /> : getIcon(ad.category)}
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          {ad.id === 'campusai-premium'
                            ? <span className="text-[8px] font-black uppercase tracking-widest text-cyan-400 bg-cyan-400/10 px-2 py-1 rounded-full border border-cyan-400/30">Official</span>
                            : <span className="text-[8px] font-black uppercase tracking-widest text-cyan-400/60 bg-cyan-400/5 px-2 py-1 rounded-md border border-cyan-400/10">Sponsored</span>
                          }
                          {ad.isVerified && <div className="flex items-center gap-1 text-[8px] font-black uppercase tracking-widest text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full border border-emerald-400/20"><ShieldCheck size={10} /> Verified</div>}
                        </div>
                      </div>
                      <h4 className={`font-bold text-xl mb-3 transition-colors ${ad.id === 'campusai-premium' ? 'text-cyan-300 group-hover:text-white' : 'text-white group-hover:text-cyan-400'}`}>{ad.title}</h4>
                      <p className="text-gray-400 text-sm leading-relaxed mb-6 line-clamp-2">{ad.description}</p>
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-6 border-t border-white/5">
                      <div className="flex flex-col">
                        <span className="text-white font-black text-lg">{ad.price}</span>
                        <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">{ad.id === 'campusai-premium' ? 'Premium Access' : ad.category}</span>
                      </div>
                      <div className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${ad.id === 'campusai-premium' ? 'bg-cyan-500 text-white hover:bg-white hover:text-gray-900' : 'bg-white/10 hover:bg-white hover:text-gray-900'}`}>
                        {ad.id === 'campusai-premium' ? 'Join Now' : 'Check Offer'} <ArrowRight size={14} />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <PremiumSuccessModal isOpen={showPremiumModal} onClose={() => setShowPremiumModal(false)} />
      <PremiumExplanationModal 
        isOpen={showExplanationModal} 
        onClose={() => setShowExplanationModal(false)}
        onProceed={() => {
            setShowExplanationModal(false);
            handlePremiumPayment({
              callback: async (response) => {
                 if (response.status === "successful") {
                     await savePremiumSubscription({
                         email: auth.currentUser?.email || 'student@campusai.ng',
                         paymentTimestamp: new Date(),
                         tx_ref: response.tx_ref
                     });
                     closePaymentModal();
                     setShowPremiumModal(true);
                 }
              },
              onClose: () => {}
            });
        }}
      />

      <AnimatePresence>
        {showCreator && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => !isSubmitting && setShowCreator(false)} className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} className="relative bg-white dark:bg-gray-900 w-full max-w-5xl rounded-[48px] overflow-hidden shadow-2xl flex flex-col md:flex-row max-h-[90vh]">
               
               <button onClick={() => { setShowCreator(false); setAgreedToTerms(false); }} className="absolute top-6 right-6 z-50 p-2 bg-gray-100 dark:bg-gray-800 rounded-full hover:scale-110 transition-transform"><X size={20} /></button>

               {/* Left Panel: Preview/Info */}
               <div className="md:w-2/5 bg-gray-50 dark:bg-black/40 p-8 md:p-12 border-r border-gray-100 dark:border-gray-800 overflow-y-auto">
                  <div className="mb-10">
                    <h3 className="text-2xl font-black dark:text-white mb-2">Campaign Studio</h3>
                    <p className="text-sm text-gray-500 font-medium">Design your billboard ad and launch globally in minutes.</p>
                  </div>

                  <div className="space-y-8">
                     <div className="p-6 bg-white dark:bg-gray-900 rounded-[32px] border-2 border-dashed border-gray-200 dark:border-gray-800">
                        <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest mb-6 flex items-center gap-2"><Layout size={14} /> Live Billboard Preview</p>
                        
                        <div className="bg-gray-900 rounded-3xl p-6 border border-white/10 shadow-xl">
                          <div className="flex justify-between items-start mb-6">
                            <div className="p-3 bg-white/10 rounded-xl text-cyan-400">
                              {getIcon(form.category || 'Services')}
                            </div>
                            <span className="text-[8px] font-black uppercase text-cyan-400/60 bg-cyan-400/5 px-2 py-1 rounded-md border border-cyan-400/10">Paid Ad</span>
                          </div>
                          <h4 className="text-white font-bold text-lg mb-2">{form.title || 'Ad Headline Here'}</h4>
                          <p className="text-gray-400 text-xs leading-relaxed line-clamp-2 mb-6">{form.description || 'Describe your product or service to attract students...'}</p>
                          <div className="flex items-center justify-between pt-4 border-t border-white/5">
                            <span className="text-white font-black text-sm">{form.price || '₦0.00'}</span>
                            <div className="px-4 py-1.5 bg-white/10 rounded-lg text-[9px] font-black text-white uppercase">Preview</div>
                          </div>
                        </div>
                     </div>

                     <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-900/10 rounded-2xl border border-emerald-100 dark:border-emerald-800">
                           <p className="text-[8px] font-black text-emerald-600 uppercase mb-1">Global Reach</p>
                           <p className="text-sm font-bold dark:text-white">50k+ Scholars</p>
                        </div>
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/10 rounded-2xl border border-blue-100 dark:border-blue-800">
                           <p className="text-[8px] font-black text-blue-600 uppercase mb-1">Duration</p>
                           <p className="text-sm font-bold dark:text-white">{selectedPackage?.duration || '7-30 Days'}</p>
                        </div>
                     </div>
                  </div>
               </div>

               {/* Right Panel: Content Form */}
               <div className="md:w-3/5 p-8 md:p-12 overflow-y-auto no-scrollbar">
                  <AnimatePresence mode="wait">
                    {creatorStep === 'package' && (
                      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                        <h4 className="text-xl font-black dark:text-white">Step 1: Choose Package</h4>
                        <div className="grid grid-cols-1 gap-4">
                          {AD_PACKAGES.map(pkg => (
                            <button 
                              key={pkg.id} 
                              onClick={() => { setSelectedPackage(pkg); setCreatorStep('details'); }}
                              className="w-full flex items-center justify-between p-6 bg-gray-50 dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 border border-gray-100 dark:border-gray-700 rounded-3xl transition-all group text-left"
                            >
                              <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 ${pkg.color} rounded-2xl flex items-center justify-center text-white shadow-lg`}><DollarSign size={24} /></div>
                                <div>
                                  <p className="font-black dark:text-white">{pkg.name}</p>
                                  <p className="text-xs text-gray-400 font-bold uppercase">{pkg.duration} Visibility</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-xl font-black dark:text-white">{pkg.price}</p>
                                <ArrowRight size={20} className="ml-auto text-gray-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                              </div>
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {creatorStep === 'details' && (
                      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                        <div className="flex items-center justify-between">
                           <h4 className="text-xl font-black dark:text-white">Step 2: Ad Details</h4>
                           <button onClick={() => { setCreatorStep('package'); setAgreedToTerms(false); }} className="text-[10px] font-black uppercase text-blue-600 underline">Change Package</button>
                        </div>
                        
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                              <label className="text-[9px] font-black uppercase text-gray-400 ml-2">Ad Category</label>
                              <select 
                                value={form.category} 
                                onChange={e => setForm({...form, category: e.target.value as any})}
                                className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none appearance-none"
                              >
                                <option>Services</option><option>Hostels</option><option>Gadgets</option><option>Tutorials</option>
                              </select>
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-[9px] font-black uppercase text-gray-400 ml-2">Asking Price</label>
                              <input 
                                value={form.price} 
                                onChange={e => setForm({...form, price: e.target.value})}
                                placeholder="e.g. ₦15,000"
                                className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none"
                              />
                            </div>
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[9px] font-black uppercase text-gray-400 ml-2">Campaign Headline</label>
                            <input 
                              value={form.title} 
                              onChange={e => setForm({...form, title: e.target.value})}
                              placeholder="e.g. Clean Hostel Space at UNILAG"
                              className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none border-2 border-transparent focus:border-blue-500"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[9px] font-black uppercase text-gray-400 ml-2">Ad Description</label>
                            <textarea 
                              value={form.description} 
                              onChange={e => setForm({...form, description: e.target.value})}
                              placeholder="Describe what you are selling..."
                              className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none h-24 border-2 border-transparent focus:border-blue-500"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                              <label className="text-[9px] font-black uppercase text-gray-400 ml-2">WhatsApp Line</label>
                              <input 
                                value={form.whatsapp} 
                                onChange={e => setForm({...form, whatsapp: e.target.value})}
                                placeholder="23481..."
                                className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-[9px] font-black uppercase text-gray-400 ml-2">Website Link (Optional)</label>
                              <input 
                                value={form.link} 
                                onChange={e => setForm({...form, link: e.target.value})}
                                placeholder="https://..."
                                className="w-full bg-gray-50 dark:bg-gray-800 p-4 rounded-2xl font-bold dark:text-white outline-none"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Terms & Conditions */}
                        <div 
                          onClick={() => setAgreedToTerms(!agreedToTerms)}
                          className={`flex items-start gap-3 p-4 rounded-2xl border-2 cursor-pointer transition-all ${agreedToTerms ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20' : 'border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800'}`}
                        >
                          <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${agreedToTerms ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300 dark:border-gray-600'}`}>
                            {agreedToTerms && <CheckCircle size={12} className="text-white" />}
                          </div>
                          <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400 leading-relaxed">
                            I confirm that my ad content is <span className="font-black text-gray-700 dark:text-gray-200">legitimate, accurate, and appropriate</span> for a student audience. I understand CampusAI reserves the right to reject content that violates community standards. <span className="font-black text-gray-700 dark:text-gray-200">Approved ads go live within 24 hours. Rejected ads are refunded within 24 hours.</span>
                          </p>
                        </div>

                        <button 
                          onClick={handleCreateAd}
                          disabled={isSubmitting || !form.title || !form.description || !agreedToTerms}
                          className="w-full py-5 bg-blue-600 hover:bg-blue-700 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <><DollarSign size={18} /> Launch via Flutterwave</>}
                        </button>
                        {!agreedToTerms && (
                          <p className="text-[9px] text-orange-500 text-center font-bold uppercase tracking-widest">Please agree to the terms above to continue</p>
                        )}
                        <p className="text-[9px] text-gray-400 text-center font-bold uppercase tracking-widest">Global Payouts Secured by Flutterwave</p>
                      </motion.div>
                    )}

                    {creatorStep === 'success' && (
                       <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12 space-y-8">
                          <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/40">
                             <PartyPopper size={48} />
                          </div>
                          <div>
                            <h4 className="text-3xl font-black dark:text-white mb-2">Payment Verified!</h4>
                            <p className="text-gray-500 font-medium">Your campaign has been submitted for final approval. You will receive a notification from our team shortly.</p>
                          </div>
                          <div className="p-6 bg-blue-50 dark:bg-blue-900/20 rounded-[32px] border border-blue-100 dark:border-blue-800">
                             <p className="text-[10px] font-black text-blue-600 uppercase mb-2">What Happens Next?</p>
                             <ul className="text-xs font-bold text-gray-600 dark:text-gray-400 space-y-2 text-left list-disc list-inside">
                                <li>Admin verifies your content manually.</li>
                                <li>Verification badge is added to your ad.</li>
                                <li>Campaign goes live globally on all devices.</li>
                             </ul>
                          </div>
                          <button onClick={() => setShowCreator(false)} className="w-full py-5 bg-gray-900 dark:bg-blue-600 text-white rounded-3xl font-black text-xs uppercase tracking-widest">Return to CampusAI</button>
                       </motion.div>
                    )}
                  </AnimatePresence>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default BillboardBanner;