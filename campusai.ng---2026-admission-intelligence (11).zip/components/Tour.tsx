import React, { useState, useEffect } from 'react';
import Joyride, { Step } from 'react-joyride';

const Tour: React.FC = () => {
  const [run, setRun] = useState(false);

  useEffect(() => {
    const hasSeenTour = localStorage.getItem('campusai_has_seen_tour');
    if (!hasSeenTour) {
      setRun(true);
    }
  }, []);

  const steps: Step[] = [
    {
      target: 'body',
      content: 'Welcome to CampusAI! Let us show you around.',
      placement: 'center',
    },
    {
      target: '.navbar-ai-button',
      content: 'Ask our AI any questions about your academic journey.',
    },
    {
      target: '.news-grid',
      content: 'Stay updated with the latest news and updates.',
    },
    {
      target: '.premium-tools',
      content: 'Access premium tools to help you succeed.',
    },
  ];

  return (
    <Joyride
      steps={steps}
      run={run}
      continuous={true}
      showSkipButton={true}
      callback={(data) => {
        if (data.status === 'finished' || data.status === 'skipped') {
          localStorage.setItem('campusai_has_seen_tour', 'true');
          setRun(false);
        }
      }}
      styles={{
        options: {
          primaryColor: '#2563eb',
        },
      }}
    />
  );
};

export default Tour;
