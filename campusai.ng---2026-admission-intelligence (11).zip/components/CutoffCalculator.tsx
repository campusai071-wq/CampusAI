
import React, { useState, useMemo, useEffect } from 'react';
import { Target, GraduationCap, Loader2, Sparkles, RefreshCw, Brain, Search, ShieldCheck, BookOpen, ArrowRight, Lock, Activity, Check, Lightbulb, Share2, Calculator, X, ChevronDown, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { OLevelGrade } from '../types';
import universityData from '../universities';
import { getCourseCutoffInfo, getUniversityCourses, getUniversityScoringSystem } from '../services/geminiService';
import { getLocalProfile, checkAndIncrementRequests, DAILY_LIMIT, getUserProfile, saveUserProfile } from '../services/userService';
import { getGlobalScoringSystem, saveGlobalScoringSystem } from '../services/dbService';
import QuotaModal from './QuotaModal';

const GRADE_POINTS: Record<OLevelGrade, number> = {
  'A1': 10, 'B2': 9, 'B3': 8, 'C4': 7, 'C5': 6, 'C6': 5, 'D7': 0, 'E8': 0, 'F9': 0
};

const GRADES: OLevelGrade[] = ['A1', 'B2', 'B3', 'C4', 'C5', 'C6', 'D7', 'E8', 'F9'];

const TOP_INSTITUTION_MAP: Record<string, ScoringSystem> = {
  'futa': { hasJamb: true, hasPostUtme: false, hasOLevel: true, explanation: "FUTA Point-Based: (JAMB / 8) + O-Level points. Max 100." },
  'futminna': { hasJamb: true, hasPostUtme: true, hasOLevel: true, explanation: "FUTMinna (50:30:20): JAMB(50) + Post-UTME(30) + O-Level(20)." },
  'unilag': { hasJamb: true, hasPostUtme: true, hasOLevel: true, explanation: "UNILAG (50:30:20): JAMB(50) + Post-UTME(30) + O-Level(20)." },
  'ui': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "UI (50:50): Average of JAMB and Post-UTME." },
  'oau': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "OAU (50:50): Weighted JAMB and CBT Screening." },
  'lasu': { hasJamb: true, hasPostUtme: false, hasOLevel: true, explanation: "LASU Point-Based: JAMB points + O-Level Verification points." },
  'funaab': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "FUNAAB (50:50): JAMB and Screening average." },
  'abu': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "ABU (50:50): JAMB and Post-UTME average." },
  'unn': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "UNN (50:50): JAMB and Post-UTME average." },
  'unilorin': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "UNILORIN (50:50): JAMB and Post-UTME average." },
  'uniben': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "UNIBEN (50:50): JAMB and Post-UTME average." },
  'uniport': { hasJamb: true, hasPostUtme: true, hasOLevel: false, explanation: "UNIPORT (50:50): JAMB and Post-UTME average." }
};

interface ScoringSystem {
  hasJamb: boolean;
  hasPostUtme: boolean;
  hasOLevel: boolean;
  explanation: string;
}

const ProbabilityGauge: React.FC<{ probability: number }> = ({ probability }) => {
  const getColor = () => {
    if (probability > 75) return 'text-emerald-500';
    if (probability > 50) return 'text-cyan-400';
    if (probability > 30) return 'text-orange-500';
    return 'text-red-500';
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-40 h-20 overflow-hidden">
        <div className="absolute top-0 left-0 w-40 h-40 border-[12px] border-white/5 rounded-full"></div>
        <motion.div 
          initial={{ rotate: -90 }}
          animate={{ rotate: -90 + (probability * 1.8) }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className={`absolute top-0 left-0 w-40 h-40 border-[12px] border-current rounded-full ${getColor()}`}
          style={{ clipPath: 'polygon(50% 50%, 0 0, 100% 0, 100% 50%, 0 50%)' }}
        ></motion.div>
      </div>
      <div className="mt-4 text-center">
        <p className={`text-4xl font-black ${getColor()}`}>{probability}%</p>
        <p className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Admission Probability</p>
      </div>
    </div>
  );
};

const CutoffCalculator: React.FC<{ user: any; onLoginRequest: () => void; onDiscussWithAI: (p: string) => void }> = ({ user, onLoginRequest, onDiscussWithAI }) => {
  const [jambScore, setJambScore] = useState('');
  const [postUtmeScore, setPostUtmeScore] = useState('');
  const [targetUni, setTargetUni] = useState<any>(null);
  const [targetCourse, setTargetCourse] = useState('');
  const [uniSearch, setUniSearch] = useState('');
  const [courseSearch, setCourseSearch] = useState('');
  const [availableCourses, setAvailableCourses] = useState<string[]>([]);
  const [scoringSystem, setScoringSystem] = useState<ScoringSystem | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isAnalysisLoading, setIsAnalysisLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);
  const [showResults, setShowResults] = useState(false);
  const [isCourseDropdownOpen, setIsCourseDropdownOpen] = useState(false);
  const [isUniDropdownOpen, setIsUniDropdownOpen] = useState(false);
  const [isQuotaModalOpen, setIsQuotaModalOpen] = useState(false);
  const [usagePercent, setUsagePercent] = useState(0);
  const [welcomeMessage, setWelcomeMessage] = useState<string | null>(null);

  const [subjects, setSubjects] = useState<{name: string, grade: OLevelGrade}[]>([
    { name: 'English Language', grade: 'C6' },
    { name: 'Mathematics', grade: 'C6' },
    { name: 'Core Subject 1', grade: 'C6' },
    { name: 'Core Subject 2', grade: 'C6' },
    { name: 'Core Subject 3', grade: 'C6' },
  ]);

  useEffect(() => {
    if (user) {
      getUserProfile(user.uid).then((profile: any) => {
        if (profile) {
          if (profile.jamb_score) setJambScore(profile.jamb_score.toString());
          if (profile.target_course) setTargetCourse(profile.target_course);
          setWelcomeMessage(`Welcome back ${user.displayName || 'student'}, your last session has been restored.`);
          setTimeout(() => setWelcomeMessage(null), 5000);
        }
      });
    }
  }, [user]);

  useEffect(() => {
    const profile = getLocalProfile();
    if (!profile.is_premium) {
      setUsagePercent(Math.min(100, ((profile.daily_requests || 0) / DAILY_LIMIT) * 100));
    }
  }, []);

  useEffect(() => {
    const handleQuotaUpdate = (e: any) => {
      const profile = e.detail;
      if (!profile.is_premium) {
        setUsagePercent(Math.min(100, (profile.daily_requests / DAILY_LIMIT) * 100));
      }
    };
    window.addEventListener('campusai_quota_updated', handleQuotaUpdate);
    return () => window.removeEventListener('campusai_quota_updated', handleQuotaUpdate);
  }, []);

  const aggregateScore = useMemo(() => {
    if (!targetUni) return 0;
    const jamb = parseFloat(jambScore) || 0;
    const post = parseFloat(postUtmeScore) || 0;
    const olevelTotal = subjects.reduce((acc, s) => acc + (GRADE_POINTS[s.grade] || 0), 0);
    
    // Accurate formulas base on school guidelines
    if (scoringSystem) {
      const desc = scoringSystem.explanation.toLowerCase();
      if (desc.includes('50:30:20')) {
        return parseFloat(((jamb/400*50) + (post/100*30) + (olevelTotal/50*20)).toFixed(2));
      }
      if (desc.includes('point-based') || desc.includes('futa')) {
        return parseFloat(((jamb/8) + olevelTotal).toFixed(2));
      }
      if (desc.includes('50:50') || desc.includes('ui') || desc.includes('oau')) {
        return parseFloat(((jamb/8) + (post/2)).toFixed(2));
      }
    }
    return parseFloat((jamb / 4).toFixed(2));
  }, [jambScore, postUtmeScore, targetUni, scoringSystem, subjects]);

  const admissionProbability = useMemo(() => {
    if (!aiResult) return 0;
    const match = aiResult.cutoff.toString().match(/(\d+(\.\d+)?)/);
    const cutoffNumeric = match ? parseFloat(match[1]) : 70;
    const diff = aggregateScore - cutoffNumeric;
    
    // Refined logic: 
    // If aggregate is exactly the cutoff, probability should be around 50-60%
    // If aggregate is above, it scales up to 98%
    // If aggregate is below, it scales down but more gracefully
    let prob;
    if (diff >= 0) {
      prob = 60 + (diff * 4); // 10 points above = 100% (capped at 98)
    } else {
      prob = 60 + (diff * 6); // 10 points below = 0% (capped at 5)
    }
    
    return Math.min(Math.max(Math.round(prob), 5), 98);
  }, [aiResult, aggregateScore]);

  useEffect(() => {
    if (!targetUni) return;
    const fetchInstitutionalKnowledge = async () => {
      setIsSyncing(true);
      const uniSlug = targetUni.slug || targetUni.name.toLowerCase().replace(/\s+/g, '-');
      
      // 1. Check Static Map First
      const instantMatch = TOP_INSTITUTION_MAP[uniSlug] || Object.entries(TOP_INSTITUTION_MAP).find(([k]) => targetUni.name.toLowerCase().includes(k))?.[1];
      if (instantMatch) {
        setScoringSystem(instantMatch);
      }

      try {
        // 2. Check Cloud Cache
        const cached = await getGlobalScoringSystem(uniSlug);
        const TWO_WEEKS_MS = 14 * 24 * 60 * 60 * 1000;
        const isStale = cached && (Date.now() - (cached.updatedAt?.seconds * 1000 || 0) > TWO_WEEKS_MS);

        if (cached && !isStale) {
          if (!instantMatch) setScoringSystem(cached);
          const courses = await getUniversityCourses(targetUni.name);
          setAvailableCourses(courses);
        } else {
          // 3. Fetch from AI if not cached or stale
          const [courses, realSystem] = await Promise.all([
            getUniversityCourses(targetUni.name), 
            getUniversityScoringSystem(targetUni.name)
          ]);
          setAvailableCourses(courses);
          if (!instantMatch) setScoringSystem(realSystem);
          
          // Save to cloud cache
          if (realSystem) {
            await saveGlobalScoringSystem(uniSlug, {
              ...realSystem,
              updatedAt: { seconds: Math.floor(Date.now() / 1000) }
            });
          }
        }
      } catch (e) {
        console.error("Scoring System Sync Error:", e);
      } finally { 
        setIsSyncing(false); 
      }
    };
    fetchInstitutionalKnowledge();
  }, [targetUni]);

  const filteredUnis = useMemo(() => {
    if (!uniSearch) return [];
    return universityData.filter(u => u.name.toLowerCase().includes(uniSearch.toLowerCase())).slice(0, 5);
  }, [uniSearch]);

  const handleLaunchAudit = async () => {
    if (!user) { onLoginRequest(); return; }
    if (!targetUni || (!targetCourse && !courseSearch)) return;

    if (user) {
      saveUserProfile(user.uid, {
        jamb_score: parseFloat(jambScore),
        target_course: targetCourse || courseSearch,
        target_university: targetUni.name,
      });
    }

    // Quota Check
    const { allowed } = await checkAndIncrementRequests(user.uid);
    if (!allowed) {
      setIsQuotaModalOpen(true);
      return;
    }

    setIsAnalysisLoading(true);
    try {
      const result = await getCourseCutoffInfo(targetUni.name, targetCourse || courseSearch, aggregateScore, subjects.map(s => `${s.name}: ${s.grade}`).join(', '), user?.role);
      setAiResult(result);
      setShowResults(true);
    } finally { setIsAnalysisLoading(false); }
  };

  const updateSubject = (index: number, grade: OLevelGrade) => {
    const updated = [...subjects];
    updated[index].grade = grade;
    setSubjects(updated);
  };

  return (
    <section id="calculator" className="py-24 bg-gray-950 text-white rounded-[64px] my-12 border border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-8 max-w-7xl">
        <div className="flex flex-col lg:flex-row gap-16 md:gap-20">
          <div className="lg:w-1/2 space-y-12">
            <div className="space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] font-black uppercase tracking-widest text-cyan-400">
                  <Calculator size={14} /> Merit Logic Engine v5.4
                </div>
                {usagePercent > 70 && (
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-orange-500/10 border border-orange-500/20 rounded-full text-[10px] font-black uppercase tracking-widest text-orange-400">
                    <Activity size={12} /> Signal: {100 - Math.round(usagePercent)}%
                  </div>
                )}
              </div>
              <h2 className="text-5xl md:text-7xl font-black tracking-tighter">Admission <br /><span className="text-cyan-400">Strategist & Analyzer</span></h2>
              <p className="text-gray-400 font-medium text-lg leading-relaxed max-w-md">Accurate aggregate calculation, predictive analysis, and strategic alternatives.</p>
              {welcomeMessage && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="p-4 bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 font-bold rounded-2xl text-xs uppercase tracking-widest max-w-md">
                  {welcomeMessage}
                </motion.div>
              )}
            </div>

            <div className="p-8 md:p-10 bg-white/5 rounded-[48px] border border-white/10 space-y-8 relative z-30">
              <div className="space-y-6">
                <div className="relative">
                  <label htmlFor="uni-search" className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-3 block">Target University</label>
                  <div className="relative">
                    <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                    <input 
                      id="uni-search"
                      name="uni-search"
                      type="text" placeholder="Search school..." value={uniSearch} 
                      onChange={(e) => { setUniSearch(e.target.value); setIsUniDropdownOpen(true); }}
                      className="w-full pl-14 pr-6 py-5 bg-black/40 border border-white/5 rounded-3xl font-bold outline-none focus:border-cyan-500 transition-all" 
                    />
                    <AnimatePresence>
                      {isUniDropdownOpen && filteredUnis.length > 0 && (
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="absolute top-full left-0 right-0 mt-2 bg-gray-900 border border-white/10 rounded-3xl overflow-hidden shadow-2xl z-50">
                          {filteredUnis.map(u => (
                            <button key={u.name} onClick={() => { setTargetUni(u); setUniSearch(u.name); setIsUniDropdownOpen(false); }} className="w-full text-left px-6 py-4 hover:bg-white/5 font-bold border-b border-white/5 last:border-0">{u.name}</button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="relative">
                   <label htmlFor="course-search" className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-3 block">Course Choice</label>
                   <div className="relative">
                    <BookOpen className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                    <input 
                      id="course-search"
                      name="course-search"
                      type="text" placeholder="e.g. Nursing Science..." value={courseSearch}
                      onChange={(e) => { setCourseSearch(e.target.value); setIsCourseDropdownOpen(true); }}
                      className="w-full pl-14 pr-6 py-5 bg-black/40 border border-white/5 rounded-3xl font-bold outline-none focus:border-cyan-500 transition-all" 
                    />
                  </div>
                </div>
              </div>

              {scoringSystem && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="p-4 bg-cyan-500/10 rounded-2xl border border-cyan-500/20">
                   <p className="text-[10px] font-black text-cyan-400 uppercase tracking-widest flex items-center gap-2">
                     <ShieldCheck size={14} /> Active Formula: {scoringSystem.explanation}
                   </p>
                </motion.div>
              )}

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                  <label htmlFor="jamb-score" className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-2">JAMB Score</label>
                  <input id="jamb-score" name="jamb-score" type="number" placeholder="400" value={jambScore} onChange={e => setJambScore(e.target.value)} className="w-full p-5 bg-black/40 border border-white/5 rounded-3xl font-black text-2xl text-center outline-none focus:border-blue-500" />
                </div>
                {(!scoringSystem || scoringSystem.hasPostUtme) && (
                  <div className="space-y-3">
                    <label htmlFor="post-utme-score" className="text-[10px] font-black uppercase text-gray-500 tracking-widest ml-2">Post-UTME (100)</label>
                    <input id="post-utme-score" name="post-utme-score" type="number" placeholder="100" value={postUtmeScore} onChange={e => setPostUtmeScore(e.target.value)} className="w-full p-5 bg-black/40 border border-white/5 rounded-3xl font-black text-2xl text-center outline-none focus:border-blue-500" />
                  </div>
                )}
              </div>

              {(!scoringSystem || scoringSystem.hasOLevel) && (
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <div className="flex justify-between items-center px-2">
                    <label className="text-[10px] font-black uppercase text-gray-500 tracking-widest">O-Level Parameters</label>
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-emerald-500/10 rounded-lg text-[8px] font-black text-emerald-400 uppercase tracking-widest">
                      <Award size={10} /> Merit Points
                    </div>
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                     {subjects.map((sub, idx) => (
                       <div key={idx} className="flex items-center justify-between p-3 bg-black/40 border border-white/5 rounded-2xl">
                          <span className="text-xs font-bold text-gray-400">{sub.name}</span>
                          <label htmlFor={`grade-${sub.name.replace(/\s+/g, '-').toLowerCase()}`} className="sr-only">Grade for {sub.name}</label>
                          <select 
                            id={`grade-${sub.name.replace(/\s+/g, '-').toLowerCase()}`}
                            name={`grade-${sub.name.replace(/\s+/g, '-').toLowerCase()}`}
                            value={sub.grade} 
                            onChange={(e) => updateSubject(idx, e.target.value as OLevelGrade)}
                            className="bg-gray-800 text-white font-black text-xs px-3 py-1.5 rounded-lg outline-none cursor-pointer"
                          >
                            {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                          </select>
                       </div>
                     ))}
                  </div>
                </div>
              )}

              <button 
                onClick={handleLaunchAudit} disabled={isAnalysisLoading || !targetUni}
                className="w-full py-6 rounded-3xl font-black text-sm uppercase tracking-[0.2em] shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95 bg-blue-600 text-white"
              >
                {isAnalysisLoading ? <Loader2 className="animate-spin" size={20} /> : <><Sparkles size={18} /> Run AI Audit</>}
              </button>
            </div>
          </div>

          <div className="lg:w-1/2">
            <AnimatePresence mode="wait">
              {showResults && aiResult ? (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col space-y-12">
                  <div className="bg-white/5 border border-white/10 rounded-[48px] p-10 md:p-12 relative overflow-hidden">
                    <button onClick={() => setShowResults(false)} className="absolute top-6 right-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all"><X size={20} /></button>
                    <div className="flex flex-col md:flex-row items-center justify-between gap-12 mb-14">
                      <ProbabilityGauge probability={admissionProbability} />
                      <div className="text-center md:text-left">
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-2">My Aggregate</p>
                        <h4 className="text-6xl font-black text-white">{aggregateScore}%</h4>
                        <div className="mt-4 p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20">
                           <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest flex items-center gap-2"><ShieldCheck size={14}/> {targetUni?.name} Verified</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-10 border-t border-white/10">
                       <div className="p-6 bg-white/5 rounded-3xl border border-white/5">
                          <p className="text-[9px] font-black text-gray-500 uppercase mb-3">Predicted Cutoff</p>
                          <p className="text-2xl font-black text-cyan-400">{aiResult.cutoff}</p>
                       </div>
                       <div className="p-6 bg-white/5 rounded-3xl border border-white/5">
                          <p className="text-[9px] font-black text-gray-500 uppercase mb-3">Reliability Index</p>
                          <p className="text-xs font-bold leading-relaxed text-gray-300">{aiResult.reliability}</p>
                       </div>
                    </div>
                  </div>

                  <div className="p-10 md:p-12 bg-blue-600 rounded-[48px] shadow-xl text-white">
                    <div className="flex items-center gap-4 mb-8">
                       <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center"><Lightbulb size={24}/></div>
                       <h5 className="text-2xl font-black uppercase tracking-tighter">Strategist Recommendation</h5>
                    </div>
                    <p className="text-base font-bold leading-relaxed italic opacity-95 mb-10">"{aiResult.recommendation}"</p>
                    <button onClick={() => onDiscussWithAI(`My aggregate for ${targetCourse} at ${targetUni?.name} is ${aggregateScore}%. What are my chances?`)} className="w-full py-5 bg-white text-blue-600 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-blue-50 transition-all"><Brain size={20}/> Discuss Strategy</button>
                  </div>
                  
                  {aiResult.alternatives && aiResult.alternatives.length > 0 && (
                    <div className="bg-white/5 border border-white/10 rounded-[48px] p-10 md:p-12 overflow-hidden">
                      <div className="flex items-center gap-4 mb-8">
                         <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><ArrowRight size={24} className="text-gray-400" /></div>
                         <h5 className="text-2xl font-black uppercase tracking-tighter text-white">Suggested Alternatives</h5>
                      </div>
                      <div className="space-y-6">
                        {aiResult.alternatives.map((alt: any, idx: number) => (
                          <div key={idx} className="p-8 bg-white/5 hover:bg-white/10 transition-colors border border-white/5 rounded-[32px]">
                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
                              <h6 className="font-bold text-white text-base max-w-[70%]">{alt.name}</h6>
                              <span className="shrink-0 px-4 py-2 bg-cyan-500/10 text-cyan-400 rounded-full text-xs font-black tracking-widest uppercase">Cutoff: {alt.typicalCutoff}</span>
                            </div>
                            <p className="text-sm text-gray-400 leading-relaxed font-medium">{alt.reasoning}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {aiResult.fresherBudget && (
                    <div className="bg-emerald-950/30 border border-emerald-500/20 rounded-[48px] p-10 md:p-12 overflow-hidden">
                      <div className="flex items-center gap-4 mb-8">
                         <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center"><Award size={24} className="text-emerald-400" /></div>
                         <h5 className="text-2xl font-black uppercase tracking-tighter text-white">Estimated Fresher Budget</h5>
                      </div>
                      <p className="text-base text-gray-300 leading-relaxed font-medium bg-emerald-500/5 p-8 rounded-[32px]">{aiResult.fresherBudget}</p>
                    </div>
                  )}
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-white/5 rounded-[56px] bg-white/[0.02]">
                   <div className="w-24 h-24 bg-white/5 rounded-[40px] flex items-center justify-center mb-8"><Brain size={48} className="text-gray-600" /></div>
                   <h3 className="text-2xl font-black uppercase tracking-tight mb-4">Logic Node Awaiting Input</h3>
                   <p className="text-gray-500 font-medium max-w-sm">Enter your scores and select an institution to initiate the 2026 merit probability mapping.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
      <QuotaModal 
        isOpen={isQuotaModalOpen} 
        onClose={() => setIsQuotaModalOpen(false)} 
        onUpgrade={() => {
          setIsQuotaModalOpen(false);
          window.dispatchEvent(new CustomEvent('campusai_open_payment'));
        }} 
      />
    </section>
  );
};

export default CutoffCalculator;
