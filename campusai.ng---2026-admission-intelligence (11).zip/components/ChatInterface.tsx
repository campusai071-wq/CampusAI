
import React, { useState, useRef, useEffect } from 'react';
import { Send, ArrowLeft, Loader2, Globe, Sparkles, Zap, Map as MapIcon, RefreshCw, User, Lock, ArrowRight, BarChart3, Activity, Brain, Download, Crown, Paperclip, FileText, X as CloseIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Markdown from 'react-markdown';
import { streamGeminiChat } from '../services/geminiService';
import { getLocalProfile, checkAndIncrementRequests, DAILY_LIMIT } from '../services/userService';
import { logChatSession, saveChatHistory, getChatHistory } from '../services/dbService';
import { ChatMessage, AdminState } from '../types';
import QuotaModal from './QuotaModal';

interface ChatInterfaceProps {
  onBack: () => void;
  initialPrompt?: string;
  onClearPrompt?: () => void;
  user: any;
  admin?: AdminState;
  userCoords?: { lat: number; lng: number };
  onLoginRequest: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ onBack, initialPrompt, onClearPrompt, user, admin, onLoginRequest }) => {
  const isAuthorized = user || admin?.isLoggedIn;
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [groundingMode, setGroundingMode] = useState<'none' | 'search' | 'maps'>('none');
  const [showStats, setShowStats] = useState(false);
  const [isQuotaModalOpen, setIsQuotaModalOpen] = useState(false);
  const [usagePercent, setUsagePercent] = useState(0);
  const [attachment, setAttachment] = useState<{ data: string; mimeType: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
     if (user) {
        getChatHistory(user.uid).then(history => {
            if (history && history.length > 0) setMessages(history);
        });
     }
  }, [user]);

  useEffect(() => {
    const profile = getLocalProfile();
    if (!profile.is_premium) {
      setUsagePercent(Math.min(100, ((profile.daily_requests || 0) / DAILY_LIMIT) * 100));
    }
  }, []);

  useEffect(() => {
    const handleQuotaUpdate = (e: any) => {
      const profile = e.detail;
      if (!profile.is_premium) {
        setUsagePercent(Math.min(100, (profile.daily_requests / DAILY_LIMIT) * 100));
      }
    };
    window.addEventListener('campusai_quota_updated', handleQuotaUpdate);
    return () => window.removeEventListener('campusai_quota_updated', handleQuotaUpdate);
  }, []);

  useEffect(() => {
    if (initialPrompt) {
      setInput(initialPrompt);
      if (onClearPrompt) onClearPrompt();
    }
  }, [initialPrompt]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!isAuthorized) { onLoginRequest(); return; }
    if (!input.trim() || isLoading) return;

    // Quota Check
    if (user && !admin?.isLoggedIn) {
      const { allowed } = await checkAndIncrementRequests(user.uid);
      if (!allowed) {
        setIsQuotaModalOpen(true);
        return;
      }
    }

    const currentInput = input;
    const currentAttachment = attachment;
    const historyForModel = messages.slice(-12).map(m => ({ role: m.role, text: m.text }));
    
    setMessages(prev => [...prev, { role: 'user', text: currentInput }, { role: 'model', text: '' }]);
    setInput('');
    setAttachment(null);
    setIsLoading(true);

    try {
      const stream = streamGeminiChat(
        currentInput, 
        historyForModel, 
        currentAttachment ? { data: currentAttachment.data, mimeType: currentAttachment.mimeType } : undefined, 
        groundingMode === 'search', 
        user?.role || 'Pre-Admission',
        user?.university,
        user?.targetCourse
      );
      let fullText = "";
      for await (const chunk of stream) {
        fullText += chunk.text || "";
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1] = { role: 'model', text: fullText };
          return updated;
        });
      }

      // Log chat to Firebase
      if (user && user.uid) {
        const updatedMessages = [...messages, { role: 'user', text: currentInput }, { role: 'model', text: fullText }];
        logChatSession(user.uid, updatedMessages as ChatMessage[]);
        saveChatHistory(user.uid, updatedMessages as ChatMessage[]);
      }
    } finally { setIsLoading(false); }
  };

  const handleSaveChat = async () => {
    if (messages.length === 0) return;
    const content = messages.map(m => `${m.role.toUpperCase()}: ${m.text}`).join('\n\n---\n\n');
    
    // Try native share for mobile if possible
    if (navigator.share && navigator.canShare && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
      try {
        const file = new File([content], `CampusAI_Session_${Date.now()}.txt`, { type: 'text/plain' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: 'CampusAI Strategy Session',
            files: [file]
          });
          return;
        } else {
          await navigator.share({
            title: 'CampusAI Strategy Session',
            text: content.substring(0, 5000)
          });
          return;
        }
      } catch (e) {
        console.error("Share failed, falling back to download:", e);
      }
    }

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CampusAI_Strategist_Session_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File too large. Max 5MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      const data = base64.split(',')[1];
      setAttachment({
        data,
        mimeType: file.type,
        name: file.name
      });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] w-full bg-white dark:bg-gray-800 rounded-[40px] shadow-2xl overflow-hidden relative border border-gray-100 dark:border-gray-700">
      <div className={`px-6 py-5 text-white flex justify-between items-center bg-gray-950 relative z-20`}>
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2.5 hover:bg-white/10 rounded-xl transition-all"><ArrowLeft size={20} /></button>
          <div className="cursor-pointer" onClick={() => setShowStats(!showStats)}>
            <h2 className="font-black text-sm uppercase tracking-[0.2em] flex items-center gap-2">
              Strategist Node 
              <Activity size={14} className="text-emerald-500 animate-pulse" />
            </h2>
            {usagePercent > 70 && (
              <div className="flex items-center gap-1.5 mt-1">
                <div className="w-1 h-1 bg-orange-500 rounded-full animate-pulse"></div>
                <span className="text-[8px] font-black text-orange-500 uppercase tracking-widest">Signal Capacity: {100 - Math.round(usagePercent)}%</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          <button onClick={handleSaveChat} className="p-2.5 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl transition-all text-gray-400 hover:text-white" title="Save Transcript">
            <Download size={18} />
          </button>
          <button onClick={() => setGroundingMode(groundingMode === 'search' ? 'none' : 'search')} className={`p-2.5 rounded-xl border transition-all ${groundingMode === 'search' ? 'bg-white text-emerald-600 shadow-lg' : 'bg-white/5 border-white/10'}`}>
            <Globe size={18}/>
          </button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-grow overflow-y-auto p-6 md:p-10 space-y-8 bg-gray-50/30 dark:bg-gray-900/30 no-scrollbar">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
             <div className="w-20 h-20 bg-gray-200 dark:bg-gray-800 rounded-[32px] flex items-center justify-center mb-6 shadow-inner">
                <Brain size={40} className="text-gray-400" />
             </div>
             <p className="text-sm font-black uppercase tracking-[0.3em] dark:text-white">Secure Uplink Established</p>
             <p className="text-[10px] font-bold mt-2 max-w-xs leading-relaxed text-gray-500 uppercase">Input your 2026 admission inquiry to activate logic kernels.</p>
          </div>
        )}
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className={`w-10 h-10 rounded-[18px] flex items-center justify-center shrink-0 shadow-lg ${msg.role === 'user' ? 'bg-blue-600' : 'bg-gray-950'}`}>
              {msg.role === 'user' ? <User size={20} className="text-white" /> : <Sparkles size={20} className="text-cyan-400" />}
            </div>
            <div className={`p-6 rounded-[32px] text-base leading-relaxed max-w-[85%] md:max-w-[75%] ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none shadow-blue-500/20' : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-tl-none border border-gray-100 dark:border-gray-700 shadow-sm'}`}>
               <div className="markdown-body">
                 <Markdown>{msg.text}</Markdown>
               </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-[18px] flex items-center justify-center shrink-0 bg-gray-950">
               <Sparkles size={20} className="text-cyan-400" />
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-[32px] rounded-tl-none border border-gray-100 dark:border-gray-700">
               <Loader2 className="animate-spin text-blue-500" size={20} />
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 relative z-20">
        <AnimatePresence>
          {attachment && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-between border border-blue-100 dark:border-blue-800"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                  <FileText size={20} />
                </div>
                <div>
                  <p className="text-xs font-black dark:text-white truncate max-w-[200px]">{attachment.name}</p>
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Ready for analysis</p>
                </div>
              </div>
              <button onClick={() => setAttachment(null)} className="p-2 hover:bg-red-500/10 text-gray-400 hover:text-red-500 rounded-lg transition-all">
                <CloseIcon size={16} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="mb-4 flex items-center justify-between px-2">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${usagePercent > 80 ? 'bg-red-500 animate-pulse' : usagePercent > 50 ? 'bg-orange-500' : 'bg-emerald-500'}`}></div>
            <span className={`text-[9px] font-black uppercase tracking-widest ${usagePercent > 80 ? 'text-red-600' : usagePercent > 50 ? 'text-orange-600' : 'text-gray-400'}`}>
              Daily Signal Capacity: {Math.round(usagePercent)}%
            </span>
          </div>
          {usagePercent > 50 && (
            <button onClick={() => setIsQuotaModalOpen(true)} className="text-[9px] font-black text-blue-600 uppercase underline tracking-widest">Upgrade</button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            className="hidden" 
            accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg"
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-14 h-14 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-2xl flex items-center justify-center text-gray-400 transition-all border border-gray-100 dark:border-gray-700"
          >
            <Paperclip size={24} />
          </button>
          <input 
            type="text" 
            value={input} 
            onChange={e => setInput(e.target.value)} 
            onKeyDown={e => e.key === 'Enter' && handleSend()} 
            placeholder="Input Strategist inquiry..." 
            className="flex-grow bg-gray-50 dark:bg-gray-800 p-5 px-6 rounded-[24px] outline-none font-bold dark:text-white border-2 border-transparent focus:border-blue-500 transition-all shadow-inner" 
          />
          <button 
            onClick={handleSend} 
            disabled={isLoading || !input.trim()} 
            className="w-14 h-14 bg-blue-600 hover:bg-blue-500 rounded-2xl flex items-center justify-center text-white shadow-[0_15px_40px_rgba(37,99,235,0.4)] active:scale-95 transition-all disabled:opacity-50"
          >
            {isLoading ? <Loader2 size={24} className="animate-spin" /> : <Send size={24} />}
          </button>
        </div>
      </div>
      <QuotaModal 
        isOpen={isQuotaModalOpen} 
        onClose={() => setIsQuotaModalOpen(false)} 
        onUpgrade={() => {
          setIsQuotaModalOpen(false);
          // Trigger payment or upgrade flow
          window.dispatchEvent(new CustomEvent('campusai_open_payment'));
        }} 
      />
    </div>
  );
};

export default ChatInterface;
