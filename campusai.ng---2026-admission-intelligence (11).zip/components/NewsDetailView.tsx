import React, { useState, useEffect } from 'react';
import { stringify } from '../services/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Clock, Share2, Bookmark, ThumbsUp, ShieldCheck, Sparkles, User, Send, MessageSquare, Trash2, Loader2, LogIn, Check, RefreshCw } from 'lucide-react';
import { NewsItem, Comment } from '../types';
import { fetchNewsComments, postNewsComment, deleteNewsComment, getNewsItemBySlug } from '../services/dbService';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import SEO from './SEO';

interface NewsDetailViewProps {
  news?: NewsItem;
  user: any;
  onClose: () => void;
  relatedNews: NewsItem[];
  onSelectRelated: (news: NewsItem) => void;
  onLoginRequest: () => void;
}

const NewsDetailView: React.FC<NewsDetailViewProps> = ({ news: initialNews, user, onClose, onLoginRequest }) => {
  const { slug } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  
  const [news, setNews] = useState<NewsItem | null>(initialNews || location.state?.article || null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingComments, setIsLoadingComments] = useState(true);
  const [isLoadingNews, setIsLoadingNews] = useState(!news);
  const [related, setRelated] = useState<{ title: string, url: string }[]>([]);
  
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [showShareSuccess, setShowShareSuccess] = useState(false);

  useEffect(() => {
    if (!news && slug) {
      loadNews();
    }
  }, [slug]);

  const loadNews = async () => {
    if (!slug) return;
    setIsLoadingNews(true);
    const data = await getNewsItemBySlug(slug);
    setNews(data);
    setIsLoadingNews(false);
  };

  useEffect(() => {
    if (news) {
      loadComments();
      const savedBookmarks = JSON.parse(localStorage.getItem('campusai_bookmarks') || '[]');
      setIsBookmarked(savedBookmarks.includes(news.id));
      
      if (news.relatedNews && news.relatedNews.length > 0) {
        setRelated(news.relatedNews);
      } else {
        import('../services/aiService').then(({ summarizeNews }) => {
          summarizeNews(news.excerpt).then(data => setRelated(data.related));
        });
      }
    }
  }, [news?.id]);

  const loadComments = async () => {
    if (!news) return;
    setIsLoadingComments(true);
    const data = await fetchNewsComments(news.id);
    setComments(data);
    setIsLoadingComments(false);
  };

  const handleToggleBookmark = () => {
    if (!news) return;
    const current = JSON.parse(localStorage.getItem('campusai_bookmarks') || '[]');
    const updated = current.includes(news.id) ? current.filter((i: string) => i !== news.id) : [...current, news.id];
    try {
      localStorage.setItem('campusai_bookmarks', stringify(updated));
    } catch (e) {
      console.error("Circular structure error in setItem('campusai_bookmarks'):", e);
    }
    setIsBookmarked(updated.includes(news.id));
  };

  const handleShare = async () => {
    if (!news) return;
    const shareData = {
      title: news.title,
      text: news.excerpt,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        setShowShareSuccess(true);
        setTimeout(() => setShowShareSuccess(false), 2000);
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  if (isLoadingNews) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <Loader2 size={48} className="animate-spin text-blue-600" />
        <p className="text-sm font-black uppercase tracking-widest text-gray-400">Decrypting Intelligence...</p>
      </div>
    );
  }

  if (!news) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6">
        <div className="w-20 h-20 bg-gray-100 dark:bg-gray-900 rounded-[32px] flex items-center justify-center text-gray-400">
          <ShieldCheck size={40} />
        </div>
        <div className="text-center">
          <h2 className="text-2xl font-black dark:text-white uppercase tracking-tight mb-2">Intelligence Not Found</h2>
          <p className="text-gray-500 font-bold">The requested report does not exist or has been archived.</p>
          <p className="text-[10px] text-gray-400 mt-2 uppercase font-black tracking-widest">Slug: {slug}</p>
        </div>
        <div className="flex gap-4">
          <button onClick={() => navigate('/')} className="px-8 py-4 bg-gray-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl">Return to Feed</button>
          <button onClick={loadNews} className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl flex items-center gap-2">
            <RefreshCw size={14} /> Retry Sync
          </button>
        </div>
      </div>
    );
  }

  const readTime = Math.max(3, Math.ceil((news.fullContent || news.excerpt).split(' ').length / 200));

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onLoginRequest();
      return;
    }
    if (!commentText.trim() || isSubmitting) return;

    setIsSubmitting(true);
    const newComment = await postNewsComment({
      newsId: news.id,
      uid: user.uid,
      displayName: user.displayName || 'Scholar',
      photoURL: user.photoURL,
      text: commentText.trim()
    });

    if (newComment) {
      setComments(prev => [newComment, ...prev]);
      setCommentText('');
    } else {
      alert("Failed to sync comment with cloud database.");
    }
    setIsSubmitting(false);
  };

  const handleDeleteComment = async (commentId: string) => {
    if (confirm("Permanently delete this comment?")) {
      const success = await deleteNewsComment(commentId);
      if (success) {
        setComments(prev => prev.filter(c => c.id !== commentId));
      }
    }
  };

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="bg-white dark:bg-gray-950 min-h-screen">
      <SEO 
        title={news.title} 
        description={news.excerpt} 
        article={true}
      />
      <div className="max-w-4xl mx-auto px-6 md:px-0">
        {/* Navigation */}
        <button onClick={onClose} className="flex items-center gap-2 mb-12 py-4 text-blue-600 font-black uppercase text-[10px] tracking-widest hover:translate-x-[-4px] transition-transform">
           <ArrowLeft size={16} /> Return to Intelligence Feed
        </button>

        <div className="flex items-center gap-3 mb-8">
           <span className="px-4 py-1.5 bg-blue-600 text-white rounded-full text-[10px] font-black uppercase tracking-widest">{news.category}</span>
           <div className="w-1 h-1 rounded-full bg-gray-300"></div>
           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1.5"><Clock size={12} /> {readTime} MIN READ</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-black text-gray-900 dark:text-white mb-10 leading-[1.1] tracking-tight">{news.title}</h1>
        
        <div className="flex items-center justify-between py-8 border-y border-gray-100 dark:border-gray-800 mb-12">
           <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-900 rounded-2xl flex items-center justify-center text-white font-black overflow-hidden border border-white/10 shadow-lg">
                 {user?.photoURL ? <img src={user.photoURL} className="w-full h-full object-cover" /> : "EI"}
              </div>
              <div>
                 <p className="text-xs font-black dark:text-white uppercase tracking-widest flex items-center gap-2">Emmanuel Iweh <ShieldCheck size={14} className="text-blue-500" /></p>
                 <p className="text-[10px] font-bold text-gray-400 mt-0.5">{news.date}</p>
              </div>
           </div>
           <div className="flex gap-2">
              <button 
                onClick={() => setIsLiked(!isLiked)} 
                className={`p-3 bg-gray-50 dark:bg-gray-900 rounded-xl transition-all active:scale-75 ${isLiked ? 'text-blue-600 bg-blue-50 dark:bg-blue-900/30' : 'text-gray-800 dark:text-gray-400 hover:text-blue-600'}`}
              >
                <ThumbsUp size={18} fill={isLiked ? "currentColor" : "none"} />
              </button>
              <button 
                onClick={handleToggleBookmark} 
                className={`p-3 bg-gray-50 dark:bg-gray-900 rounded-xl transition-all active:scale-75 ${isBookmarked ? 'text-blue-600 bg-blue-50 dark:bg-blue-900/30' : 'text-gray-800 dark:text-gray-400 hover:text-blue-600'}`}
              >
                <Bookmark size={18} fill={isBookmarked ? "currentColor" : "none"} />
              </button>
              <button 
                onClick={handleShare} 
                className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-gray-800 dark:text-gray-400 hover:text-blue-600 transition-all active:scale-75 relative"
              >
                {showShareSuccess ? <Check size={18} className="text-emerald-500" /> : <Share2 size={18} />}
                <AnimatePresence>
                  {showShareSuccess && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
                      className="absolute -top-10 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-[8px] font-black uppercase tracking-widest px-2 py-1 rounded-md whitespace-nowrap"
                    >
                      Copied to Clipboard
                    </motion.div>
                  )}
                </AnimatePresence>
              </button>
           </div>
        </div>

        <article className="prose prose-xl max-w-none dark:prose-invert">
           <p className="text-xl md:text-2xl text-gray-900 dark:text-white leading-relaxed font-black mb-10 italic">"{news.excerpt}"</p>
           <div className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed space-y-6 font-medium">
              {news.fullContent || "Detailed investigation data is being synchronized from the institutional database. Standby for secondary analysis report."}
           </div>
        </article>

        {related.length > 0 && (
          <div className="my-12">
            <h4 className="text-sm font-black text-gray-900 dark:text-white uppercase tracking-widest mb-6">Related Intelligence:</h4>
            <div className="flex flex-wrap gap-3">
              {related.map((item, i) => (
                <a key={i} href={item.url} target="_blank" rel="noopener noreferrer" className="px-4 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors">
                  {item.title}
                </a>
              ))}
            </div>
          </div>
        )}

        <div className="my-20 p-8 bg-blue-50 dark:bg-blue-900/10 rounded-[40px] border border-blue-100 dark:border-blue-800">
           <h4 className="flex items-center gap-2 text-blue-700 dark:text-cyan-400 font-black text-sm uppercase mb-6"><Sparkles size={20} /> Strategist Intelligence Note</h4>
           <p className="text-base font-bold text-gray-700 dark:text-gray-300 leading-relaxed italic">"Our analysis indicates that this update strictly aligns with the 2026 merit guidelines. Candidates are advised to cross-reference their NIN data before final verification."</p>
        </div>

        {/* Comment Section */}
        <section className="py-20 border-t border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between mb-10">
            <h3 className="text-2xl font-black flex items-center gap-3 dark:text-white uppercase tracking-tight">
              <MessageSquare size={24} className="text-blue-600" /> Discussion Hub ({comments.length})
            </h3>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1 rounded-full text-[9px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest border border-emerald-100 dark:border-emerald-800">Live Sync Active</div>
          </div>

          <form onSubmit={handlePostComment} className="mb-16">
            {!user ? (
              <div onClick={onLoginRequest} className="p-8 bg-gray-50 dark:bg-gray-900 rounded-[32px] border border-dashed border-gray-200 dark:border-gray-800 text-center cursor-pointer group hover:border-blue-500 transition-all">
                <LogIn className="mx-auto mb-4 text-gray-400 group-hover:text-blue-500 transition-colors" size={32} />
                <p className="font-bold text-gray-600 dark:text-gray-400">Sign in to join the conversation</p>
                <p className="text-[10px] font-black uppercase text-blue-600 mt-2 tracking-widest">Connect Scholar Profile</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative">
                  <textarea 
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Share your thoughts or ask a question..."
                    className="w-full bg-gray-50 dark:bg-gray-900 border-2 border-transparent focus:border-blue-500 rounded-[32px] p-6 pr-16 outline-none font-bold dark:text-white min-h-[120px] transition-all resize-none shadow-inner"
                  />
                  <button 
                    type="submit" 
                    disabled={!commentText.trim() || isSubmitting}
                    className="absolute bottom-4 right-4 w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-xl active:scale-95 disabled:opacity-50 transition-all"
                  >
                    {isSubmitting ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
                  </button>
                </div>
                <div className="flex items-center gap-2 px-4">
                   <div className="w-6 h-6 rounded-full overflow-hidden bg-gray-200">
                      {user.photoURL && <img src={user.photoURL} className="w-full h-full object-cover" />}
                   </div>
                   <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Posting as {user.displayName || 'Scholar'}</span>
                </div>
              </div>
            )}
          </form>

          <div className="space-y-8">
            {isLoadingComments ? (
              <div className="py-10 flex justify-center">
                <Loader2 className="animate-spin text-blue-600" size={32} />
              </div>
            ) : comments.length > 0 ? (
              <AnimatePresence>
                {comments.map((comment, idx) => (
                  <motion.div 
                    key={comment.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex gap-4 group"
                  >
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center shrink-0 overflow-hidden shadow-sm">
                       {comment.photoURL ? <img src={comment.photoURL} className="w-full h-full object-cover" /> : <User size={20} className="text-gray-400" />}
                    </div>
                    <div className="flex-grow">
                       <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                             <span className="font-black text-xs md:text-sm dark:text-white uppercase tracking-tight">{comment.displayName}</span>
                             {comment.uid === '5ej852963@gmail.com' && <ShieldCheck size={14} className="text-blue-500" />}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-[8px] font-bold text-gray-400 uppercase">{comment.createdAt?.toDate?.() ? new Date(comment.createdAt.toDate()).toLocaleDateString() : 'Just now'}</span>
                            {user && user.uid === comment.uid && (
                              <button onClick={() => handleDeleteComment(comment.id)} className="p-1 text-gray-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"><Trash2 size={14} /></button>
                            )}
                          </div>
                       </div>
                       <div className="p-4 md:p-5 bg-gray-50 dark:bg-gray-900 rounded-[24px] rounded-tl-none border border-gray-100 dark:border-gray-800 shadow-sm">
                          <p className="text-sm md:text-base text-gray-700 dark:text-gray-300 leading-relaxed font-medium">{comment.text}</p>
                       </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            ) : (
              <div className="py-20 text-center space-y-4">
                 <div className="w-16 h-16 bg-gray-50 dark:bg-gray-900 rounded-3xl flex items-center justify-center mx-auto text-gray-300"><MessageSquare size={24} /></div>
                 <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">No discussions yet</p>
                 <p className="text-xs text-gray-500">Be the first to share your intelligence on this update.</p>
              </div>
            )}
          </div>
        </section>

        <div className="pb-24 flex justify-center">
           <button onClick={onClose} className="px-12 py-5 bg-gray-900 dark:bg-white text-white dark:text-black rounded-3xl font-black text-xs uppercase tracking-widest active:scale-95 transition-all">Close Report</button>
        </div>
      </div>
    </motion.div>
  );
};

export default NewsDetailView;