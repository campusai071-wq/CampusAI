
import React, { useState, useEffect } from 'react';
import { Search, Brain, Clock, ShieldCheck, Activity, Fingerprint, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { TICKER_HEADLINES, ADMISSION_DATES } from '../constants';
import { getAsuuStrikeStatus } from '../services/geminiService';
import { getTickerHeadlines } from '../services/dbService';

interface HeroProps {
  onSearch: () => void;
  onAskAI: () => void;
}

const AsuuStatus = () => {
  const [status, setStatus] = useState<{ isActive: boolean; status: string; summary: string } | null>(null);

  useEffect(() => {
    getAsuuStrikeStatus().then(setStatus);
  }, []);

  if (!status) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="flex items-center gap-3 px-4 py-2 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 shadow-xl"
    >
      <div className="relative">
        <div className={`w-2 h-2 rounded-full ${status.isActive ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
        <div className={`absolute inset-0 w-2 h-2 rounded-full animate-ping ${status.isActive ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
      </div>
      <div>
        <p className="text-[8px] font-black uppercase tracking-widest text-white/40 mb-0.5">ASUU Status</p>
        <p className="text-[10px] font-black text-white uppercase tracking-wider">{status.status}</p>
      </div>
    </motion.div>
  );
};

const CountdownTimer = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0, hours: 0, minutes: 0, seconds: 0
  });

  useEffect(() => {
    const target = new Date(ADMISSION_DATES.JAMB_REG_END).getTime();
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = target - now;

      if (difference <= 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const TimeUnit = ({ label, value }: { label: string; value: number }) => (
    <div className="flex flex-col items-center">
      <div className="bg-white/10 backdrop-blur-md border border-white/20 w-12 h-12 md:w-16 md:h-16 rounded-2xl flex items-center justify-center mb-2">
        <span className="text-lg md:text-2xl font-black text-white tabular-nums">
          {value.toString().padStart(2, '0')}
        </span>
      </div>
      <span className="text-[7px] md:text-[8px] font-black uppercase tracking-widest text-cyan-400">{label}</span>
    </div>
  );

  return (
    <div className="inline-flex flex-col items-center p-5 md:p-8 bg-black/20 backdrop-blur-xl border border-white/10 rounded-[32px] md:rounded-[40px] shadow-2xl animate-in zoom-in duration-1000">
      <div className="flex items-center gap-2 mb-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-orange-400">
        <Clock size={12} className="animate-pulse" />
        Official JAMB 2026 Registration Closing
      </div>
      <div className="flex gap-2.5 md:gap-4">
        <TimeUnit label="Days" value={timeLeft.days} />
        <div className="text-white/20 pt-4 font-black">:</div>
        <TimeUnit label="Hrs" value={timeLeft.hours} />
        <div className="text-white/20 pt-4 font-black">:</div>
        <TimeUnit label="Min" value={timeLeft.minutes} />
        <div className="text-white/20 pt-4 font-black">:</div>
        <TimeUnit label="Sec" value={timeLeft.seconds} />
      </div>
    </div>
  );
};

const ActivityPulse = () => {
  const [activeMessage, setActiveMessage] = useState("Scanning UNILAG Merit List...");
  const messages = [
    "34 students in Lagos checking UNILAG Law cutoff...",
    "A scholar just calculated FUTA Engineering aggregate...",
    "In-Campus student tracking semester GPA in UNIBEN...",
    "Graduate scholar mobilizing for NYSC 2026 Batch A...",
    "98% accuracy verified for OAU 2026 scoring formula...",
    "12 scholars currently mapping CBT centers in Kano...",
    "Institution admin publishing National policy update..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveMessage(messages[Math.floor(Math.random() * messages.length)]);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center gap-3 px-5 py-2.5 bg-black/30 backdrop-blur-md rounded-full border border-white/10 shadow-lg mt-8 animate-in fade-in slide-in-from-top-4 duration-700">
      <div className="relative">
        <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
        <div className="absolute inset-0 w-2 h-2 bg-emerald-500 rounded-full animate-ping"></div>
      </div>
      <span className="text-[10px] font-bold text-blue-100 tracking-wide uppercase">{activeMessage}</span>
    </div>
  );
};

const Hero: React.FC<HeroProps> = ({ onSearch, onAskAI }) => {
  const [headlines, setHeadlines] = useState<string[]>(TICKER_HEADLINES);

  useEffect(() => {
    getTickerHeadlines().then(setHeadlines);
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col overflow-hidden bg-[#050505]">
      {/* Immersive Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_30%,#1e3a8a_0%,transparent_70%)] opacity-40"></div>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute top-1/2 left-0 w-[300px] h-[300px] bg-blue-600/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="flex-grow flex flex-col justify-start relative z-10 pt-32 pb-20">
        <div className="container mx-auto px-4 md:px-8">
          <div className="max-w-6xl">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="flex flex-wrap items-center gap-4 mb-8"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-md rounded-full border border-white/10">
                <Sparkles size={14} className="text-emerald-400" />
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/70">Intelligence for the Nigerian Scholar</span>
              </div>
              <AsuuStatus />
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="text-[12vw] md:text-[8vw] font-black leading-[0.85] tracking-tighter text-white uppercase mb-8"
            >
              Sovereign <br />
              <span className="text-emerald-400">Intelligence</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="text-lg md:text-3xl text-white/60 max-w-2xl mb-12 font-medium leading-tight"
            >
              The complete ecosystem for your academic journey. From <span className="text-white">Admission</span> to <span className="text-white">Campus</span> and <span className="text-white">Career</span>.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="flex flex-col sm:flex-row gap-6"
            >
              <button 
                onClick={onAskAI}
                className="group relative px-12 py-6 bg-emerald-500 text-black rounded-full font-black text-sm uppercase tracking-widest overflow-hidden transition-all hover:scale-105 active:scale-95"
              >
                <span className="relative z-10 flex items-center gap-3">
                  <Brain size={20} />
                  Get Started
                </span>
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20 transition-opacity"></div>
              </button>
              <button 
                onClick={() => document.getElementById('news')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-12 py-6 bg-white/5 backdrop-blur-md border border-white/10 text-white rounded-full font-black text-sm uppercase tracking-widest hover:bg-white/10 transition-all flex items-center gap-3"
              >
                Learn More
              </button>
            </motion.div>

            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-12">
              {[
                { label: 'Active Scholars', value: '1.2M+' },
                { label: 'Accuracy Rate', value: '99.8%' },
                { label: 'Institutions', value: '240+' },
                { label: 'AI Responses', value: '5M+' }
              ].map((stat, i) => (
                <div key={i}>
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-2">{stat.label}</p>
                  <p className="text-2xl md:text-4xl font-black text-white">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Live Ticker */}
      <div className="relative w-full bg-white/5 backdrop-blur-xl py-6 border-t border-white/10 z-20">
        <div className="container mx-auto px-4 flex items-center overflow-hidden">
          <div className="bg-red-500 text-[10px] font-black px-3 py-1 rounded-full mr-6 shrink-0 uppercase tracking-widest animate-pulse text-white">
            Live
          </div>
          <div className="ticker-wrap flex-1">
            <div className="ticker-content flex items-center gap-12">
              {[...headlines, ...headlines].map((headline, i) => (
                <div key={i} className="flex items-center gap-3 text-xs font-black whitespace-nowrap text-white/80 uppercase tracking-wider">
                  <div className="w-1 h-1 bg-emerald-400 rounded-full"></div>
                  {headline}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
