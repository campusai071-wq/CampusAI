import React from 'react';
import { Globe, Shield, Heart, Sparkles, CheckCircle, Quote, Mail, Linkedin, User, Brain, Database, Zap, ShieldCheck, ShieldAlert, XCircle, Check, Info } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-32 bg-white dark:bg-gray-950 border-t border-gray-100 dark:border-gray-800 overflow-hidden transition-colors">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-12 md:gap-20 lg:items-start">
            {/* Portrait Column */}
            <div className="w-full lg:w-2/5 relative">
              <div className="relative group max-w-[320px] md:max-w-[400px] mx-auto">
                <div className="absolute -top-10 -left-10 w-32 h-32 md:w-40 md:h-40 bg-blue-500/10 dark:bg-blue-400/5 rounded-full blur-3xl"></div>
                <div className="absolute -bottom-10 -right-10 w-32 h-32 md:w-40 md:h-40 bg-cyan-500/10 dark:bg-cyan-400/5 rounded-full blur-3xl"></div>
                
                <div className="relative z-10 aspect-[3/4] w-full rounded-[40px] md:rounded-[56px] overflow-hidden shadow-2xl border-4 border-white dark:border-gray-900 group-hover:scale-[1.02] transition-transform duration-700 bg-gradient-to-br from-gray-900 to-black">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative">
                      <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full"></div>
                      <User size={100} className="text-gray-700 dark:text-gray-800 relative z-10 opacity-50" strokeWidth={1} />
                      <div className="absolute inset-0 flex items-center justify-center">
                         <span className="text-7xl md:text-8xl font-black text-white/10 select-none">EI</span>
                      </div>
                    </div>
                  </div>
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
                  <div className="absolute top-6 left-6 flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 text-white text-[9px] md:text-[10px] font-black uppercase tracking-widest shadow-xl">
                    <CheckCircle size={14} className="text-cyan-400" fill="currentColor" />
                    Verified Architect
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80"></div>
                  <div className="absolute bottom-10 left-10 right-10">
                    <div className="flex flex-col">
                      <span className="text-2xl md:text-3xl font-black text-white tracking-tight">Emmanuel Iweh</span>
                      <span className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.2em] mt-2 flex items-center gap-2">
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
                        Founder & CEO
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Text Content Column */}
            <div className="w-full lg:w-3/5 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-cyan-400 rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-6 border border-blue-100 dark:border-blue-800">
                <Sparkles size={12} />
                Pioneering Student Tech
              </div>
              
              <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-gray-900 dark:text-white mb-8 leading-[1.1] tracking-tight">
                Empowering the <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">Next Generation</span>
              </h2>
              
              <div className="space-y-6 text-gray-600 dark:text-gray-400 text-base md:text-lg leading-relaxed font-medium">
                <p>
                  <strong>Emmanuel Iweh</strong> architected CampusAI.ng to introduce a new era of **Dynamic Intelligence** to the Nigerian educational landscape. Our platform is designed to provide a real-time, AI-driven companion that empowers scholars with instant, data-backed clarity throughout their academic journey.
                </p>
              </div>
              
              {/* Comparative Grid (Focus on value addition) */}
              <div className="my-12 p-8 bg-gray-50 dark:bg-gray-900 rounded-[40px] border border-gray-100 dark:border-gray-800 shadow-inner">
                <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-8 text-center flex items-center justify-center gap-2">
                   <Info size={16} className="text-blue-500" /> The CampusAI Evolution
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <p className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Conventional Methods</p>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-500"><CheckCircle size={14} className="shrink-0 opacity-20" /> Static Admission Data</li>
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-500"><CheckCircle size={14} className="shrink-0 opacity-20" /> Manual Calculation</li>
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-500"><CheckCircle size={14} className="shrink-0 opacity-20" /> Delayed Information Flow</li>
                    </ul>
                  </div>
                  <div className="space-y-4 md:border-l border-gray-200 dark:border-gray-800 md:pl-8">
                    <p className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">AI-Powered Strategy</p>
                    <ul className="space-y-3">
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-900 dark:text-white"><Check size={14} className="text-emerald-500 shrink-0" /> Real-time Quota Mapping</li>
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-900 dark:text-white"><Check size={14} className="text-emerald-500 shrink-0" /> Autonomous Logic Kernels</li>
                      <li className="flex items-center gap-2 text-xs font-bold text-gray-900 dark:text-white"><Check size={14} className="text-emerald-500 shrink-0" /> Instant News Grounding</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="relative p-8 md:p-12 bg-gray-900 dark:bg-black rounded-[40px] md:rounded-[56px] text-white shadow-2xl overflow-hidden group border border-white/5">
                <div className="absolute top-0 right-0 p-8 text-white/5 pointer-events-none">
                  <Quote size={100} />
                </div>
                
                <div className="relative z-10 flex flex-col gap-6 text-left">
                  <Heart size={28} className="text-red-500" fill="currentColor" />
                  <p className="text-xl md:text-2xl lg:text-3xl font-black leading-tight tracking-tight italic">
                    "Intelligence is about making clarity accessible. We built CampusAI to be the light for every aspiring Nigerian student."
                  </p>
                  <div className="flex items-center gap-4 mt-2">
                    <div className="w-10 h-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"></div>
                    <span className="text-[9px] font-black uppercase tracking-[0.4em] text-gray-500">Emmanuel Iweh</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;